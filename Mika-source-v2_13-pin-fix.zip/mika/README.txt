Mika launcher 2.1 - source
Build: needs aapt (v1), JDK 17+, dalvik-exchange (dx), zipalign, apksigner and an android.jar (API 33).
  ANDROID_JAR=/path/to/android.jar ./build.sh
Output: build/Mika-Launcher.apk (debug-signed; create ~/.android/debug.keystore first, or edit build.sh).
Source layout: src/com/mika/launcher/*.java, res/, AndroidManifest.xml

v2.5 changes
- Map: vector 3D map (MapLibre GL JS bundled in assets/, tiles from OpenFreeMap / CARTO, no API key), pan/zoom/rotate/tilt,
  3D buildings, satellite layer, tap places of interest, search anywhere, in-app routing (OSRM demo server) with
  turn-by-turn banner and re-routing. Falls back to the classic raster map when WebGL/WebView isn't available.
  Settings > Map to pick the engine or use the Google Maps app.
- Mirroring: window now draws behind the notch/rounded corners (Settings > Screen & mirroring), optional edge padding.
- Player: works with any media app, always shows a cover (embedded, MediaStore thumbnail, folder.jpg, URI art,
  or a generated one) over a blurred full-screen background. Home widget uses the blurred cover as its background.

v2.6: drive-to-destination now also shows on the home-screen map card (route line, next turn, distance, ETA, end button).
  Shared route state in NavState.java; "Where to?" and Home/Work shortcuts search, pick the best match and start driving.

v2.7
- Fixed: Settings crashed on open (Map engine option used the wrong preference type).
- Home-screen map is now the same vector map as the Map screen (VectorMapView), with the drive-to route on it.
- Optional Mapbox: Settings > Map > Mapbox access token. With a token the map uses Mapbox GL JS (mapbox-gl 2.15, bundled),
  Mapbox navigation day/night styles with traffic, Mapbox Directions (driving-traffic) and Mapbox search.
  Without a token it uses MapLibre + OpenFreeMap / CARTO + OSRM.

v2.8 (routing)
- Free routing now uses Valhalla (valhalla1.openstreetmap.de) instead of the OSRM demo server; OSRM stays as an automatic fallback
  if the Valhalla server is unreachable. A Mapbox token still takes priority when set.

v2.9
- Icons: whole set redrawn in a modern rounded style (soft corners, thicker round pause bars, rounded play/prev/next,
  proper gear, outline home, etc). New icons: volume up/down, car, back, shuffle, repeat(1), replay/forward 10, star, compass, layers, slideshow.
  The emoji/text glyphs in Player, Media library, Video player, Photo viewer, Map and Settings were replaced with these vector icons.
- Volume card: new volume-down / volume-up buttons around the slider; the mute icon follows the volume.
- Home screen: new second slide with your 3D car (assets/car.glb = BAIC U5 Plus). Swipe left/right (or use the car button in the dock;
  swipes starting on the map keep panning the map, edge swipes always switch). The wheels spin, the road scrolls and the body settles with the
  GPS speed, and everything eases to a stop when the car stops. Settings > "Car page" turns the slide off.

v2.9.1 (car page: sky + soft edges + new car)
- Car widget edges are feathered into the home background (theme gradient or wallpaper): EdgeBlend.java. Car and road are untouched.
- Day / night sky in the 3D scene: blue sky with sun and clouds by day; stars and moon by night; orange dawn / dusk blend, road and car lighting follow.
- Settings > Day & night: Car page sky (Automatic / Always day / Always night), "Day starts at" and "Night starts at" (manual times).
  The "Switch theme automatically at night" option now uses the same times (SkyClock.java).
- assets/car.glb replaced with the low-poly "Hyper GT" (single mesh + colour-strip atlas). Glb.java has a new atlas path: bakes the texture to
  vertex colours, converts Y-up/Z-front to the app's model space, and splits the four wheels by geometry so they still spin.

v2.9.2
- Camera lowered / pulled back: the horizon sits about two thirds up, so the sky is a real part of the scene (it was a thin strip before and the road hid the sun and moon).
- Sky: horizon haze shared with the road, two layers of distant hills (town lights at night), sun / moon sit above the horizon, clouds by day, stars by night.
- Lights: head and tail lamps glow, soft light sprites, head-light beams and red tail glow on the road. Settings > Day & night > Car lights (Automatic / Always on / Off).
- Quick switch pill on the Car page (bottom right): tap to cycle Auto / Day / Night.

v2.10 (full-screen car page + weather)
- Car page is now full screen (no frame, no rounded rim). Its own HUD: speed, clock, Wi-Fi / battery and the page buttons (car, music, layouts, settings)
  at the top left; weather, Auto/Day/Night and Driving/Parked pills at the top right; one glass pill at the bottom with the apps button,
  your pinned dock apps and, when something is playing, cover + title + artist + progress + prev / play-pause / next (hidden when nothing plays).
- Weather in the sky (live Open-Meteo data, also when the home screen has no weather card): clouds that thicken with the cloud cover and grey out the sky,
  rain (light to heavy, slanted by the wind) with a wet darker road, snow flakes, fog / mist, thunderstorms with lightning flashes, strong wind
  (fast clouds, wind streaks, slanted rain and snow, the car body rocks a little). Head lights switch on by themselves in rain, storms and fog (Car lights = Automatic).
- Tap the weather pill on the Car page to preview Clear / Cloudy / Rain / Storm / Snow / Fog / Windy, and once more to go back to the live weather.
  Settings > Day & night > "Weather in the car page sky" turns the effects off.
- build.sh now signs with ./debug.keystore when it is next to it (so every build is signed with the same key and installs as an update).

v2.10.1: bottom pill sits lower (smaller margin / padding) and the whole 3D scene is lifted a little (CAR_LIFT in Car3DView) so the car clears the dock.

v2.11 (shared locations)
- Receive a location from Google Maps (Share > Mika Maps), WhatsApp / Telegram location messages (geo: links), tapped Google Maps links and
  google.navigation: intents: the map opens on the place with a pin and the usual Directions / Save / Clear card. Short links (maps.app.goo.gl,
  goo.gl/maps) are followed to find the coordinates; if that fails it falls back to a search by the place name.
- Paste anything into the map search box: a Maps link, "30.0444, 31.2357", degrees-minutes-seconds, Arabic digits - it goes straight to the map.
  "Where to?" on the home screen accepts the same and starts driving right away.
- New: MapLink.java (parser, pure Java). MapActivity is now exported + singleTop with intent filters in AndroidManifest.xml.

v2.12 (share-location fix)
- Short Google Maps links (maps.app.goo.gl/..., with or without ?g_st=...) now resolve reliably: LinkResolver.java tries several browser identities,
  follows HTTP redirects and redirects hidden inside the page, skips the cookie-consent wall and reads coordinates from the URL or the page.
- If a link only gives a place name, search uses name + address, with Nominatim then Photon as fallback.

v2.13
- Fixed: the pin landed next to the user instead of at the shared place. Page scans no longer use the map viewport centre
  (which Google centres on the viewer). Short links are read first as a link-preview page (map centred on the place itself).
