package com.mika.launcher;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;

/** Card background: blurred album art (centre-cropped) under a theme-coloured scrim, with rounded corners. */
final class ArtBg extends Drawable {
    private final Bitmap bmp;
    private final float radius;
    private final boolean dark;
    private final int strokeColor;
    private final float strokeW;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint scrim = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path clip = new Path();
    private final RectF rect = new RectF();
    private final Rect src = new Rect();

    ArtBg(Bitmap blurred, float radiusPx, boolean dark, int strokeColor, float strokePx) {
        bmp = blurred;
        radius = radiusPx;
        this.dark = dark;
        this.strokeColor = strokeColor;
        strokeW = strokePx;
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(strokePx);
        stroke.setColor(strokeColor);
    }

    @Override
    protected void onBoundsChange(Rect b) {
        rect.set(b);
        clip.reset();
        clip.addRoundRect(rect, radius, radius, Path.Direction.CW);
        // centre-crop source rect
        float bw = bmp.getWidth(), bh = bmp.getHeight();
        float s = Math.max(b.width() / bw, b.height() / bh);
        int sw = Math.round(b.width() / s), sh = Math.round(b.height() / s);
        int sx = Math.max(0, (int) ((bw - sw) / 2)), sy = Math.max(0, (int) ((bh - sh) / 2));
        src.set(sx, sy, Math.min((int) bw, sx + sw), Math.min((int) bh, sy + sh));
        int top = dark ? 0x77000000 : 0x88FFFFFF, bot = dark ? 0xC0000000 : 0xDDFFFFFF;
        scrim.setShader(new LinearGradient(0, b.top, 0, b.bottom, top, bot, Shader.TileMode.CLAMP));
    }

    @Override
    public void draw(Canvas c) {
        int sv = c.save();
        c.clipPath(clip);
        c.drawBitmap(bmp, src, rect, paint);
        c.drawRect(rect, scrim);
        c.restoreToCount(sv);
        if (strokeW > 0) {
            float h = strokeW / 2f;
            c.drawRoundRect(new RectF(rect.left + h, rect.top + h, rect.right - h, rect.bottom - h), radius, radius, stroke);
        }
    }

    @Override
    public void setAlpha(int a) {
        paint.setAlpha(a);
    }

    @Override
    public void setColorFilter(ColorFilter cf) {
        paint.setColorFilter(cf);
    }

    @Override
    public int getOpacity() {
        return PixelFormat.TRANSLUCENT;
    }
}
