package com.mika.launcher;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextClock;
import android.widget.TextView;

/**
 * Home-screen "Car" slide, full screen: the 3D car (sky, weather, road) edge to edge with a light HUD on top:
 * speed + clock + page buttons (top left), weather / day-night / driving pills (top right) and one glass pill
 * at the bottom with the apps button, your pinned apps and, when something is playing, the now-playing controls.
 */
final class CarPage extends FrameLayout {
    interface Host {
        void openDrawer();

        void showHome();

        void openMusic();

        void openLayout();

        void resize();

        void openSettings();

        /** 0 = previous, 1 = play / pause, 2 = next. */
        void mediaAction(int action);

        void openPlayer();
    }

    /** Preview presets for the weather pill: {name, WMO code, wind km/h}. */
    private static final String[] WX_NAME = {"Clear", "Cloudy", "Rain", "Storm", "Snow", "Fog", "Windy"};
    private static final int[] WX_CODE = {0, 3, 65, 95, 75, 45, 1};
    private static final float[] WX_WIND = {5f, 12f, 18f, 48f, 10f, 5f, 58f};

    private final Host host;
    private final Car3DView gl;
    private final TextView tvSpeed, tvUnit, tvState, tvSky, tvWx, tvStatus, tvTitle, tvArtist;
    private final TextClock clock;
    private final LinearLayout pill, dock, nowGroup;
    private final View divider, btnPlay;
    private final ImageView ivArt;
    private final Bar bar;
    private final int accent, sideMargin;
    private final float sc;
    private boolean moving = false;
    private boolean active = false;
    private boolean resumed = false;

    // weather
    private int liveCode = -1;
    private float liveWind = 0f;
    private String liveTemp = "";

    // now playing (cached so repeated pushes don't relayout)
    private boolean nowInit = false, hasNow = false, nowPlaying = false;
    private String nowTitle = "", nowArtist = "";
    private Bitmap nowArt = null;

    CarPage(Context c, Pal pal, Host h) {
        super(c);
        host = h;
        accent = pal.accent;
        DisplayMetrics dm = c.getResources().getDisplayMetrics();
        float shortDp = Math.min(dm.widthPixels, dm.heightPixels) / dm.density;
        sc = Math.max(0.85f, Math.min(1.25f, shortDp / 400f));
        int edge = Prefs.i(c, "edge", -1);
        sideMargin = Math.max(s(18), edge >= 0 ? Ui.dp(c, edge) : 0);
        int topMargin = Math.max(s(14), edge >= 0 ? Ui.dp(c, edge) : 0);

        gl = new Car3DView(c, pal.accent);
        addView(gl, new FrameLayout.LayoutParams(-1, -1));

        // ------------------------------------------------ top left: speed, clock, status, page buttons
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        tvSpeed = hud(Ui.text(c, "0", 54, 0xFFFFFFFF));
        tvSpeed.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        tvSpeed.setIncludeFontPadding(false);
        tvUnit = hud(Ui.text(c, "km/h", 15, 0xCCFFFFFF));
        col.addView(tvSpeed);
        col.addView(tvUnit);

        clock = new TextClock(c);
        String fmt = Prefs.b(c, "h24", true) ? "HH:mm" : "h:mm a";
        clock.setFormat24Hour(fmt);
        clock.setFormat12Hour(fmt);
        clock.setTextSize(24);
        clock.setTextColor(0xFFFFFFFF);
        clock.setTypeface(Typeface.DEFAULT_BOLD);
        clock.setIncludeFontPadding(false);
        hud(clock);
        LinearLayout.LayoutParams ckl = new LinearLayout.LayoutParams(-2, -2);
        ckl.topMargin = s(12);
        col.addView(clock, ckl);

        tvStatus = hud(Ui.text(c, "", 12, 0xCCFFFFFF));
        col.addView(tvStatus);

        LinearLayout btns = new LinearLayout(c);
        btns.setGravity(Gravity.CENTER_VERTICAL);
        btns.addView(pageBtn(Icons.CAR, true, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                host.showHome();
            }
        }, null));
        btns.addView(pageBtn(Icons.MUSIC, false, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                host.openMusic();
            }
        }, null));
        btns.addView(pageBtn(Icons.LAYOUT, false, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                host.openLayout();
            }
        }, new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                host.resize();
                return true;
            }
        }));
        btns.addView(pageBtn(Icons.GEAR, false, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                host.openSettings();
            }
        }, new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                host.resize();
                return true;
            }
        }));
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-2, -2);
        bl.topMargin = s(12);
        col.addView(btns, bl);
        FrameLayout.LayoutParams cl = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.LEFT);
        cl.leftMargin = sideMargin;
        cl.topMargin = topMargin;
        addView(col, cl);

        // ------------------------------------------------ top right: weather / sky / driving pills
        LinearLayout pills = new LinearLayout(c);
        pills.setGravity(Gravity.CENTER_VERTICAL);
        tvWx = topPill(c);
        tvSky = topPill(c);
        tvState = topPill(c);
        pills.addView(tvWx);
        LinearLayout.LayoutParams gap = new LinearLayout.LayoutParams(-2, -2);
        gap.leftMargin = s(8);
        pills.addView(tvSky, gap);
        LinearLayout.LayoutParams gap2 = new LinearLayout.LayoutParams(-2, -2);
        gap2.leftMargin = s(8);
        pills.addView(tvState, gap2);
        FrameLayout.LayoutParams pl = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.RIGHT);
        pl.rightMargin = sideMargin;
        pl.topMargin = topMargin;
        addView(pills, pl);

        tvSky.setText(SkyClock.label(c));
        tvSky.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Context cx = getContext();
                Prefs.putI(cx, "skyMode", (SkyClock.mode(cx) + 1) % 3);
                tvSky.setText(SkyClock.label(cx));
                gl.skyChanged();
            }
        });
        // weather pill: tap to preview Live -> Clear -> Cloudy -> Rain -> Storm -> Snow -> Fog -> Windy
        tvWx.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Context cx = getContext();
                Prefs.putI(cx, "carWx", (Prefs.i(cx, "carWx", 0) + 1) % (WX_NAME.length + 1));
                applyWeather();
            }
        });

        // ------------------------------------------------ bottom: one glass pill
        pill = new LinearLayout(c);
        pill.setGravity(Gravity.CENTER_VERTICAL);
        pill.setPadding(s(10), s(6), s(10), s(6));
        pill.setBackground(Ui.glass(c, 0x8C22252D, 0x30FFFFFF, 40));

        View apps = Ui.iconButton(c, Icons.APPS, 48, 24, accent, 0xFFFFFFFF);
        apps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                host.openDrawer();
            }
        });
        LinearLayout.LayoutParams al = new LinearLayout.LayoutParams(s(48), s(48));
        al.rightMargin = s(6);
        pill.addView(apps, al);

        dock = new LinearLayout(c);
        dock.setGravity(Gravity.CENTER_VERTICAL);
        pill.addView(dock, new LinearLayout.LayoutParams(-2, -2));

        divider = new View(c);
        divider.setBackgroundColor(0x33FFFFFF);
        LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(Math.max(1, Ui.dp(c, 1)), s(44));
        dl.leftMargin = s(10);
        dl.rightMargin = s(12);
        pill.addView(divider, dl);

        // now playing: [cover][title / artist] + progress, then the controls
        nowGroup = new LinearLayout(c);
        nowGroup.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout left = new LinearLayout(c);
        left.setOrientation(LinearLayout.VERTICAL);
        LinearLayout top = new LinearLayout(c);
        top.setGravity(Gravity.CENTER_VERTICAL);
        ivArt = new ImageView(c);
        ivArt.setScaleType(ImageView.ScaleType.CENTER_CROP);
        ivArt.setBackground(Ui.pill(c, 0x33FFFFFF, 12));
        ivArt.setClipToOutline(true);
        top.addView(ivArt, new LinearLayout.LayoutParams(s(46), s(46)));
        LinearLayout tcol = new LinearLayout(c);
        tcol.setOrientation(LinearLayout.VERTICAL);
        tvTitle = Ui.text(c, "", 15, 0xFFFFFFFF);
        tvTitle.setTypeface(Typeface.DEFAULT_BOLD);
        tvTitle.setSingleLine(true);
        tvTitle.setEllipsize(android.text.TextUtils.TruncateAt.MARQUEE);
        tvTitle.setMarqueeRepeatLimit(-1);
        tvTitle.setSelected(true);
        tvArtist = Ui.text(c, "", 12, 0xCCFFFFFF);
        tvArtist.setSingleLine(true);
        tvArtist.setEllipsize(android.text.TextUtils.TruncateAt.END);
        tcol.addView(tvTitle);
        tcol.addView(tvArtist);
        LinearLayout.LayoutParams tcl = new LinearLayout.LayoutParams(0, -2, 1f);
        tcl.leftMargin = s(12);
        top.addView(tcol, tcl);
        left.addView(top, new LinearLayout.LayoutParams(-1, -2));
        bar = new Bar(c, accent);
        LinearLayout.LayoutParams barl = new LinearLayout.LayoutParams(-1, Math.max(3, Ui.dp(c, 3)));
        barl.topMargin = s(6);
        left.addView(bar, barl);
        nowGroup.addView(left, new LinearLayout.LayoutParams(0, -2, 1f));
        View.OnClickListener open = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                host.openPlayer();
            }
        };
        left.setOnClickListener(open);

        LinearLayout ctrl = new LinearLayout(c);
        ctrl.setGravity(Gravity.CENTER_VERTICAL);
        ctrl.addView(ctlBtn(Icons.PREV, 38, 18, false, 0));
        btnPlay = ctlBtn(Icons.PLAY, 46, 22, true, 1);
        ctrl.addView(btnPlay);
        ctrl.addView(ctlBtn(Icons.NEXT, 38, 18, false, 2));
        LinearLayout.LayoutParams ctl = new LinearLayout.LayoutParams(-2, -2);
        ctl.leftMargin = s(12);
        nowGroup.addView(ctrl, ctl);
        pill.addView(nowGroup, new LinearLayout.LayoutParams(0, -2, 1f));

        FrameLayout.LayoutParams pil = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        pil.bottomMargin = Math.max(s(8), edge >= 0 ? Ui.dp(c, edge) : 0);
        addView(pill, pil);
        setNowPlaying(false, "", "", null, false);

        paintState();
        applyWeather();
    }

    private int s(int dp) {
        return Ui.dp(getContext(), Math.round(dp * sc));
    }

    private TextView hud(TextView t) {
        t.setShadowLayer(Ui.dp(getContext(), 3), 0f, Ui.dp(getContext(), 1), 0x99000000);
        return t;
    }

    private TextView topPill(Context c) {
        TextView t = Ui.text(c, "", 13, 0xFFFFFFFF);
        t.setGravity(Gravity.CENTER);
        t.setSingleLine(true);
        t.setPadding(s(14), s(7), s(14), s(7));
        t.setBackground(Ui.pill(c, 0x66000000, 18));
        return t;
    }

    private View pageBtn(int icon, boolean on, View.OnClickListener l, View.OnLongClickListener ll) {
        View b = Ui.iconButton(getContext(), icon, 42, 22, on ? accent : 0x52000000, 0xFFFFFFFF);
        b.setOnClickListener(l);
        if (ll != null) b.setOnLongClickListener(ll);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(s(42), s(42));
        lp.rightMargin = s(8);
        b.setLayoutParams(lp);
        return b;
    }

    private View ctlBtn(int icon, int size, int iconDp, boolean primary, final int action) {
        View b = Ui.iconButton(getContext(), icon, size, iconDp, primary ? accent : 0x40FFFFFF, 0xFFFFFFFF);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(s(size), s(size));
        lp.leftMargin = s(3);
        lp.rightMargin = s(3);
        b.setLayoutParams(lp);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                host.mediaAction(action);
            }
        });
        return b;
    }

    // ------------------------------------------------------------------ API for MainActivity
    /** The container for the pinned-app icons inside the bottom pill. */
    LinearLayout dockView() {
        return dock;
    }

    /** Re-sizes the app cells to the pill (called after the cells are added). */
    int cellSizeDp() {
        return Math.round(44 * sc);
    }

    void setStatus(String s) {
        tvStatus.setText(s);
    }

    /** What is playing now; hidden when nothing is. */
    void setNowPlaying(boolean has, String title, String artist, Bitmap art, boolean playing) {
        if (title == null) title = "";
        if (artist == null) artist = "";
        boolean same = nowInit && has == hasNow && playing == nowPlaying && art == nowArt
                && title.equals(nowTitle) && artist.equals(nowArtist);
        if (same) return;
        boolean visChanged = !nowInit || has != hasNow;
        nowInit = true;
        hasNow = has;
        nowPlaying = playing;
        nowTitle = title;
        nowArtist = artist;
        nowArt = art;
        tvTitle.setText(title);
        tvArtist.setText(artist);
        tvArtist.setVisibility(artist.length() == 0 ? View.GONE : View.VISIBLE);
        if (art == null) ivArt.setImageDrawable(null);
        else ivArt.setImageBitmap(art);
        Ui.setIcon(btnPlay, playing ? Icons.PAUSE : Icons.PLAY, 0xFFFFFFFF);
        if (visChanged) {
            nowGroup.setVisibility(has ? View.VISIBLE : View.GONE);
            divider.setVisibility(has ? View.VISIBLE : View.GONE);
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) pill.getLayoutParams();
            if (has) {
                lp.width = -1;
                lp.leftMargin = Math.max(s(18), sideMargin);
                lp.rightMargin = Math.max(s(18), sideMargin);
            } else {
                lp.width = -2;
                lp.leftMargin = 0;
                lp.rightMargin = 0;
            }
            pill.setLayoutParams(lp);
        }
    }

    /** Playback position in thousandths (0..1000). */
    void setProgress(int permille) {
        bar.set(permille / 1000f);
    }

    /** Live weather from the forecast: WMO code, wind in km/h and a short temperature text like "18°C". */
    void setLiveWeather(int code, float windKmh, String temp) {
        liveCode = code;
        liveWind = windKmh;
        liveTemp = temp == null ? "" : temp;
        applyWeather();
    }

    /** Picks live weather or the preview chosen with the weather pill, and tells the 3D scene. */
    void applyWeather() {
        Context c = getContext();
        int ov = Prefs.i(c, "carWx", 0);
        boolean fx = Prefs.b(c, "carWxFx", true);
        int code = 0;
        float wind = 0f;
        String label;
        if (ov > 0 && ov <= WX_NAME.length) {
            code = WX_CODE[ov - 1];
            wind = WX_WIND[ov - 1];
            label = WeatherClient.emoji(code, true) + " " + WX_NAME[ov - 1] + " \u00B7 preview";
        } else if (liveCode >= 0) {
            code = liveCode;
            wind = liveWind;
            label = WeatherClient.emoji(code, true) + " " + WeatherClient.describe(code)
                    + (liveTemp.length() > 0 ? " \u00B7 " + liveTemp : "")
                    + (wind >= 40f ? " \u00B7 Windy" : "");
        } else {
            label = "Weather";
        }
        tvWx.setText(label);
        gl.setWeather(fx ? code : 0, fx ? wind : 0f);
    }

    /** Kept for HomePager: nothing to re-sample any more now that the page is full screen. */
    void onSlide() {
    }

    private void paintState() {
        tvState.setText(moving ? "Driving" : "Parked");
        tvState.setBackground(Ui.pill(getContext(), moving ? accent : 0x66000000, 18));
    }

    /** speedMs: GPS speed in m/s (0 when there is no fix). */
    void setSpeed(float speedMs, boolean mph) {
        gl.setSpeed(speedMs);
        float shown = speedMs * (mph ? 2.23694f : 3.6f);
        boolean mv = speedMs >= 0.8f;
        tvSpeed.setText(String.valueOf(mv ? Math.round(shown) : 0));
        tvUnit.setText(mph ? "mph" : "km/h");
        if (mv != moving) {
            moving = mv;
            paintState();
        }
    }

    /** True while the Car page is the visible slide: only then does the GL view render continuously. */
    void setActive(boolean on) {
        active = on;
        gl.setActive(on && resumed);
    }

    void onHostResume() {
        resumed = true;
        tvSky.setText(SkyClock.label(getContext()));
        applyWeather();
        gl.skyChanged();
        gl.onResume();
        gl.setActive(active);
    }

    void onHostPause() {
        resumed = false;
        gl.setActive(false);
        gl.onPause();
    }

    /** Thin rounded progress line. */
    private static final class Bar extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();
        private final int fill;
        private float f = 0f;

        Bar(Context c, int fill) {
            super(c);
            this.fill = fill;
        }

        void set(float v) {
            v = Math.max(0f, Math.min(1f, v));
            if (Math.abs(v - f) < 0.001f) return;
            f = v;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight(), rad = h / 2f;
            p.setColor(0x40FFFFFF);
            r.set(0, 0, w, h);
            cv.drawRoundRect(r, rad, rad, p);
            if (f > 0f) {
                p.setColor(fill);
                r.set(0, 0, Math.max(h, w * f), h);
                cv.drawRoundRect(r, rad, rad, p);
            }
        }
    }
}
