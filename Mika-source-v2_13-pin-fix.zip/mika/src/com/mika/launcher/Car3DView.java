package com.mika.launcher;

import android.content.Context;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import android.os.SystemClock;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/**
 * OpenGL ES 2.0 view of the user's car (assets/car.glb). Speed-driven: the wheels spin, the road
 * scrolls and the body settles with the GPS speed, and everything eases to a halt when the car stops.
 */
class Car3DView extends GLSurfaceView implements GLSurfaceView.Renderer {
    private static final String CAR_VS =
            "uniform mat4 uVP; uniform mat4 uM;\n"
                    + "attribute vec3 aPos; attribute vec3 aNrm; attribute vec4 aCol;\n"
                    + "varying vec3 vN; varying vec3 vP; varying vec4 vC;\n"
                    + "void main(){ vec4 w = uM*vec4(aPos,1.0); vP = w.xyz; vN = (uM*vec4(aNrm,0.0)).xyz; vC = aCol;\n"
                    + "  gl_Position = uVP*w; }\n";
    private static final String CAR_FS =
            "precision mediump float;\n"
                    + "uniform vec3 uEye; uniform vec3 uAccent; uniform float uDay; uniform float uLights; uniform vec3 uSky;\n"
                    + "varying vec3 vN; varying vec3 vP; varying vec4 vC;\n"
                    + "void main(){\n"
                    + "  vec3 n = normalize(vN); vec3 v = normalize(uEye - vP);\n"
                    + "  if (dot(n, v) < 0.0) n = -n;\n"
                    + "  vec3 l = normalize(vec3(0.45, 0.85, 0.35));\n"
                    + "  float d = max(dot(n, l), 0.0) * (0.72 + 0.34 * uDay);\n"
                    + "  float fill = max(dot(n, normalize(vec3(-0.7, 0.25, -0.6))), 0.0) * 0.22;\n"
                    + "  float hemi = (0.34 + 0.16 * n.y) * (0.88 + 0.30 * uDay);\n"
                    + "  vec3 amb = mix(vec3(1.0), uSky * 1.5 + 0.1, 0.22);\n"
                    + "  vec3 h = normalize(l + v);\n"
                    + "  float sp = pow(max(dot(n, h), 0.0), 40.0) * (0.75 + 0.25 * uDay);\n"
                    + "  float lum = dot(vC.rgb, vec3(0.3, 0.59, 0.11));\n"
                    + "  float gloss = 0.25 + 0.5 * (1.0 - lum);\n"
                    + "  float rim = pow(1.0 - max(dot(n, v), 0.0), 3.0);\n"
                    + "  vec3 col = vC.rgb * (hemi * amb + d * 0.85 + fill) + vec3(sp * gloss) + uAccent * rim * 0.28;\n"
                    + "  if (vC.a > 0.5) {\n"
                    + "    vec3 lamp = vC.a > 1.5 ? vec3(1.0, 0.10, 0.06) : vec3(1.0, 0.95, 0.80);\n"
                    + "    col = mix(col, lamp, 0.10 + 0.80 * uLights) + lamp * uLights * 0.9;\n"
                    + "  }\n"
                    + "  gl_FragColor = vec4(col, 1.0);\n"
                    + "}\n";
    private static final String GND_VS =
            "uniform mat4 uVP; attribute vec3 aPos; varying vec3 vP;\n"
                    + "void main(){ vP = aPos; gl_Position = uVP*vec4(aPos,1.0); }\n";
    private static final String GND_FS =
            "#ifdef GL_FRAGMENT_PRECISION_HIGH\nprecision highp float;\n#else\nprecision mediump float;\n#endif\n"
                    + "uniform float uScroll; uniform vec3 uEye; uniform vec3 uAccent; uniform vec3 uFog; uniform vec3 uAsphalt;\n"
                    + "uniform float uLights; uniform vec2 uHead; uniform vec2 uTail;\n"
                    + "uniform float uMist; uniform float uWet; uniform float uFlash;\n"
                    + "varying vec3 vP;\n"
                    + "void main(){\n"
                    + "  vec2 p = vP.xz; float az = abs(p.y);\n"
                    + "  float road = 1.0 - smoothstep(5.3, 5.7, az);\n"
                    + "  vec3 col = mix(uAsphalt * 0.55, uAsphalt, road);\n"
                    + "  float band = 0.5 + 0.5 * sin((p.x + uScroll) * 2.0943951);\n"
                    + "  col *= 0.96 + 0.04 * band * road;\n"
                    + "  float dash = step(mod(p.x + uScroll, 6.0), 3.0);\n"
                    + "  float ll = (1.0 - smoothstep(0.06, 0.11, abs(az - 2.75))) * dash;\n"
                    + "  col = mix(col, vec3(0.86), ll * 0.85);\n"
                    + "  float e = abs(az - 5.15);\n"
                    + "  col += uAccent * 0.30 * exp(-e * 4.0);\n"
                    + "  col = mix(col, uAccent, (1.0 - smoothstep(0.05, 0.13, e)) * 0.95);\n"
                    + "  float d = length(vec2(p.x / 2.9, p.y / 1.25));\n"
                    + "  col *= mix(0.25, 1.0, smoothstep(0.7, 1.3, d));\n"
                    + "  col *= 1.0 - 0.22 * uWet;\n"
                    // head-light beams in front of the car, red glow behind it
                    + "  vec3 add = vec3(0.0);\n"
                    + "  for (int i = 0; i < 2; i++) {\n"
                    + "    float sg = i == 0 ? -1.0 : 1.0;\n"
                    + "    float t = max(p.x - uHead.x, 0.0);\n"
                    + "    float w = 0.34 + 0.22 * t;\n"
                    + "    float lat = p.y - (sg * uHead.y + sg * 0.05 * t);\n"
                    + "    float beam = exp(-(lat * lat) / (w * w)) * exp(-t * 0.10) * smoothstep(-0.3, 0.8, p.x - uHead.x);\n"
                    + "    add += vec3(1.0, 0.93, 0.74) * beam * 0.80;\n"
                    + "    float tt = max(uTail.x - p.x, 0.0);\n"
                    + "    float wt = 0.30 + 0.24 * tt;\n"
                    + "    float latT = p.y - sg * uTail.y;\n"
                    + "    float tail = exp(-(latT * latT) / (wt * wt)) * exp(-tt * 0.55) * smoothstep(-0.3, 0.5, uTail.x - p.x);\n"
                    + "    add += vec3(1.0, 0.10, 0.06) * tail * 0.50;\n"
                    + "  }\n"
                    + "  col += add * uLights * (1.0 + 0.9 * uWet);\n"
                    + "  col += vec3(0.30, 0.32, 0.45) * uFlash * 0.45;\n"
                    + "  float dist = length(vP - uEye);\n"
                    + "  col = mix(col, uFog, smoothstep(10.0 - 7.0 * uMist, 150.0 - 128.0 * uMist, dist));\n"
                    + "  gl_FragColor = vec4(col, 1.0);\n"
                    + "}\n";
    private static final String SKY_VS =
            "attribute vec2 aPos; void main(){ gl_Position = vec4(aPos, 0.999, 1.0); }\n";
    private static final String SKY_FS =
            "#ifdef GL_FRAGMENT_PRECISION_HIGH\nprecision highp float;\n#else\nprecision mediump float;\n#endif\n"
                    + "uniform vec2 uRes; uniform vec3 uTop; uniform vec3 uFog;\n"
                    + "uniform float uDay; uniform float uTwi; uniform float uTime; uniform float uHor;\n"
                    + "uniform float uCloud; uniform float uRainy; uniform float uCT; uniform float uFlash;\n"
                    + "float hash(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }\n"
                    + "float vnoise(vec2 p){ vec2 i = floor(p); vec2 f = fract(p); f = f * f * (3.0 - 2.0 * f);\n"
                    + "  return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), f.x), mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), f.x), f.y); }\n"
                    + "void main(){\n"
                    + "  vec2 p = gl_FragCoord.xy; float v = p.y / uRes.y;\n"
                    + "  float s = clamp((v - uHor) / (1.0 - uHor), 0.0, 1.0);\n"      // 0 at the horizon, 1 at the top
                    + "  vec3 col = mix(uFog, uTop, pow(s, 0.65));\n"
                    + "  float night = 1.0 - uDay;\n"
                    + "  float up = smoothstep(0.10, 0.45, s);\n"
                    // stars
                    + "  vec2 g = p / (uRes.y * 0.040); vec2 id = floor(g); vec2 f = fract(g);\n"
                    + "  float h = hash(id);\n"
                    + "  vec2 sp = vec2(hash(id + 3.7), hash(id + 9.1)) * 0.6 + 0.2;\n"
                    + "  float star = step(0.88, h) * (1.0 - smoothstep(0.0, 0.11, length(f - sp)));\n"
                    + "  col += vec3(0.9, 0.95, 1.0) * star * (0.65 + 0.35 * sin(uTime * 2.0 + h * 60.0)) * night * night * up * (1.0 - uCloud);\n"
                    // moon
                    + "  vec2 mc = vec2(0.78 * uRes.x, (uHor + 0.04 + 0.20 * night) * uRes.y);\n"
                    + "  float mr = length(p - mc) / uRes.y;\n"
                    + "  float moonW = (1.0 - smoothstep(0.2, 0.85, uDay)) * (1.0 - 0.92 * uCloud);\n"
                    + "  float disc = 1.0 - smoothstep(0.040, 0.044, mr);\n"
                    + "  float cut = 1.0 - smoothstep(0.036, 0.040, length(p - (mc + vec2(0.020, 0.010) * uRes.y)) / uRes.y);\n"
                    + "  col += vec3(0.86, 0.91, 1.0) * disc * (1.0 - 0.8 * cut) * moonW;\n"
                    + "  col += vec3(0.45, 0.55, 0.85) * exp(-mr * 16.0) * 0.22 * moonW;\n"
                    // sun
                    + "  vec2 sc = vec2(0.78 * uRes.x, (uHor + 0.04 + 0.20 * uDay) * uRes.y);\n"
                    + "  float sr = length(p - sc) / uRes.y;\n"
                    + "  float sunW = smoothstep(0.10, 0.60, uDay) * (1.0 - 0.93 * uCloud);\n"
                    + "  vec3 sunCol = mix(vec3(1.0, 0.52, 0.22), vec3(1.0, 0.96, 0.80), uDay);\n"
                    + "  col += sunCol * ((1.0 - smoothstep(0.046, 0.052, sr)) + exp(-sr * 8.0) * 0.60) * sunW;\n"
                    // clouds
                    + "  vec2 cuv = vec2(p.x / uRes.y * 1.6 + uCT, v * 5.0);\n"
                    + "  float cn = vnoise(cuv * vec2(1.0, 1.6)) * 0.6 + vnoise(cuv * 2.3 + 7.0 + vec2(uCT * 0.7, 0.0)) * 0.4;\n"
                    + "  float thr = mix(0.55, 0.20, uCloud);\n"
                    + "  float cl = smoothstep(thr, thr + mix(0.25, 0.32, uCloud), cn);\n"
                    + "  cl *= smoothstep(mix(0.10, 0.0, uCloud), mix(0.30, 0.14, uCloud), s) * (1.0 - 0.6 * (1.0 - uCloud) * smoothstep(0.75, 1.0, s));\n"
                    + "  vec3 ccDay = mix(mix(vec3(0.96, 0.97, 1.0), vec3(1.0, 0.72, 0.55), uTwi), vec3(0.40, 0.43, 0.49), uRainy * 0.85);\n"
                    + "  vec3 ccNight = vec3(0.075, 0.09, 0.14) + vec3(0.06, 0.07, 0.10) * cn;\n"
                    + "  vec3 cc = mix(ccNight, ccDay, uDay) * (0.84 + 0.30 * cn);\n"
                    + "  float ca = uDay * mix(0.62, 0.95, uCloud) + night * 0.90 * smoothstep(0.15, 0.50, uCloud);\n"
                    + "  col = mix(col, cc, cl * ca);\n"
                    + "  col += vec3(0.62, 0.68, 1.0) * uFlash * (0.20 + 0.70 * cl);\n"
                    // distant hills melt the sky into the road haze
                    + "  float nx = p.x / uRes.y;\n"
                    + "  float h1 = 0.034 + 0.018 * sin(nx * 3.1 + 1.3) + 0.010 * sin(nx * 7.3 + 4.0) + 0.005 * sin(nx * 13.0);\n"
                    + "  float far = 1.0 - smoothstep(0.0, 0.004, v - (uHor + h1));\n"
                    + "  col = mix(col, mix(uFog, uTop * 0.55, 0.42), far);\n"
                    + "  float h2 = 0.012 + 0.011 * sin(nx * 4.7 + 0.4) + 0.006 * sin(nx * 10.0 + 2.0);\n"
                    + "  float nr = 1.0 - smoothstep(0.0, 0.004, v - (uHor + h2));\n"
                    + "  col = mix(col, mix(uFog, uTop * 0.40, 0.55), nr);\n"
                    // town lights on the hills at night
                    + "  float win = step(0.93, hash(floor(p / (uRes.y * 0.012)))) * far * night * smoothstep(0.003, 0.012, v - uHor);\n"
                    + "  col += vec3(1.0, 0.85, 0.5) * win * 0.55;\n"
                    + "  gl_FragColor = vec4(col, 1.0); }\n";
    private static final String PRE_VS =
            "attribute vec2 aPos; void main(){ gl_Position = vec4(aPos, 0.0, 1.0); }\n";
    private static final String PRE_FS =
            "#ifdef GL_FRAGMENT_PRECISION_HIGH\nprecision highp float;\n#else\nprecision mediump float;\n#endif\n"
                    + "uniform vec2 uRes; uniform float uT; uniform float uRain; uniform float uSnow; uniform float uWind;\n"
                    + "uniform float uWT; uniform float uDay; uniform float uMist; uniform vec3 uFog;\n"
                    + "float hash(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }\n"
                    // slanted rain streak layer
                    + "float rainL(vec2 p, float sc, float spd, float len, float slant, float dens){\n"
                    + "  vec2 uv = p / uRes.y; uv.x += uv.y * slant;\n"
                    + "  vec2 g = vec2(uv.x * sc, uv.y * sc * 0.16); g.y += uT * spd;\n"
                    + "  vec2 id = floor(g); vec2 f = fract(g);\n"
                    + "  float on = step(hash(id), dens);\n"
                    + "  float hx = 0.15 + 0.7 * hash(id + 4.3);\n"
                    + "  float y0 = hash(id + 8.9) * (1.0 - len);\n"
                    + "  float ln = 1.0 - smoothstep(0.0, 0.10, abs(f.x - hx));\n"
                    + "  float inside = step(y0, f.y) * step(f.y, y0 + len);\n"
                    + "  float fade = 1.0 - (f.y - y0) / len;\n"
                    + "  return on * ln * inside * clamp(fade, 0.0, 1.0); }\n"
                    // soft snow flakes
                    + "float snowL(vec2 p, float sc, float spd, float sz, float slant, float dens){\n"
                    + "  vec2 uv = p / uRes.y; uv.x += uv.y * slant;\n"
                    + "  vec2 g = uv * sc; g.y += uT * spd;\n"
                    + "  vec2 id = floor(g); vec2 f = fract(g);\n"
                    + "  float h = hash(id); float on = step(h, dens);\n"
                    + "  vec2 c = 0.5 + 0.30 * vec2(sin(uT * 1.1 + h * 40.0), sin(uT * 0.8 + h * 17.0));\n"
                    + "  return on * (1.0 - smoothstep(sz * 0.5, sz, length(f - c))); }\n"
                    // long horizontal wind streaks
                    + "float windL(vec2 p, float rows, float spd, float len, float dens, float seed){\n"
                    + "  vec2 uv = p / uRes.y;\n"
                    + "  vec2 g = vec2(uv.x * 0.9 - uWT * spd, uv.y * rows);\n"
                    + "  vec2 id = floor(g); vec2 f = fract(g);\n"
                    + "  float on = step(hash(id + seed), dens);\n"
                    + "  float x0 = hash(id + 3.1) * (1.0 - len);\n"
                    + "  float yc = 0.2 + 0.6 * hash(id + 7.7);\n"
                    + "  float ln = 1.0 - smoothstep(0.0, 0.05, abs(f.y - yc));\n"
                    + "  float t = (f.x - x0) / len;\n"
                    + "  float inside = step(0.0, t) * step(t, 1.0);\n"
                    + "  return on * ln * inside * sin(3.14159 * clamp(t, 0.0, 1.0)); }\n"
                    + "void main(){\n"
                    + "  vec2 p = gl_FragCoord.xy;\n"
                    + "  float slant = 0.08 + 0.55 * uWind;\n"
                    + "  float ra = 0.0;\n"
                    + "  if (uRain > 0.01) {\n"
                    + "    float dn = 0.22 + 0.78 * uRain;\n"
                    + "    ra = rainL(p, 120.0, 5.0, 0.35, slant, dn * 0.9) * 0.22\n"
                    + "       + rainL(p, 72.0, 7.0, 0.45, slant, dn * 0.8) * 0.34\n"
                    + "       + rainL(p, 40.0, 10.0, 0.55, slant, dn * 0.6) * 0.50;\n"
                    + "  }\n"
                    + "  float sa = 0.0;\n"
                    + "  if (uSnow > 0.01) {\n"
                    + "    float dn = 0.25 + 0.60 * uSnow;\n"
                    + "    float sl = 0.05 + 0.50 * uWind;\n"
                    + "    sa = snowL(p, 42.0, 0.35, 0.16, sl, dn * 0.6) * 0.55\n"
                    + "       + snowL(p, 26.0, 0.55, 0.20, sl, dn * 0.6) * 0.75\n"
                    + "       + snowL(p, 15.0, 0.80, 0.26, sl, dn * 0.5) * 0.95;\n"
                    + "  }\n"
                    + "  float wa = 0.0;\n"
                    + "  if (uWind > 0.05) {\n"
                    + "    wa = (windL(p, 14.0, 0.9, 0.55, 0.45, 1.0) * 0.30 + windL(p, 24.0, 1.4, 0.40, 0.40, 5.0) * 0.22) * uWind * uWind;\n"
                    + "  }\n"
                    + "  float aP = clamp(ra + sa + wa, 0.0, 1.0);\n"
                    + "  vec3 pc = vec3(0.84, 0.89, 0.97) * (0.55 + 0.45 * uDay);\n"
                    + "  float aV = uMist * 0.22;\n"
                    + "  float aT = aP + aV * (1.0 - aP);\n"
                    + "  vec3 rgb = (pc * aP + uFog * aV * (1.0 - aP)) / max(aT, 0.0001);\n"
                    + "  gl_FragColor = vec4(rgb, aT); }\n";
    private static final String GLOW_VS =
            "uniform mat4 uVP; attribute vec3 aPos; attribute vec2 aUv; varying vec2 vUv;\n"
                    + "void main(){ vUv = aUv; gl_Position = uVP * vec4(aPos, 1.0); }\n";
    private static final String GLOW_FS =
            "precision mediump float;\n"
                    + "varying vec2 vUv; uniform vec3 uCol; uniform float uA;\n"
                    + "void main(){ float d = length(vUv);\n"
                    + "  float g = (exp(-d * d * 5.0) + 0.7 * exp(-d * d * 38.0)) * (1.0 - smoothstep(0.80, 1.0, d));\n"
                    + "  gl_FragColor = vec4(uCol * g * uA, 1.0); }\n";

    private final float[] accent = new float[3];
    private final Context ctx;
    private Glb model;

    // day / night + lights (render thread)
    private float day = 1f;            // eased 0 (night) .. 1 (day)
    private float lights = 0f;         // eased 0 (off) .. 1 (on)
    private boolean dayInit = false;
    private float dayTarget = 1f, lightsTarget = 0f;
    private float dayCheck = 0f;
    private volatile boolean skyDirty = false;
    private final float[] skyTop = new float[3], skyHor = new float[3], asphalt = new float[3];

    // weather (written from the UI thread, eased on the render thread)
    private volatile int wxCode = 0;
    private volatile float wxWind = 0f; // km/h
    private boolean wxInit = false;
    private float cloud = 0f, rain = 0f, snow = 0f, mist = 0f, storm = 0f, windS = 0f;
    private float cloudT = 0f, windT = 0f, flash = 0f, flashTimer = 3f;
    private boolean flashAgain = false;
    private int lightMode = 0;
    private static final float[] N_TOP = {0.02f, 0.03f, 0.07f}, N_HOR = {0.08f, 0.10f, 0.16f}, N_ASP = {0.11f, 0.12f, 0.145f};
    private static final float[] D_TOP = {0.18f, 0.46f, 0.88f}, D_HOR = {0.70f, 0.84f, 0.96f}, D_ASP = {0.31f, 0.32f, 0.35f};
    private static final float[] T_TOP = {0.30f, 0.22f, 0.46f}, T_HOR = {0.98f, 0.52f, 0.30f};

    private static void mix3(float[] out, float[] a, float[] b, float t) {
        for (int i = 0; i < 3; i++) out[i] = a[i] + (b[i] - a[i]) * t;
    }

    // lamps (world space of the car, before bob / pitch): {x, y, z, type}; ground-light anchors
    private float[][] lamps = new float[0][];
    private float headX = 2f, headZ = 0.7f, tailX = -2.3f, tailZ = 0.6f;

    // GL state (render thread)
    private int carProg, gndProg, skyProg, glowProg, preProg;
    private FloatBuffer[] carBuf = new FloatBuffer[5];
    private int[] carCount = new int[5];
    private FloatBuffer gndBuf, skyBuf, glowBuf;
    private final float[] glowV = new float[6 * 5];
    private final float[] tmpIn = new float[4], tmpOut = new float[4];
    private final float[] proj = new float[16], view = new float[16], vp = new float[16];
    private final float[] swap = new float[16], bodyM = new float[16], wheelM = new float[16];
    private float aspect = 1.6f;
    private int vw = 1, vh = 1;
    private long lastNs = 0;
    private float speed = 0f, prevSpeed = 0f, scroll = 0f, wheelAng = 0f, time = 0f;

    // written from the UI thread
    private volatile float targetSpeed = 0f;
    private volatile long speedAt = 0L;

    Car3DView(Context c, int accentColor) {
        super(c);
        ctx = c.getApplicationContext();
        accent[0] = ((accentColor >> 16) & 0xFF) / 255f;
        accent[1] = ((accentColor >> 8) & 0xFF) / 255f;
        accent[2] = (accentColor & 0xFF) / 255f;
        try {
            InputStream in = c.getAssets().open("car.glb");
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] b = new byte[16384];
            int n;
            while ((n = in.read(b)) > 0) bo.write(b, 0, n);
            in.close();
            model = Glb.parse(bo.toByteArray());
        } catch (Throwable t) {
            model = null;
        }
        // model space (X fwd, Y left, Z up) -> world (X fwd, Y up, Z right-handed)
        Matrix.setIdentityM(swap, 0);
        swap[0] = 1; swap[1] = 0; swap[2] = 0;
        swap[4] = 0; swap[5] = 0; swap[6] = -1;
        swap[8] = 0; swap[9] = 1; swap[10] = 0;
        if (model != null) {
            lamps = model.lamps;
            float hx = -1e9f, hz = 0f, tx = 1e9f, tz = 0f;
            int hn = 0, tn = 0;
            for (float[] l : lamps) {
                if (l[3] == 1f) {
                    hx = Math.max(hx, l[0]);
                    hz += Math.abs(l[1]);
                    hn++;
                } else {
                    tx = Math.min(tx, l[0]);
                    tz += Math.abs(l[1]);
                    tn++;
                }
            }
            if (hn > 0) {
                headX = hx;
                headZ = hz / hn;
            }
            if (tn > 0) {
                tailX = tx;
                tailZ = tz / tn;
            }
        }
        setEGLContextClientVersion(2);
        setEGLConfigChooser(8, 8, 8, 0, 16, 0);
        setRenderer(this);
        setRenderMode(RENDERMODE_WHEN_DIRTY);
    }

    boolean hasModel() {
        return model != null;
    }

    /** Feed the latest GPS speed (m/s). Anything below ~3 km/h counts as standing still. */
    void setSpeed(float ms) {
        targetSpeed = ms < 0.8f ? 0f : ms;
        speedAt = SystemClock.elapsedRealtime();
    }

    /** Weather for the sky: WMO weather code (Open-Meteo) and wind speed in km/h. Pass 0 / 0 for a clear, calm sky. */
    void setWeather(int code, float windKmh) {
        wxCode = code;
        wxWind = windKmh;
    }

    /** The day / night or lights setting changed: pick it up on the next frame instead of within a second. */
    void skyChanged() {
        skyDirty = true;
    }

    /** Render continuously only while the page is on screen. */
    void setActive(boolean on) {
        setRenderMode(on ? RENDERMODE_CONTINUOUSLY : RENDERMODE_WHEN_DIRTY);
        if (on) {
            lastNs = 0;
            requestRender();
        }
    }

    // ------------------------------------------------------------------ GL
    private static int shader(int type, String src) {
        int s = GLES20.glCreateShader(type);
        GLES20.glShaderSource(s, src);
        GLES20.glCompileShader(s);
        int[] ok = new int[1];
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0);
        if (ok[0] == 0) {
            android.util.Log.e("Car3DView", "shader compile failed: " + GLES20.glGetShaderInfoLog(s));
            GLES20.glDeleteShader(s);
            return 0;
        }
        return s;
    }

    /** Returns 0 when the program could not be built (that layer is then simply skipped). */
    private static int program(String vs, String fs) {
        int v = shader(GLES20.GL_VERTEX_SHADER, vs), f = shader(GLES20.GL_FRAGMENT_SHADER, fs);
        if (v == 0 || f == 0) return 0;
        int p = GLES20.glCreateProgram();
        GLES20.glAttachShader(p, v);
        GLES20.glAttachShader(p, f);
        GLES20.glLinkProgram(p);
        int[] ok = new int[1];
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0);
        if (ok[0] == 0) {
            android.util.Log.e("Car3DView", "program link failed: " + GLES20.glGetProgramInfoLog(p));
            return 0;
        }
        return p;
    }

    private static FloatBuffer buf(float[] a) {
        FloatBuffer f = ByteBuffer.allocateDirect(a.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        f.put(a).position(0);
        return f;
    }

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        carProg = program(CAR_VS, CAR_FS);
        gndProg = program(GND_VS, GND_FS);
        skyProg = program(SKY_VS, SKY_FS);
        glowProg = program(GLOW_VS, GLOW_FS);
        preProg = program(PRE_VS, PRE_FS);
        if (model != null) {
            carBuf[0] = buf(model.body.v);
            carCount[0] = model.body.count;
            for (int i = 0; i < 4; i++) {
                carBuf[i + 1] = buf(model.wheels[i].v);
                carCount[i + 1] = model.wheels[i].count;
            }
        }
        float g = 300f;
        gndBuf = buf(new float[]{-g, 0, -g, g, 0, -g, -g, 0, g, g, 0, -g, g, 0, g, -g, 0, g});
        skyBuf = buf(new float[]{-1, -1, 1, -1, -1, 1, 1, -1, 1, 1, -1, 1});
        glowBuf = ByteBuffer.allocateDirect(glowV.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);
        GLES20.glDisable(GLES20.GL_CULL_FACE);
        lastNs = 0;
        dayInit = false;
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int w, int h) {
        vw = Math.max(1, w);
        vh = Math.max(1, h);
        GLES20.glViewport(0, 0, vw, vh);
        aspect = (float) vw / vh;
        Matrix.perspectiveM(proj, 0, FOV, aspect, 0.5f, 400f);
        proj[9] = -CAR_LIFT; // lifts the whole scene (car, road, horizon) a little so the bottom dock has room
    }

    private static final float FOV = 36f;

    @Override
    public void onDrawFrame(GL10 gl) {
        long now = System.nanoTime();
        float dt = lastNs == 0 ? 0.016f : Math.min(0.05f, (now - lastNs) / 1e9f);
        lastNs = now;
        time += dt;

        // ---- speed easing: speeds up / slows down smoothly, stops fully when the car stops
        float tgt = SystemClock.elapsedRealtime() - speedAt > 5000 ? 0f : targetSpeed;
        prevSpeed = speed;
        speed += (tgt - speed) * (1f - (float) Math.exp(-dt / 0.7f));
        if (tgt == 0f && speed < 0.05f) speed = 0f;
        float vis = 11f * (1f - (float) Math.exp(-speed / 9f)); // saturating visual speed (m/s)
        float accel = dt > 0 ? (speed - prevSpeed) / dt : 0f;
        scroll = (scroll + vis * dt) % 6f;
        wheelAng += vis * dt / (model != null ? model.wheelRadius : 0.35f);
        wheelAng %= (float) (Math.PI * 2);
        float moving = Math.min(1f, speed / 6f);

        // ---- day / night + lights (settings are read about once a second; changes ease in over ~1 s)
        dayCheck -= dt;
        if (dayCheck <= 0f || !dayInit || skyDirty) {
            dayCheck = 1f;
            skyDirty = false;
            try {
                dayTarget = SkyClock.daylight(ctx);
                int lm = Prefs.i(ctx, "carLights", 0);
                lightMode = lm;
                lightsTarget = lm == 1 ? 1f : lm == 2 ? 0f : Math.max(0f, Math.min(1f, (0.70f - dayTarget) / 0.40f));
            } catch (Throwable t) {
                dayTarget = 1f;
                lightsTarget = 0f;
            }
            if (!dayInit) {
                day = dayTarget;
                lights = lightsTarget;
                dayInit = true;
            }
        }
        // ---- weather targets from the WMO code
        int wc = wxCode;
        float tC, tR = 0f, tS = 0f, tM = 0f, tSt = 0f;
        if (wc == 0) tC = 0.04f;
        else if (wc == 1) tC = 0.18f;
        else if (wc == 2) tC = 0.50f;
        else if (wc == 3) tC = 0.88f;
        else if (wc == 45 || wc == 48) { tC = 0.75f; tM = 0.85f; }
        else if (wc >= 51 && wc <= 57) { tC = 0.85f; tR = wc == 51 ? 0.25f : wc == 53 ? 0.35f : 0.45f; }
        else if (wc >= 61 && wc <= 67) { tC = 0.95f; tR = wc == 61 ? 0.45f : wc == 63 ? 0.70f : wc == 66 ? 0.60f : 1f; }
        else if (wc >= 71 && wc <= 77) { tC = 0.90f; tS = wc == 71 ? 0.35f : wc == 73 ? 0.65f : wc == 77 ? 0.40f : 1f; }
        else if (wc >= 80 && wc <= 82) { tC = 0.95f; tR = wc == 80 ? 0.50f : wc == 81 ? 0.80f : 1f; }
        else if (wc == 85 || wc == 86) { tC = 0.92f; tS = wc == 85 ? 0.50f : 1f; }
        else if (wc >= 95) { tC = 1f; tR = 1f; tSt = 1f; }
        else tC = 0.3f;
        tM = Math.min(1f, tM + 0.18f * tR + 0.25f * tS);
        float tW = Math.max(0f, Math.min(1f, (wxWind - 12f) / 45f));
        float wk = 1f - (float) Math.exp(-dt / 1.4f);
        if (!wxInit) {
            cloud = tC; rain = tR; snow = tS; mist = tM; storm = tSt; windS = tW;
            wxInit = true;
        }
        cloud += (tC - cloud) * wk;
        rain += (tR - rain) * wk;
        snow += (tS - snow) * wk;
        mist += (tM - mist) * wk;
        storm += (tSt - storm) * wk;
        windS += (tW - windS) * wk;
        float rainy = Math.max(rain, storm);
        cloudT += dt * (0.015f + 0.32f * windS);
        windT += dt * windS * 2.2f;
        // lightning
        if (storm > 0.5f) {
            flashTimer -= dt;
            if (flashTimer <= 0f) {
                flash = 1f;
                flashTimer = 2.5f + (float) Math.random() * 7f;
                flashAgain = Math.random() < 0.5;
            }
        }
        flash = Math.max(0f, flash - dt * 3.2f);
        if (flashAgain && flash > 0f && flash < 0.45f) {
            flash = 0.85f;
            flashAgain = false;
        }
        // head-lights come on by themselves in rain, storms and fog (automatic mode only)
        float lightsEff = lightMode == 0 ? Math.max(lightsTarget, Math.max(0.85f * rainy, 0.9f * Math.min(1f, mist))) : lightsTarget;

        float k = 1f - (float) Math.exp(-dt / 0.9f);
        day += (dayTarget - day) * k;
        lights += (lightsEff - lights) * k;
        if (Math.abs(dayTarget - day) < 0.002f) day = dayTarget;
        if (Math.abs(lightsEff - lights) < 0.002f) lights = lightsEff;
        float twi = 4f * day * (1f - day);
        mix3(skyTop, N_TOP, D_TOP, day);
        mix3(skyTop, skyTop, T_TOP, twi * 0.55f);
        mix3(skyHor, N_HOR, D_HOR, day);
        mix3(skyHor, skyHor, T_HOR, twi * 0.60f);
        mix3(asphalt, N_ASP, D_ASP, day);
        {
            float g = Math.min(1f, cloud * 0.80f);
            float dk = 1f - 0.38f * rainy;
            float lt = skyTop[0] * 0.3f + skyTop[1] * 0.59f + skyTop[2] * 0.11f;
            float lh = skyHor[0] * 0.3f + skyHor[1] * 0.59f + skyHor[2] * 0.11f;
            for (int i = 0; i < 3; i++) {
                skyTop[i] += (lt * dk * (i == 2 ? 1.05f : 1f) + 0.03f - skyTop[i]) * g;
                skyHor[i] += (lh * dk * 0.95f * (i == 2 ? 1.04f : 1f) + 0.02f - skyHor[i]) * g * 0.9f;
            }
            float mm = Math.min(1f, mist) * 0.75f;
            float fogC = 0.20f + 0.58f * day;
            for (int i = 0; i < 3; i++) {
                skyHor[i] += (fogC - skyHor[i]) * mm;
                skyTop[i] += (fogC * 0.9f - skyTop[i]) * mm * 0.6f;
                asphalt[i] *= 1f - 0.28f * Math.max(rain, storm * 0.9f);
            }
        }

        // ---- camera: low and wide so the sky has room above the horizon
        float yaw = (float) Math.toRadians(38f + 5f * Math.sin(time * 0.35f));
        float el = (float) Math.toRadians(CAM_EL + 0.8f * Math.sin(time * 0.23f));
        float tv = (float) Math.tan(Math.toRadians(FOV / 2));
        float dist = Math.max(2.25f / tv, 3.2f / (tv * aspect)) * CAM_DIST;
        float tx = 0f, ty = CAM_TY, tz = 0f;
        float ex = tx + dist * (float) (Math.cos(el) * Math.cos(yaw));
        float ey = ty + dist * (float) Math.sin(el);
        float ez = tz + dist * (float) (Math.cos(el) * Math.sin(yaw));
        Matrix.setLookAtM(view, 0, ex, ey, ez, tx, ty, tz, 0, 1, 0);
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0);
        float pitch = (float) Math.atan2(ey - ty, Math.hypot(ex - tx, ez - tz));
        float horizon = 0.5f + 0.5f * (float) Math.tan(pitch) / tv + 0.5f * CAR_LIFT; // screen height (0..1) of the horizon line

        GLES20.glClearColor(skyHor[0], skyHor[1], skyHor[2], 1f);
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);

        // ---- sky
        if (skyProg != 0) {
            GLES20.glDisable(GLES20.GL_DEPTH_TEST);
            GLES20.glUseProgram(skyProg);
            GLES20.glUniform2f(GLES20.glGetUniformLocation(skyProg, "uRes"), vw, vh);
            GLES20.glUniform3f(GLES20.glGetUniformLocation(skyProg, "uTop"), skyTop[0], skyTop[1], skyTop[2]);
            GLES20.glUniform3f(GLES20.glGetUniformLocation(skyProg, "uFog"), skyHor[0], skyHor[1], skyHor[2]);
            GLES20.glUniform1f(GLES20.glGetUniformLocation(skyProg, "uDay"), day);
            GLES20.glUniform1f(GLES20.glGetUniformLocation(skyProg, "uTwi"), twi);
            GLES20.glUniform1f(GLES20.glGetUniformLocation(skyProg, "uTime"), time);
            GLES20.glUniform1f(GLES20.glGetUniformLocation(skyProg, "uHor"), horizon);
            GLES20.glUniform1f(GLES20.glGetUniformLocation(skyProg, "uCloud"), cloud);
            GLES20.glUniform1f(GLES20.glGetUniformLocation(skyProg, "uRainy"), rainy);
            GLES20.glUniform1f(GLES20.glGetUniformLocation(skyProg, "uCT"), cloudT);
            GLES20.glUniform1f(GLES20.glGetUniformLocation(skyProg, "uFlash"), flash);
            int sa = GLES20.glGetAttribLocation(skyProg, "aPos");
            GLES20.glEnableVertexAttribArray(sa);
            GLES20.glVertexAttribPointer(sa, 2, GLES20.GL_FLOAT, false, 8, skyBuf);
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 6);
            GLES20.glDisableVertexAttribArray(sa);
            GLES20.glEnable(GLES20.GL_DEPTH_TEST);
        }

        // ---- road (+ head-light beams and tail-light glow)
        if (gndProg != 0) {
            GLES20.glUseProgram(gndProg);
            GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(gndProg, "uVP"), 1, false, vp, 0);
            GLES20.glUniform1f(GLES20.glGetUniformLocation(gndProg, "uScroll"), scroll);
            GLES20.glUniform3f(GLES20.glGetUniformLocation(gndProg, "uEye"), ex, ey, ez);
            GLES20.glUniform3f(GLES20.glGetUniformLocation(gndProg, "uAccent"), accent[0], accent[1], accent[2]);
            GLES20.glUniform3f(GLES20.glGetUniformLocation(gndProg, "uFog"), skyHor[0], skyHor[1], skyHor[2]);
            GLES20.glUniform3f(GLES20.glGetUniformLocation(gndProg, "uAsphalt"), asphalt[0], asphalt[1], asphalt[2]);
            GLES20.glUniform1f(GLES20.glGetUniformLocation(gndProg, "uLights"), lights);
            GLES20.glUniform2f(GLES20.glGetUniformLocation(gndProg, "uHead"), headX, headZ);
            GLES20.glUniform2f(GLES20.glGetUniformLocation(gndProg, "uTail"), tailX, tailZ);
            GLES20.glUniform1f(GLES20.glGetUniformLocation(gndProg, "uMist"), mist);
            GLES20.glUniform1f(GLES20.glGetUniformLocation(gndProg, "uWet"), Math.max(rain, storm * 0.9f));
            GLES20.glUniform1f(GLES20.glGetUniformLocation(gndProg, "uFlash"), flash);
            int ga = GLES20.glGetAttribLocation(gndProg, "aPos");
            GLES20.glEnableVertexAttribArray(ga);
            GLES20.glVertexAttribPointer(ga, 3, GLES20.GL_FLOAT, false, 12, gndBuf);
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 6);
            GLES20.glDisableVertexAttribArray(ga);
        }

        // ---- car
        if (model == null || carProg == 0) {
            drawPrecip();
            return;
        }
        float bob = 0.012f * moving * (float) Math.sin(time * 17f) + 0.003f * (float) Math.sin(time * 41f);
        float pitchDeg = Math.max(-1.6f, Math.min(1.6f, accel * 0.35f)); // degrees: nose up when accelerating
        Matrix.setIdentityM(wheelM, 0);
        Matrix.translateM(wheelM, 0, 0, bob, 0);
        Matrix.rotateM(wheelM, 0, pitchDeg, 0, 0, 1);
        if (windS > 0.02f) { // strong wind rocks the body a little
            float roll = windS * (0.30f * (float) Math.sin(time * 2.1f) + 0.18f * (float) Math.sin(time * 5.3f + 1f));
            Matrix.rotateM(wheelM, 0, roll, 1, 0, 0);
        }
        Matrix.multiplyMM(bodyM, 0, wheelM, 0, swap, 0);

        GLES20.glUseProgram(carProg);
        int uVP = GLES20.glGetUniformLocation(carProg, "uVP");
        int uM = GLES20.glGetUniformLocation(carProg, "uM");
        GLES20.glUniformMatrix4fv(uVP, 1, false, vp, 0);
        GLES20.glUniform3f(GLES20.glGetUniformLocation(carProg, "uEye"), ex, ey, ez);
        GLES20.glUniform3f(GLES20.glGetUniformLocation(carProg, "uAccent"), accent[0], accent[1], accent[2]);
        GLES20.glUniform1f(GLES20.glGetUniformLocation(carProg, "uDay"), day);
        GLES20.glUniform1f(GLES20.glGetUniformLocation(carProg, "uLights"), lights);
        GLES20.glUniform3f(GLES20.glGetUniformLocation(carProg, "uSky"), skyHor[0], skyHor[1], skyHor[2]);
        int aPos = GLES20.glGetAttribLocation(carProg, "aPos");
        int aNrm = GLES20.glGetAttribLocation(carProg, "aNrm");
        int aCol = GLES20.glGetAttribLocation(carProg, "aCol");
        GLES20.glEnableVertexAttribArray(aPos);
        GLES20.glEnableVertexAttribArray(aNrm);
        GLES20.glEnableVertexAttribArray(aCol);

        drawGroup(0, bodyM, uM, aPos, aNrm, aCol);
        float deg = (float) Math.toDegrees(wheelAng);
        for (int i = 0; i < 4; i++) {
            Glb.Group w = model.wheels[i];
            System.arraycopy(bodyM, 0, wheelM, 0, 16);
            Matrix.translateM(wheelM, 0, w.px, w.py, w.pz);
            Matrix.rotateM(wheelM, 0, deg, 0, 1, 0);
            Matrix.translateM(wheelM, 0, -w.px, -w.py, -w.pz);
            drawGroup(i + 1, wheelM, uM, aPos, aNrm, aCol);
        }
        GLES20.glDisableVertexAttribArray(aPos);
        GLES20.glDisableVertexAttribArray(aNrm);
        GLES20.glDisableVertexAttribArray(aCol);

        // ---- lamp glow: soft additive sprites around the lit lamps
        if (glowProg != 0 && lights > 0.01f && lamps.length > 0) drawGlow(ex, ey, ez);
        drawPrecip();
    }

    /** Rain, snow, wind streaks and a light mist veil drawn over everything (screen space). */
    private void drawPrecip() {
        if (preProg == 0 || rain + snow + mist + windS < 0.01f) return;
        GLES20.glDisable(GLES20.GL_DEPTH_TEST);
        GLES20.glEnable(GLES20.GL_BLEND);
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA);
        GLES20.glUseProgram(preProg);
        GLES20.glUniform2f(GLES20.glGetUniformLocation(preProg, "uRes"), vw, vh);
        GLES20.glUniform1f(GLES20.glGetUniformLocation(preProg, "uT"), time % 1000f);
        GLES20.glUniform1f(GLES20.glGetUniformLocation(preProg, "uRain"), rain);
        GLES20.glUniform1f(GLES20.glGetUniformLocation(preProg, "uSnow"), snow);
        GLES20.glUniform1f(GLES20.glGetUniformLocation(preProg, "uWind"), windS);
        GLES20.glUniform1f(GLES20.glGetUniformLocation(preProg, "uWT"), windT);
        GLES20.glUniform1f(GLES20.glGetUniformLocation(preProg, "uDay"), day);
        GLES20.glUniform1f(GLES20.glGetUniformLocation(preProg, "uMist"), mist);
        GLES20.glUniform3f(GLES20.glGetUniformLocation(preProg, "uFog"), skyHor[0], skyHor[1], skyHor[2]);
        int pa = GLES20.glGetAttribLocation(preProg, "aPos");
        GLES20.glEnableVertexAttribArray(pa);
        GLES20.glVertexAttribPointer(pa, 2, GLES20.GL_FLOAT, false, 8, skyBuf);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 6);
        GLES20.glDisableVertexAttribArray(pa);
        GLES20.glDisable(GLES20.GL_BLEND);
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);
    }

    private void drawGlow(float ex, float ey, float ez) {
        GLES20.glUseProgram(glowProg);
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(glowProg, "uVP"), 1, false, vp, 0);
        int uCol = GLES20.glGetUniformLocation(glowProg, "uCol");
        int uA = GLES20.glGetUniformLocation(glowProg, "uA");
        int aPos = GLES20.glGetAttribLocation(glowProg, "aPos");
        int aUv = GLES20.glGetAttribLocation(glowProg, "aUv");
        float rx = view[0], ry = view[4], rz = view[8]; // camera right
        float ux = view[1], uy = view[5], uz = view[9]; // camera up
        GLES20.glEnable(GLES20.GL_BLEND);
        GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE);
        GLES20.glDepthMask(false);
        GLES20.glEnableVertexAttribArray(aPos);
        GLES20.glEnableVertexAttribArray(aUv);
        for (float[] l : lamps) {
            tmpIn[0] = l[0];
            tmpIn[1] = l[1];
            tmpIn[2] = l[2];
            tmpIn[3] = 1f;
            Matrix.multiplyMV(tmpOut, 0, bodyM, 0, tmpIn, 0);
            float cx = tmpOut[0], cy = tmpOut[1], cz = tmpOut[2];
            float dx = ex - cx, dy = ey - cy, dz = ez - cz;
            float dl = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
            float off = 0.22f / dl;
            cx += dx * off;
            cy += dy * off;
            cz += dz * off;
            boolean head = l[3] == 1f;
            float sz = head ? 0.60f : 0.50f;
            if (head) GLES20.glUniform3f(uCol, 1.0f, 0.93f, 0.78f);
            else GLES20.glUniform3f(uCol, 1.0f, 0.12f, 0.08f);
            GLES20.glUniform1f(uA, lights * (head ? 0.95f : 0.80f));
            float[][] c = {{-1, -1}, {1, -1}, {-1, 1}, {1, -1}, {1, 1}, {-1, 1}};
            for (int i = 0; i < 6; i++) {
                float a = c[i][0], b = c[i][1];
                glowV[i * 5] = cx + (rx * a + ux * b) * sz;
                glowV[i * 5 + 1] = cy + (ry * a + uy * b) * sz;
                glowV[i * 5 + 2] = cz + (rz * a + uz * b) * sz;
                glowV[i * 5 + 3] = a;
                glowV[i * 5 + 4] = b;
            }
            glowBuf.position(0);
            glowBuf.put(glowV).position(0);
            glowBuf.position(0);
            GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 20, glowBuf);
            glowBuf.position(3);
            GLES20.glVertexAttribPointer(aUv, 2, GLES20.GL_FLOAT, false, 20, glowBuf);
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 6);
            glowBuf.position(0);
        }
        GLES20.glDisableVertexAttribArray(aPos);
        GLES20.glDisableVertexAttribArray(aUv);
        GLES20.glDepthMask(true);
        GLES20.glDisable(GLES20.GL_BLEND);
    }

    // camera framing (tuned so the horizon sits about two thirds up and the car stands on the road)
    private static final float CAR_LIFT = 0.13f; // fraction of half the screen height
    private static final float CAM_EL = 6f, CAM_DIST = 1.15f, CAM_TY = 1.3f;

    private void drawGroup(int i, float[] m, int uM, int aPos, int aNrm, int aCol) {
        FloatBuffer b = carBuf[i];
        if (b == null || carCount[i] == 0) return;
        GLES20.glUniformMatrix4fv(uM, 1, false, m, 0);
        int stride = Glb.STRIDE * 4;
        b.position(0);
        GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, stride, b);
        b.position(3);
        GLES20.glVertexAttribPointer(aNrm, 3, GLES20.GL_FLOAT, false, stride, b);
        b.position(6);
        GLES20.glVertexAttribPointer(aCol, 4, GLES20.GL_FLOAT, false, stride, b);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, carCount[i]);
        b.position(0);
    }
}
