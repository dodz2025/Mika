package com.mika.launcher;

import android.content.Context;

/** Colour palette: 20 built-in themes + optional accent override + optional automatic night theme. */
final class Pal {

    static class T {
        final String name;
        final boolean dark;
        final int top, bottom, accent, text, sub, card;

        T(String n, boolean d, int top, int bottom, int accent) {
            this.name = n;
            this.dark = d;
            this.top = top;
            this.bottom = bottom;
            this.accent = accent;
            this.text = d ? 0xFFFFFFFF : 0xFF14182A;
            this.sub = d ? 0xFFA9B0C3 : 0xFF5A6179;
            this.card = d ? 0x26FFFFFF : 0x1A000000;
        }
    }

    static final T[] THEMES = {
            new T("Midnight", true, 0xFF141826, 0xFF05060A, 0xFF7C4DFF),
            new T("AMOLED Black", true, 0xFF000000, 0xFF000000, 0xFF2979FF),
            new T("Aurora", true, 0xFF0C3B3A, 0xFF08172B, 0xFF1DE9B6),
            new T("Sunset", true, 0xFF4A1F52, 0xFF1C0C1F, 0xFFFF8A3D),
            new T("Ocean", true, 0xFF08335C, 0xFF020F1F, 0xFF29B6F6),
            new T("Forest", true, 0xFF12301F, 0xFF050E09, 0xFF66BB6A),
            new T("Neon", true, 0xFF230B3D, 0xFF04010C, 0xFFFF2BD6),
            new T("Crimson", true, 0xFF33090F, 0xFF0A0305, 0xFFFF3B4E),
            new T("Graphite", true, 0xFF2D3036, 0xFF111214, 0xFFFFB300),
            new T("Royal", true, 0xFF1D2252, 0xFF080A20, 0xFFFFD54F),
            new T("Daylight", false, 0xFFF4F6FC, 0xFFD5DBEC, 0xFF2979FF),
            new T("Paper", false, 0xFFFBF5E9, 0xFFE8DDC6, 0xFFC2185B),
            new T("Mint", false, 0xFFE8F7F1, 0xFFC5E6D8, 0xFF00897B),
            new T("Lavender", false, 0xFFF1EBFB, 0xFFD8CCF0, 0xFF7C4DFF),
            new T("Peach", false, 0xFFFFF0E8, 0xFFF6D2C0, 0xFFF4511E),
            new T("Sky", false, 0xFFE6F4FF, 0xFFBFDDF5, 0xFF0288D1),
            new T("Cockpit", true, 0xFF3A1A66, 0xFF0B0620, 0xFFE040FB),
            new T("Carbon", true, 0xFF22262B, 0xFF08090B, 0xFF00E5FF),
            new T("Rally", true, 0xFF3B0D12, 0xFF0C0204, 0xFFFF6D00),
            new T("Glacier", true, 0xFF0D2A3F, 0xFF030B12, 0xFF80D8FF),
    };

    /** Index of "Cockpit", the default look until the user picks a theme. */
    static final int DEFAULT = 16;

    static final String[] ACCENT_NAMES = {"Theme default", "Violet", "Blue", "Teal", "Green", "Orange", "Pink", "Red", "Cyan"};
    static final int[] ACCENT_VALUES = {-1, 0, 1, 2, 3, 4, 5, 6, 7};
    static final int[] ACCENTS = {
            0xFF7C4DFF, 0xFF2979FF, 0xFF00BFA5, 0xFF43A047, 0xFFFF9100, 0xFFEC407A, 0xFFE53935, 0xFF00B8D4};

    boolean dark;
    int bgTop, bgBottom, text, sub, card, accent, panel;
    String name;
    int index;

    static boolean isNight(Context c) {
        return SkyClock.scheduleNight(c);
    }

    static int themeIndex(Context c) {
        int day = Prefs.p(c).contains("themeId") ? Prefs.i(c, "themeId", 0) : DEFAULT;
        int night = Prefs.i(c, "nightTheme", 0);
        int idx = (Prefs.b(c, "autoTheme", false) && isNight(c)) ? night : day;
        if (idx < 0 || idx >= THEMES.length) idx = 0;
        return idx;
    }

    /** Changes whenever the effective look changes (used to decide when to rebuild the UI). */
    static String key(Context c) {
        return themeIndex(c) + ":" + Prefs.i(c, "accent", -1);
    }

    static Pal of(Context c) {
        return of(c, themeIndex(c));
    }

    static Pal of(Context c, int idx) {
        T t = THEMES[idx];
        Pal p = new Pal();
        p.index = idx;
        p.name = t.name;
        p.dark = t.dark;
        p.bgTop = t.top;
        p.bgBottom = t.bottom;
        p.text = t.text;
        p.sub = t.sub;
        p.card = t.card;
        int a = Prefs.i(c, "accent", -1);
        p.accent = a >= 0 ? ACCENTS[a % ACCENTS.length] : t.accent;
        p.panel = (t.dark ? t.bottom : t.top) & 0x00FFFFFF | 0xF2000000;
        return p;
    }
}
