package com.mika.launcher;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Mika settings. Everything here is free - there are no locked or paid options. */
public class SettingsActivity extends Activity {

    private static final int REQ_WALLPAPER = 7;
    private static final int REQ_LOC = 8;

    private Pal pal;
    private LinearLayout list;
    private ScrollView sv;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        build();
    }

    @Override
    protected void onResume() {
        super.onResume();
        build();
    }

    private int dp(int v) {
        return Ui.dp(this, v);
    }

    // ------------------------------------------------------------- building
    private void build() {
        int scroll = sv == null ? 0 : sv.getScrollY();
        pal = Pal.of(this);
        sv = new ScrollView(this);
        sv.setBackgroundColor(pal.dark ? 0xFF0B0E17 : 0xFFEFF2FA);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(18), dp(18), dp(18), dp(40));
        sv.addView(list, new ScrollView.LayoutParams(-1, -2));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = Ui.button(this, "\u2190", 20, pal.card, pal.text);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        top.addView(back);
        TextView title = Ui.text(this, "Mika settings", 24, pal.text);
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(-2, -2);
        tl.leftMargin = dp(14);
        top.addView(title, tl);
        list.addView(top);

        header("Appearance");
        action("Theme", Pal.THEMES[Pal.themeIndex(this)].name + "  \u00B7  " + Pal.THEMES.length + " themes",
                new Runnable() {
                    public void run() {
                        themeDialog("themeId", "Choose theme");
                    }
                });
        toggle("Switch theme automatically at night", "Use a different theme between 6 PM and 6 AM", "autoTheme", false);
        if (Prefs.b(this, "autoTheme", false)) {
            action("Night theme", Pal.THEMES[Prefs.i(this, "nightTheme", 0) % Pal.THEMES.length].name,
                    new Runnable() {
                        public void run() {
                            themeDialog("nightTheme", "Choose night theme");
                        }
                    });
        }
        choice("Accent colour", Pal.ACCENT_NAMES, "accent", -1, Pal.ACCENT_VALUES);
        action("Wallpaper", Prefs.wallpaperFile(this).exists() ? "Custom wallpaper set" : "Using theme gradient",
                new Runnable() {
                    public void run() {
                        wallpaperMenu();
                    }
                });
        choice("Wallpaper dimming", new String[]{"None", "20%", "40%", "60%", "80%"}, "dim", 40,
                new int[]{0, 20, 40, 60, 80});
        toggle("24-hour clock", null, "h24", true);
        choice("App icon size", new String[]{"Small", "Medium", "Large", "Extra large"}, "iconSize", 56,
                new int[]{44, 56, 72, 88});
        choice("App grid columns", new String[]{"3", "4", "5", "6", "7", "8"}, "cols", 6,
                new int[]{3, 4, 5, 6, 7, 8});

        header("Home dashboard");
        toggle("Weather", "Current conditions and 3-day forecast", "showWeather", true);
        toggle("Now playing", "Track, album art and controls from any music app", "showMusic", true);
        toggle("Speedometer", "GPS speed and compass heading", "showSpeed", true);
        toggle("Map", "Live mini map on the home screen", "showMap", true);
        toggle("Volume", "Media volume slider", "showVolume", true);
        toggle("Frequent apps", "Shortcuts to the apps you open most", "showFrequent", true);

        header("Weather");
        action("City", Prefs.b(this, "wxManual", false) ? Prefs.s(this, "wxName", "") : "Using current location",
                new Runnable() {
                    public void run() {
                        citySearchDialog();
                    }
                });
        action("Use my current location", "Switch back to automatic location", new Runnable() {
            public void run() {
                Prefs.putB(SettingsActivity.this, "wxManual", false);
                Prefs.cache(SettingsActivity.this).edit().clear().apply();
                requestLocation();
                build();
            }
        });
        choice("Units", new String[]{"Celsius, km/h", "Fahrenheit, mph"}, "wxF", false, null);

        header("Speedometer");
        choice("Speed unit", new String[]{"km/h", "mph"}, "speedMph", false, null);

        header("Apps");
        choice("Sort app drawer", new String[]{"A to Z", "Most used", "Recently installed"}, "sort", 0,
                new int[]{0, 1, 2});
        toggle("Swipe up to open apps", "Swipe up anywhere on the home screen", "swipeUp", true);
        action("Hidden apps", Prefs.list(this, "hidden").size() + " hidden", new Runnable() {
            public void run() {
                hiddenAppsDialog();
            }
        });
        action("Clear dock", "Remove all pinned apps", new Runnable() {
            public void run() {
                Prefs.putS(SettingsActivity.this, "dock", "");
                Toast.makeText(SettingsActivity.this, "Dock cleared", Toast.LENGTH_SHORT).show();
            }
        });
        action("Reset usage statistics", "Clears the frequent apps list", new Runnable() {
            public void run() {
                Prefs.counts(SettingsActivity.this).edit().clear().apply();
                Toast.makeText(SettingsActivity.this, "Usage statistics reset", Toast.LENGTH_SHORT).show();
            }
        });

        header("System");
        action("Notification access (for Now playing)",
                MediaTracker.hasAccess(this) ? "Enabled" : "Not enabled \u2013 tap to enable",
                new Runnable() {
                    public void run() {
                        try {
                            startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
                        } catch (Exception e) {
                            Toast.makeText(SettingsActivity.this, "Open Settings \u203A Notification access",
                                    Toast.LENGTH_LONG).show();
                        }
                    }
                });
        action("Location permission", "Needed for speedometer and automatic weather", new Runnable() {
            public void run() {
                requestLocation();
            }
        });
        action("Set Mika as default home app", "Choose Mika when Android asks", new Runnable() {
            public void run() {
                try {
                    startActivity(new Intent(Settings.ACTION_HOME_SETTINGS));
                } catch (Exception e) {
                    startActivity(new Intent(Settings.ACTION_SETTINGS));
                }
            }
        });

        header("About");
        action("Mika 2.0", "Free launcher. No ads, no subscription, no locked features.", null);

        setContentView(sv);
        final int restore = scroll;
        sv.post(new Runnable() {
            public void run() {
                sv.scrollTo(0, restore);
            }
        });
    }

    // ---------------------------------------------------------- row helpers
    private void header(String s) {
        TextView t = Ui.text(this, s.toUpperCase(), 12, pal.accent);
        t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        t.setLetterSpacing(0.12f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.topMargin = dp(26);
        lp.bottomMargin = dp(8);
        list.addView(t, lp);
    }

    private LinearLayout row(String title, String sub) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setBackground(Ui.pill(this, pal.card, 16));
        r.setPadding(dp(16), dp(14), dp(16), dp(14));
        TextView t = Ui.text(this, title, 17, pal.text);
        r.addView(t);
        if (sub != null && sub.length() > 0) {
            TextView s = Ui.text(this, sub, 13, pal.sub);
            r.addView(s);
        }
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(6);
        list.addView(r, lp);
        return r;
    }

    private void action(String title, String sub, final Runnable run) {
        LinearLayout r = row(title, sub);
        if (run != null) {
            r.setClickable(true);
            r.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    run.run();
                }
            });
        }
    }

    private void toggle(String title, String sub, final String key, boolean def) {
        LinearLayout r = row(title, sub);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        // move text children into a vertical holder so the switch sits on the right
        LinearLayout holder = new LinearLayout(this);
        holder.setOrientation(LinearLayout.VERTICAL);
        while (r.getChildCount() > 0) {
            View c = r.getChildAt(0);
            r.removeViewAt(0);
            holder.addView(c);
        }
        r.addView(holder, new LinearLayout.LayoutParams(0, -2, 1f));
        final Switch sw = new Switch(this);
        sw.setChecked(Prefs.b(this, key, def));
        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean on) {
                Prefs.putB(SettingsActivity.this, key, on);
            }
        });
        r.addView(sw);
        r.setClickable(true);
        r.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sw.toggle();
            }
        });
    }

    /**
     * Choice row. For int prefs pass values[]; for boolean prefs pass values == null and a Boolean default
     * (option index 0 = false, 1 = true).
     */
    private void choice(final String title, final String[] opts, final String key, Object def, final int[] values) {
        int current = 0;
        if (values == null) {
            current = Prefs.b(this, key, (Boolean) def) ? 1 : 0;
        } else {
            int cur = Prefs.i(this, key, (Integer) def);
            for (int i = 0; i < values.length; i++) if (values[i] == cur) current = i;
        }
        final int sel = current;
        LinearLayout r = row(title, opts[current]);
        r.setClickable(true);
        r.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(SettingsActivity.this).setTitle(title)
                        .setSingleChoiceItems(opts, sel, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int which) {
                                if (values == null) Prefs.putB(SettingsActivity.this, key, which == 1);
                                else Prefs.putI(SettingsActivity.this, key, values[which]);
                                if (key.equals("wxF")) Prefs.cache(SettingsActivity.this).edit().clear().apply();
                                d.dismiss();
                                build();
                            }
                        }).show();
            }
        });
    }

    // ---------------------------------------------------------------- themes
    private void themeDialog(final String key, String title) {
        final AlertDialog.Builder b = new AlertDialog.Builder(this).setTitle(title);
        ScrollView scroll = new ScrollView(this);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(10), dp(6), dp(10), dp(6));
        scroll.addView(col);
        b.setView(scroll);
        final AlertDialog dlg = b.create();
        int cur = key.equals("themeId") && !Prefs.p(this).contains(key) ? Pal.DEFAULT : Prefs.i(this, key, 0);
        LinearLayout row = null;
        for (int i = 0; i < Pal.THEMES.length; i++) {
            if (i % 2 == 0) {
                row = new LinearLayout(this);
                col.addView(row, new LinearLayout.LayoutParams(-1, -2));
            }
            final int idx = i;
            Pal.T t = Pal.THEMES[i];
            LinearLayout tile = new LinearLayout(this);
            tile.setOrientation(LinearLayout.VERTICAL);
            tile.setGravity(Gravity.CENTER);
            android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable(
                    android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                    new int[]{t.top, t.bottom});
            g.setCornerRadius(dp(14));
            if (i == cur) g.setStroke(dp(3), t.accent);
            else g.setStroke(dp(1), 0x33888888);
            tile.setBackground(g);
            tile.setPadding(dp(8), dp(14), dp(8), dp(12));
            View dot = new View(this);
            dot.setBackground(Ui.pill(this, t.accent, 20));
            tile.addView(dot, new LinearLayout.LayoutParams(dp(26), dp(26)));
            TextView n = Ui.text(this, t.name, 14, t.text);
            n.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams nl = new LinearLayout.LayoutParams(-2, -2);
            nl.topMargin = dp(8);
            tile.addView(n, nl);
            tile.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Prefs.putI(SettingsActivity.this, key, idx);
                    dlg.dismiss();
                    build();
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
            lp.setMargins(dp(5), dp(5), dp(5), dp(5));
            row.addView(tile, lp);
        }
        dlg.show();
    }

    // -------------------------------------------------------------- wallpaper
    private void wallpaperMenu() {
        String[] items = {"Choose from gallery", "Remove wallpaper"};
        new AlertDialog.Builder(this).setTitle("Wallpaper")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        if (which == 0) {
                            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                            i.setType("image/*");
                            startActivityForResult(Intent.createChooser(i, "Choose wallpaper"), REQ_WALLPAPER);
                        } else {
                            Prefs.wallpaperFile(SettingsActivity.this).delete();
                            Prefs.putI(SettingsActivity.this, "wp", 0);
                            build();
                        }
                    }
                }).show();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_WALLPAPER || res != RESULT_OK || data == null || data.getData() == null) return;
        try {
            Uri uri = data.getData();
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            InputStream in = getContentResolver().openInputStream(uri);
            BitmapFactory.decodeStream(in, null, o);
            in.close();
            int sample = 1;
            while (o.outWidth / sample > 2400 || o.outHeight / sample > 2400) sample *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            in = getContentResolver().openInputStream(uri);
            Bitmap bmp = BitmapFactory.decodeStream(in, null, o2);
            in.close();
            if (bmp == null) throw new Exception("decode failed");
            FileOutputStream out = new FileOutputStream(Prefs.wallpaperFile(this));
            bmp.compress(Bitmap.CompressFormat.JPEG, 90, out);
            out.close();
            Prefs.putI(this, "wp", (int) (System.currentTimeMillis() / 1000));
            Toast.makeText(this, "Wallpaper set", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Couldn't use that image", Toast.LENGTH_SHORT).show();
        }
        build();
    }

    // ---------------------------------------------------------------- weather
    private void requestLocation() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Location permission already granted", Toast.LENGTH_SHORT).show();
            } else {
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOC);
            }
        }
    }

    private void citySearchDialog() {
        final EditText et = new EditText(this);
        et.setHint("City name");
        et.setSingleLine(true);
        et.setInputType(InputType.TYPE_CLASS_TEXT);
        new AlertDialog.Builder(this).setTitle("Weather city").setView(et)
                .setPositiveButton("Search", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        searchCity(et.getText().toString().trim());
                    }
                }).setNegativeButton("Cancel", null).show();
    }

    private void searchCity(final String q) {
        if (q.length() == 0) return;
        Toast.makeText(this, "Searching\u2026", Toast.LENGTH_SHORT).show();
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    final List<WeatherClient.Place> res = WeatherClient.search(q);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            showCityResults(res);
                        }
                    });
                } catch (Exception e) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(SettingsActivity.this, "Search failed. Check your connection.",
                                    Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
        }).start();
    }

    private void showCityResults(final List<WeatherClient.Place> res) {
        if (res.isEmpty()) {
            Toast.makeText(this, "No cities found", Toast.LENGTH_SHORT).show();
            return;
        }
        String[] labels = new String[res.size()];
        for (int i = 0; i < labels.length; i++) labels[i] = res.get(i).label();
        new AlertDialog.Builder(this).setTitle("Choose city")
                .setItems(labels, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        WeatherClient.Place p = res.get(which);
                        Prefs.putS(SettingsActivity.this, "wxLat", String.valueOf(p.lat));
                        Prefs.putS(SettingsActivity.this, "wxLon", String.valueOf(p.lon));
                        Prefs.putS(SettingsActivity.this, "wxName", p.name);
                        Prefs.putB(SettingsActivity.this, "wxManual", true);
                        Prefs.cache(SettingsActivity.this).edit().clear().apply();
                        build();
                    }
                }).show();
    }

    // ------------------------------------------------------------ hidden apps
    private void hiddenAppsDialog() {
        final PackageManager pm = getPackageManager();
        Intent main = new Intent(Intent.ACTION_MAIN, null);
        main.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> ris = pm.queryIntentActivities(main, 0);
        final List<String[]> apps = new ArrayList<String[]>(); // {label, key}
        for (ResolveInfo ri : ris) {
            if (ri.activityInfo.packageName.equals(getPackageName())) continue;
            apps.add(new String[]{String.valueOf(ri.loadLabel(pm)),
                    ri.activityInfo.packageName + "/" + ri.activityInfo.name});
        }
        Collections.sort(apps, new Comparator<String[]>() {
            @Override
            public int compare(String[] a, String[] b) {
                return a[0].compareToIgnoreCase(b[0]);
            }
        });
        final List<String> hidden = Prefs.list(this, "hidden");
        String[] labels = new String[apps.size()];
        final boolean[] checked = new boolean[apps.size()];
        for (int i = 0; i < labels.length; i++) {
            labels[i] = apps.get(i)[0];
            checked[i] = hidden.contains(apps.get(i)[1]);
        }
        new AlertDialog.Builder(this).setTitle("Hide apps from the drawer")
                .setMultiChoiceItems(labels, checked, new DialogInterface.OnMultiChoiceClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which, boolean isChecked) {
                        checked[which] = isChecked;
                    }
                })
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        List<String> out = new ArrayList<String>();
                        for (int i = 0; i < checked.length; i++) if (checked[i]) out.add(apps.get(i)[1]);
                        Prefs.saveList(SettingsActivity.this, "hidden", out);
                        build();
                    }
                }).setNegativeButton("Cancel", null).show();
    }
}
