package com.mika.launcher;

import android.service.notification.NotificationListenerService;

/**
 * Empty notification listener. Granting notification access to this service is what lets
 * Mika read the active media sessions (track title, artist, album art, play state).
 * Mika does not read or store your notifications.
 */
public class MediaListenerService extends NotificationListenerService {
}
