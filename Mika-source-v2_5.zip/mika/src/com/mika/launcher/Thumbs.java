package com.mika.launcher;

import android.content.ContentUris;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.util.LruCache;
import android.widget.ImageView;

import java.io.InputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Asynchronous, cached thumbnail loading for lists. */
final class Thumbs {
    private Thumbs() {
    }

    interface Loader {
        Bitmap load() throws Exception;
    }

    private static final LruCache<String, Bitmap> CACHE = new LruCache<String, Bitmap>(24 * 1024 * 1024) {
        @Override
        protected int sizeOf(String k, Bitmap b) {
            return b.getByteCount();
        }
    };
    private static final ExecutorService POOL = Executors.newFixedThreadPool(3);

    static void load(final ImageView iv, final String key, final Loader l) {
        iv.setTag(key);
        Bitmap b = CACHE.get(key);
        if (b != null) {
            iv.setImageBitmap(b);
            return;
        }
        iv.setImageDrawable(null);
        POOL.execute(new Runnable() {
            @Override
            public void run() {
                Bitmap bmp = null;
                try {
                    bmp = l.load();
                } catch (Throwable ignored) {
                }
                if (bmp == null) return;
                CACHE.put(key, bmp);
                final Bitmap fb = bmp;
                iv.post(new Runnable() {
                    @Override
                    public void run() {
                        if (key.equals(iv.getTag())) iv.setImageBitmap(fb);
                    }
                });
            }
        });
    }

    static Bitmap decodeUri(Context c, Uri uri, int maxDim) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            InputStream in = c.getContentResolver().openInputStream(uri);
            BitmapFactory.decodeStream(in, null, o);
            if (in != null) in.close();
            int sample = 1;
            while (o.outWidth / (sample * 2) >= maxDim && o.outHeight / (sample * 2) >= maxDim) sample *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            in = c.getContentResolver().openInputStream(uri);
            Bitmap b = BitmapFactory.decodeStream(in, null, o2);
            if (in != null) in.close();
            return b;
        } catch (Throwable t) {
            return null;
        }
    }

    /** Album art: tries the MediaStore album-art URI first, then the picture embedded in the file. */
    static Bitmap audioArt(Context c, Track t, int size) {
        Bitmap b = null;
        if (t.albumId > 0) {
            b = decodeUri(c, ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), t.albumId), size);
        }
        if (b == null && t.uri != null) {
            MediaMetadataRetriever r = new MediaMetadataRetriever();
            try {
                r.setDataSource(c, t.uri);
                byte[] pic = r.getEmbeddedPicture();
                if (pic != null) {
                    BitmapFactory.Options o = new BitmapFactory.Options();
                    o.inJustDecodeBounds = true;
                    BitmapFactory.decodeByteArray(pic, 0, pic.length, o);
                    int sample = 1;
                    while (o.outWidth / (sample * 2) >= size) sample *= 2;
                    BitmapFactory.Options o2 = new BitmapFactory.Options();
                    o2.inSampleSize = sample;
                    b = BitmapFactory.decodeByteArray(pic, 0, pic.length, o2);
                }
            } catch (Throwable ignored) {
            } finally {
                try {
                    r.release();
                } catch (Throwable ignored) {
                }
            }
        }
        return b;
    }

    static Bitmap videoFrame(Context c, Uri uri, int size) {
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        try {
            r.setDataSource(c, uri);
            Bitmap f = r.getFrameAtTime(1000000);
            if (f == null) return null;
            float s = (float) size / Math.max(f.getWidth(), f.getHeight());
            if (s < 1f) f = Bitmap.createScaledBitmap(f, Math.round(f.getWidth() * s), Math.round(f.getHeight() * s), true);
            return f;
        } catch (Throwable t) {
            return null;
        } finally {
            try {
                r.release();
            } catch (Throwable ignored) {
            }
        }
    }
}
