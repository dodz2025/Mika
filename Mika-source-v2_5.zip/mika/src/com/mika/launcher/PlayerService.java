package com.mika.launcher;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.drawable.Icon;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaMetadata;
import android.media.MediaPlayer;
import android.media.audiofx.Equalizer;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.SystemClock;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Music playback that keeps going while you use other apps. Exposes a MediaSession so
 * steering-wheel / Bluetooth / lock-screen buttons work, and shows a media notification.
 */
public class PlayerService extends Service {

    static final String ACTION_START = "mika.START";
    static final String ACTION_TOGGLE = "mika.TOGGLE";
    static final String ACTION_NEXT = "mika.NEXT";
    static final String ACTION_PREV = "mika.PREV";
    static final String ACTION_STOP = "mika.STOP";
    private static final String CHANNEL = "mika_playback";
    private static final int NOTIF_ID = 42;

    // ---- shared state (read by the UI)
    static PlayerService instance;
    static final List<Track> queue = new ArrayList<Track>();
    static int index = -1;
    static boolean shuffle = false;
    static int repeat = 0; // 0 off, 1 all, 2 one
    static long sleepAt = 0;
    static final CopyOnWriteArrayList<Runnable> LISTENERS = new CopyOnWriteArrayList<Runnable>();

    private MediaPlayer mp;
    private boolean prepared = false;
    private boolean playing = false;
    private boolean resumeOnFocus = false;
    private Bitmap art;
    private MediaSession session;
    private AudioManager am;
    private NotificationManager nm;
    private Equalizer eq;
    private final Handler h = new Handler();
    private final Random rnd = new Random();
    private boolean foregroundStarted = false;

    // ============================================================ static API
    static boolean active() {
        return instance != null && index >= 0 && index < queue.size();
    }

    static Track current() {
        return active() ? queue.get(index) : null;
    }

    static boolean isPlaying() {
        return instance != null && instance.playing;
    }

    static int position() {
        try {
            return instance != null && instance.prepared ? instance.mp.getCurrentPosition() : 0;
        } catch (Exception e) {
            return 0;
        }
    }

    static int duration() {
        try {
            if (instance != null && instance.prepared) return instance.mp.getDuration();
        } catch (Exception ignored) {
        }
        Track t = current();
        return t == null ? 0 : (int) t.duration;
    }

    static Bitmap art() {
        return instance == null ? null : instance.art;
    }

    static void play(Context c, List<Track> list, int start) {
        queue.clear();
        queue.addAll(list);
        index = Math.max(0, Math.min(start, queue.size() - 1));
        send(c, ACTION_START);
    }

    static void send(Context c, String action) {
        Intent i = new Intent(c, PlayerService.class).setAction(action);
        if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i);
        else c.startService(i);
    }

    static void toggle() {
        if (instance != null) instance.togglePlay();
    }

    static void next() {
        if (instance != null) instance.advance(false);
    }

    static void prev() {
        if (instance != null) instance.previous();
    }

    static void seek(int ms) {
        if (instance != null && instance.prepared) {
            instance.mp.seekTo(ms);
            instance.updateSession();
        }
    }

    static void jumpTo(int i) {
        if (instance != null && i >= 0 && i < queue.size()) {
            index = i;
            instance.loadCurrent(true);
        }
    }

    static void enqueue(Context c, Track t, boolean playNext) {
        if (!active()) {
            List<Track> l = new ArrayList<Track>();
            l.add(t);
            play(c, l, 0);
            return;
        }
        if (playNext) queue.add(index + 1, t);
        else queue.add(t);
        notifyListeners();
    }

    static void pauseIfPlaying() {
        if (instance != null && instance.playing) instance.togglePlay();
    }

    static void setSleepMinutes(int minutes) {
        if (instance == null) return;
        instance.h.removeCallbacks(instance.sleepRun);
        if (minutes > 0) {
            sleepAt = System.currentTimeMillis() + minutes * 60000L;
            instance.h.postDelayed(instance.sleepRun, minutes * 60000L);
        } else {
            sleepAt = 0;
        }
        notifyListeners();
    }

    static void applyEqPreset(Context c, int preset) {
        Prefs.putI(c, "eqPreset", preset);
        if (instance != null) instance.refreshEq();
    }

    static void notifyListeners() {
        for (Runnable r : LISTENERS) r.run();
    }

    // =========================================================== lifecycle
    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Music playback",
                    NotificationManager.IMPORTANCE_LOW);
            ch.setShowBadge(false);
            nm.createNotificationChannel(ch);
        }
        session = new MediaSession(this, "Mika");
        session.setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS | MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS);
        session.setCallback(new MediaSession.Callback() {
            @Override
            public void onPlay() {
                if (!playing) togglePlay();
            }

            @Override
            public void onPause() {
                if (playing) togglePlay();
            }

            @Override
            public void onSkipToNext() {
                advance(false);
            }

            @Override
            public void onSkipToPrevious() {
                previous();
            }

            @Override
            public void onSeekTo(long pos) {
                seek((int) pos);
            }

            @Override
            public void onStop() {
                stopAll();
            }
        });
        session.setSessionActivity(PendingIntent.getActivity(this, 0,
                new Intent(this, PlayerActivity.class), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT));
        session.setActive(true);
        registerReceiver(noisy, new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY));
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String a = intent == null ? null : intent.getAction();
        startForegroundNow();
        if (!active()) {
            stopAll();
            return START_NOT_STICKY;
        }
        if (ACTION_START.equals(a)) {
            loadCurrent(true);
        } else if (ACTION_TOGGLE.equals(a)) {
            togglePlay();
        } else if (ACTION_NEXT.equals(a)) {
            advance(false);
        } else if (ACTION_PREV.equals(a)) {
            previous();
        } else if (ACTION_STOP.equals(a)) {
            stopAll();
        }
        return START_NOT_STICKY;
    }

    @Override
    public IBinder onBind(Intent i) {
        return null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        try {
            unregisterReceiver(noisy);
        } catch (Exception ignored) {
        }
        releasePlayer();
        h.removeCallbacksAndMessages(null);
        if (session != null) {
            session.setActive(false);
            session.release();
        }
        if (am != null) am.abandonAudioFocus(focusListener);
        if (instance == this) instance = null;
        notifyListeners();
    }

    private void stopAll() {
        playing = false;
        releasePlayer();
        stopForeground(true);
        foregroundStarted = false;
        stopSelf();
        notifyListeners();
    }

    private final BroadcastReceiver noisy = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            if (playing) togglePlay();
        }
    };

    private final Runnable sleepRun = new Runnable() {
        @Override
        public void run() {
            sleepAt = 0;
            if (playing) togglePlay();
            notifyListeners();
        }
    };

    // ============================================================= playback
    @SuppressWarnings("deprecation")
    private boolean requestFocus() {
        return am.requestAudioFocus(focusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN)
                == AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
    }

    private final AudioManager.OnAudioFocusChangeListener focusListener = new AudioManager.OnAudioFocusChangeListener() {
        @Override
        public void onAudioFocusChange(int change) {
            if (mp == null) return;
            try {
                if (change == AudioManager.AUDIOFOCUS_LOSS) {
                    resumeOnFocus = false;
                    if (playing) togglePlay();
                } else if (change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
                    if (playing) {
                        resumeOnFocus = true;
                        togglePlay();
                    }
                } else if (change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK) {
                    mp.setVolume(0.25f, 0.25f);
                } else if (change == AudioManager.AUDIOFOCUS_GAIN) {
                    mp.setVolume(1f, 1f);
                    if (resumeOnFocus && !playing) togglePlay();
                    resumeOnFocus = false;
                }
            } catch (Exception ignored) {
            }
        }
    };

    private void releasePlayer() {
        prepared = false;
        if (eq != null) {
            try {
                eq.release();
            } catch (Exception ignored) {
            }
            eq = null;
        }
        if (mp != null) {
            try {
                mp.release();
            } catch (Exception ignored) {
            }
            mp = null;
        }
    }

    private void loadCurrent(final boolean autoplay) {
        releasePlayer();
        if (!active()) {
            stopAll();
            return;
        }
        final Track t = queue.get(index);
        art = null;
        playing = false;
        mp = new MediaPlayer();
        try {
            mp.setWakeMode(this, PowerManager.PARTIAL_WAKE_LOCK);
            mp.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            mp.setDataSource(this, t.uri);
            mp.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer p) {
                    prepared = true;
                    setupEq();
                    if (autoplay && requestFocus()) {
                        p.start();
                        playing = true;
                    }
                    updateSession();
                    updateNotification();
                    notifyListeners();
                }
            });
            mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer p) {
                    onTrackEnded();
                }
            });
            mp.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                @Override
                public boolean onError(MediaPlayer p, int what, int extra) {
                    Toast.makeText(PlayerService.this, "Can't play \u201C" + t.title + "\u201D", Toast.LENGTH_SHORT).show();
                    if (queue.size() > 1) advance(true);
                    else stopAll();
                    return true;
                }
            });
            mp.prepareAsync();
        } catch (Exception e) {
            Toast.makeText(this, "Can't play \u201C" + t.title + "\u201D", Toast.LENGTH_SHORT).show();
            if (queue.size() > 1) advance(true);
            else stopAll();
            return;
        }
        updateSession();
        updateNotification();
        notifyListeners();
        loadArtAsync(t);
    }

    private void loadArtAsync(final Track t) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                final Bitmap b = Thumbs.audioArt(PlayerService.this, t, 600);
                h.post(new Runnable() {
                    @Override
                    public void run() {
                        if (current() == t) {
                            art = b;
                            updateSession();
                            updateNotification();
                            notifyListeners();
                        }
                    }
                });
            }
        }).start();
    }

    private void setupEq() {
        int preset = Prefs.i(this, "eqPreset", -1);
        if (preset < 0) return;
        try {
            eq = new Equalizer(0, mp.getAudioSessionId());
            if (preset < eq.getNumberOfPresets()) eq.usePreset((short) preset);
            eq.setEnabled(true);
        } catch (Throwable t) {
            eq = null;
        }
    }

    /** Reapplies the equalizer preset chosen in Prefs to the running player. */
    void refreshEq() {
        if (eq != null) {
            try {
                eq.release();
            } catch (Exception ignored) {
            }
            eq = null;
        }
        if (prepared) setupEq();
    }

    private void togglePlay() {
        if (mp == null) {
            loadCurrent(true);
            return;
        }
        if (!prepared) return;
        try {
            if (playing) {
                mp.pause();
                playing = false;
            } else if (requestFocus()) {
                mp.start();
                playing = true;
            }
        } catch (Exception ignored) {
        }
        updateSession();
        updateNotification();
        notifyListeners();
    }

    private void onTrackEnded() {
        if (repeat == 2) {
            mp.seekTo(0);
            mp.start();
            return;
        }
        advance(true);
    }

    /** Moves to the next track. auto == true when the previous track just finished. */
    private void advance(boolean auto) {
        if (queue.isEmpty()) return;
        if (shuffle && queue.size() > 1) {
            int n;
            do {
                n = rnd.nextInt(queue.size());
            } while (n == index);
            index = n;
            loadCurrent(true);
            return;
        }
        if (index + 1 < queue.size()) {
            index++;
            loadCurrent(true);
        } else if (repeat == 1 || !auto) {
            index = 0;
            loadCurrent(true);
        } else {
            index = 0;
            loadCurrent(false); // reached the end: stop on the first track
        }
    }

    private void previous() {
        if (queue.isEmpty()) return;
        if (prepared && mp.getCurrentPosition() > 3000) {
            mp.seekTo(0);
            updateSession();
            return;
        }
        if (index > 0) index--;
        else if (repeat == 1) index = queue.size() - 1;
        loadCurrent(true);
    }

    // ======================================================= session + notif
    private void updateSession() {
        Track t = current();
        if (t == null || session == null) return;
        MediaMetadata.Builder mb = new MediaMetadata.Builder()
                .putString(MediaMetadata.METADATA_KEY_TITLE, t.title)
                .putString(MediaMetadata.METADATA_KEY_ARTIST, t.artist)
                .putString(MediaMetadata.METADATA_KEY_ALBUM, t.album)
                .putLong(MediaMetadata.METADATA_KEY_DURATION, duration());
        if (art != null) mb.putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, art);
        session.setMetadata(mb.build());
        long actions = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE | PlaybackState.ACTION_PLAY_PAUSE
                | PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS
                | PlaybackState.ACTION_SEEK_TO | PlaybackState.ACTION_STOP;
        session.setPlaybackState(new PlaybackState.Builder().setActions(actions)
                .setState(playing ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED,
                        position(), playing ? 1f : 0f, SystemClock.elapsedRealtime()).build());
    }

    private PendingIntent actionPi(String action, int req) {
        return PendingIntent.getService(this, req, new Intent(this, PlayerService.class).setAction(action),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private Notification buildNotification() {
        Track t = current();
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL)
                : new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle(t == null ? "Mika" : t.title)
                .setContentText(t == null ? "" : t.artist)
                .setOngoing(true)
                .setShowWhen(false)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setContentIntent(PendingIntent.getActivity(this, 1, new Intent(this, PlayerActivity.class),
                        PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT));
        if (art != null) b.setLargeIcon(art);
        b.addAction(new Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_media_previous),
                "Previous", actionPi(ACTION_PREV, 10)).build());
        b.addAction(new Notification.Action.Builder(Icon.createWithResource(this,
                playing ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play),
                playing ? "Pause" : "Play", actionPi(ACTION_TOGGLE, 11)).build());
        b.addAction(new Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_media_next),
                "Next", actionPi(ACTION_NEXT, 12)).build());
        b.addAction(new Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
                "Stop", actionPi(ACTION_STOP, 13)).build());
        b.setStyle(new Notification.MediaStyle().setMediaSession(session.getSessionToken())
                .setShowActionsInCompactView(0, 1, 2));
        return b.build();
    }

    private void startForegroundNow() {
        Notification n = buildNotification();
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
            } else {
                startForeground(NOTIF_ID, n);
            }
            foregroundStarted = true;
        } catch (Exception e) {
            foregroundStarted = false;
        }
    }

    private void updateNotification() {
        if (!foregroundStarted) return;
        try {
            nm.notify(NOTIF_ID, buildNotification());
        } catch (Exception ignored) {
        }
    }
}
