package com.mika.launcher;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.widget.ImageView;

/** Modern flat vector icons drawn with Canvas (no bitmap assets, scale to any size, tint-able). */
final class Icons {
    static final int PLAY = 0, PAUSE = 1, PREV = 2, NEXT = 3, GEAR = 4, MAP = 5, PHONE = 6, WIFI = 7,
            BT = 8, MUTE = 9, VOLUME = 10, SEARCH = 11, HOME = 12, NAV = 13, APPS = 14, MUSIC = 15,
            CLOSE = 16, LAYOUT = 24, BOLT = 17, BATTERY = 18, MIC = 19, PLUS = 20, MINUS = 21, TARGET = 22, WORK = 23;

    private Icons() {
    }

    static Drawable get(int type, int color) {
        return new Glyph(type, color);
    }

    static ImageView view(Context c, int type, int sizeDp, int color) {
        ImageView iv = new ImageView(c);
        iv.setImageDrawable(new Glyph(type, color));
        int px = Ui.dp(c, sizeDp);
        iv.setLayoutParams(new android.widget.LinearLayout.LayoutParams(px, px));
        return iv;
    }

    static void set(ImageView iv, int type, int color) {
        iv.setImageDrawable(new Glyph(type, color));
    }

    private static final class Glyph extends Drawable {
        private final int type;
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);

        Glyph(int type, int color) {
            this.type = type;
            fill.setStyle(Paint.Style.FILL);
            fill.setColor(color);
            line.setStyle(Paint.Style.STROKE);
            line.setColor(color);
            line.setStrokeCap(Paint.Cap.ROUND);
            line.setStrokeJoin(Paint.Join.ROUND);
        }

        @Override
        public void draw(Canvas cv) {
            RectF b = new RectF(getBounds());
            float s = Math.min(b.width(), b.height());
            float u = s / 24f; // design grid 24x24
            cv.save();
            cv.translate(b.left + (b.width() - s) / 2f, b.top + (b.height() - s) / 2f);
            cv.scale(u, u);
            line.setStrokeWidth(2.2f);
            Path p = new Path();
            switch (type) {
                case PLAY:
                    p.moveTo(7, 4.5f);
                    p.lineTo(19, 12);
                    p.lineTo(7, 19.5f);
                    p.close();
                    cv.drawPath(p, fill);
                    line.setStrokeWidth(1.6f);
                    cv.drawPath(p, line);
                    break;
                case PAUSE:
                    cv.drawRoundRect(new RectF(6, 4.5f, 10.5f, 19.5f), 1.5f, 1.5f, fill);
                    cv.drawRoundRect(new RectF(13.5f, 4.5f, 18, 19.5f), 1.5f, 1.5f, fill);
                    break;
                case PREV:
                    cv.drawRoundRect(new RectF(5, 5, 7.4f, 19), 1.2f, 1.2f, fill);
                    p.moveTo(19, 5);
                    p.lineTo(9, 12);
                    p.lineTo(19, 19);
                    p.close();
                    cv.drawPath(p, fill);
                    break;
                case NEXT:
                    cv.drawRoundRect(new RectF(16.6f, 5, 19, 19), 1.2f, 1.2f, fill);
                    p.moveTo(5, 5);
                    p.lineTo(15, 12);
                    p.lineTo(5, 19);
                    p.close();
                    cv.drawPath(p, fill);
                    break;
                case GEAR: {
                    line.setStrokeWidth(2f);
                    cv.drawCircle(12, 12, 3.2f, line);
                    for (int i = 0; i < 8; i++) {
                        double a = Math.PI / 4 * i;
                        float x1 = 12 + (float) Math.cos(a) * 6.8f, y1 = 12 + (float) Math.sin(a) * 6.8f;
                        float x2 = 12 + (float) Math.cos(a) * 9.2f, y2 = 12 + (float) Math.sin(a) * 9.2f;
                        line.setStrokeWidth(2.6f);
                        cv.drawLine(x1, y1, x2, y2, line);
                    }
                    line.setStrokeWidth(2f);
                    cv.drawCircle(12, 12, 6.6f, line);
                    break;
                }
                case MAP:
                    p.moveTo(12, 21);
                    p.cubicTo(6, 14.5f, 5, 12, 5, 9.5f);
                    p.cubicTo(5, 5.6f, 8.1f, 3, 12, 3);
                    p.cubicTo(15.9f, 3, 19, 5.6f, 19, 9.5f);
                    p.cubicTo(19, 12, 18, 14.5f, 12, 21);
                    p.close();
                    cv.drawPath(p, fill);
                    Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
                    dot.setColor(0x66000000);
                    cv.drawCircle(12, 9.5f, 2.8f, dot);
                    break;
                case PHONE:
                    p.moveTo(6.6f, 3.5f);
                    p.lineTo(9.4f, 3.5f);
                    p.lineTo(10.6f, 7.6f);
                    p.lineTo(8.8f, 9.2f);
                    p.cubicTo(9.9f, 11.6f, 12.4f, 14.1f, 14.8f, 15.2f);
                    p.lineTo(16.4f, 13.4f);
                    p.lineTo(20.5f, 14.6f);
                    p.lineTo(20.5f, 17.4f);
                    p.cubicTo(20.5f, 19.2f, 19.2f, 20.5f, 17.4f, 20.5f);
                    p.cubicTo(10.2f, 20.1f, 3.9f, 13.8f, 3.5f, 6.6f);
                    p.cubicTo(3.5f, 4.8f, 4.8f, 3.5f, 6.6f, 3.5f);
                    p.close();
                    cv.drawPath(p, fill);
                    break;
                case WIFI: {
                    line.setStrokeWidth(2.2f);
                    RectF a1 = new RectF(3, 3, 21, 21);
                    cv.drawArc(a1, 225, 90, false, line);
                    RectF a2 = new RectF(6.2f, 6.2f, 17.8f, 17.8f);
                    cv.drawArc(a2, 225, 90, false, line);
                    RectF a3 = new RectF(9.2f, 9.2f, 14.8f, 14.8f);
                    cv.drawArc(a3, 225, 90, false, line);
                    cv.drawCircle(12, 15.6f, 1.5f, fill);
                    break;
                }
                case BT:
                    line.setStrokeWidth(2f);
                    p.moveTo(7, 7.5f);
                    p.lineTo(17, 16.5f);
                    p.lineTo(12, 21);
                    p.lineTo(12, 3);
                    p.lineTo(17, 7.5f);
                    p.lineTo(7, 16.5f);
                    cv.drawPath(p, line);
                    break;
                case MUTE:
                case VOLUME: {
                    p.moveTo(4, 9.5f);
                    p.lineTo(8, 9.5f);
                    p.lineTo(13, 5);
                    p.lineTo(13, 19);
                    p.lineTo(8, 14.5f);
                    p.lineTo(4, 14.5f);
                    p.close();
                    cv.drawPath(p, fill);
                    line.setStrokeWidth(2f);
                    if (type == VOLUME) {
                        cv.drawArc(new RectF(10, 8, 18, 16), -50, 100, false, line);
                        cv.drawArc(new RectF(8, 4.5f, 21, 19.5f), -50, 100, false, line);
                    } else {
                        cv.drawLine(16, 9.5f, 21, 14.5f, line);
                        cv.drawLine(21, 9.5f, 16, 14.5f, line);
                    }
                    break;
                }
                case SEARCH:
                    line.setStrokeWidth(2.4f);
                    cv.drawCircle(10.5f, 10.5f, 6, line);
                    cv.drawLine(15, 15, 20, 20, line);
                    break;
                case HOME:
                    p.moveTo(3, 11.5f);
                    p.lineTo(12, 3.5f);
                    p.lineTo(21, 11.5f);
                    p.lineTo(19, 11.5f);
                    p.lineTo(19, 20);
                    p.lineTo(14.5f, 20);
                    p.lineTo(14.5f, 14);
                    p.lineTo(9.5f, 14);
                    p.lineTo(9.5f, 20);
                    p.lineTo(5, 20);
                    p.lineTo(5, 11.5f);
                    p.close();
                    cv.drawPath(p, fill);
                    break;
                case NAV:
                    p.moveTo(12, 2.5f);
                    p.lineTo(19.5f, 20.5f);
                    p.lineTo(12, 16.5f);
                    p.lineTo(4.5f, 20.5f);
                    p.close();
                    cv.drawPath(p, fill);
                    break;
                case APPS: {
                    float[] xs = {4.5f, 10.2f, 15.9f};
                    for (float x : xs) for (float y : xs) cv.drawRoundRect(new RectF(x, y, x + 3.6f, y + 3.6f), 1.1f, 1.1f, fill);
                    break;
                }
                case MUSIC:
                    cv.drawRoundRect(new RectF(14.2f, 3.5f, 16.4f, 16f), 1f, 1f, fill);
                    p.moveTo(14.2f, 3.5f);
                    p.lineTo(20, 5.5f);
                    p.lineTo(20, 9f);
                    p.lineTo(14.2f, 7f);
                    p.close();
                    cv.drawPath(p, fill);
                    cv.drawOval(new RectF(7, 13f, 15.2f, 19.5f), fill);
                    break;
                case LAYOUT:
                    cv.drawRoundRect(new RectF(3.5f, 3.5f, 13, 20.5f), 2.2f, 2.2f, fill);
                    cv.drawRoundRect(new RectF(15, 3.5f, 20.5f, 10.5f), 2.2f, 2.2f, fill);
                    cv.drawRoundRect(new RectF(15, 13, 20.5f, 20.5f), 2.2f, 2.2f, fill);
                    break;
                case CLOSE:
                    line.setStrokeWidth(2.6f);
                    cv.drawLine(6, 6, 18, 18, line);
                    cv.drawLine(18, 6, 6, 18, line);
                    break;
                case BOLT:
                    p.moveTo(13.5f, 2.5f);
                    p.lineTo(5.5f, 13.5f);
                    p.lineTo(11, 13.5f);
                    p.lineTo(10, 21.5f);
                    p.lineTo(18.5f, 10f);
                    p.lineTo(13, 10f);
                    p.close();
                    cv.drawPath(p, fill);
                    break;
                case BATTERY:
                    line.setStrokeWidth(2f);
                    cv.drawRoundRect(new RectF(3, 7, 19, 17), 2.5f, 2.5f, line);
                    cv.drawRoundRect(new RectF(20, 10.2f, 22, 13.8f), 1f, 1f, fill);
                    cv.drawRoundRect(new RectF(5.2f, 9.2f, 14, 14.8f), 1.2f, 1.2f, fill);
                    break;
                case MIC:
                    cv.drawRoundRect(new RectF(9, 3, 15, 14), 3f, 3f, fill);
                    line.setStrokeWidth(2f);
                    cv.drawArc(new RectF(6, 7, 18, 19), 0, 180, false, line);
                    cv.drawLine(12, 19, 12, 22, line);
                    break;
                case PLUS:
                    line.setStrokeWidth(2.8f);
                    cv.drawLine(12, 5, 12, 19, line);
                    cv.drawLine(5, 12, 19, 12, line);
                    break;
                case MINUS:
                    line.setStrokeWidth(2.8f);
                    cv.drawLine(5, 12, 19, 12, line);
                    break;
                case TARGET:
                    line.setStrokeWidth(2f);
                    cv.drawCircle(12, 12, 7, line);
                    cv.drawCircle(12, 12, 2.4f, fill);
                    cv.drawLine(12, 2, 12, 5, line);
                    cv.drawLine(12, 19, 12, 22, line);
                    cv.drawLine(2, 12, 5, 12, line);
                    cv.drawLine(19, 12, 22, 12, line);
                    break;
                case WORK:
                    line.setStrokeWidth(2f);
                    cv.drawRoundRect(new RectF(3.5f, 8, 20.5f, 20), 3f, 3f, line);
                    cv.drawArc(new RectF(8.5f, 3.5f, 15.5f, 11), 180, 180, false, line);
                    cv.drawLine(3.5f, 13.5f, 20.5f, 13.5f, line);
                    break;
                default:
                    break;
            }
            cv.restore();
        }

        @Override
        public void setAlpha(int a) {
            fill.setAlpha(a);
            line.setAlpha(a);
        }

        @Override
        public void setColorFilter(ColorFilter f) {
            fill.setColorFilter(f);
            line.setColorFilter(f);
        }

        @Override
        public int getOpacity() {
            return PixelFormat.TRANSLUCENT;
        }
    }
}
