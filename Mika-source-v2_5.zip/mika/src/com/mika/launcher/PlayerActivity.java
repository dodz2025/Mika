package com.mika.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.media.audiofx.Equalizer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/** Now-playing screen: big album art, seek bar, transport controls, queue, equalizer, sleep timer. */
public class PlayerActivity extends Activity implements MediaTracker.Listener {

    private MediaTracker ext;

    private Pal pal;
    private boolean landscape;
    private ImageView ivArt;
    private TextView tvTitle, tvArtist, tvAlbum, tvPos, tvDur, btnPlay, btnShuffle, btnRepeat, tvSleep;
    private SeekBar seek, vol;
    private boolean seeking = false;
    private final Handler h = new Handler();
    private AudioManager audio;

    private int dp(int v) {
        return Ui.dp(this, v);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        audio = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        handleIntent(getIntent());
        build();
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        handleIntent(i);
    }

    private void handleIntent(Intent i) {
        if (i != null && Intent.ACTION_VIEW.equals(i.getAction()) && i.getData() != null) {
            List<Track> l = new ArrayList<Track>();
            l.add(Track.fromUri(this, i.getData()));
            PlayerService.play(this, l, 0);
            i.setAction(null);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        PlayerService.LISTENERS.add(refresh);
        if (MediaTracker.hasAccess(this)) {
            ext = new MediaTracker(this, this);
            ext.start();
        }
        h.post(ticker);
        refresh.run();
    }

    @Override
    protected void onPause() {
        super.onPause();
        PlayerService.LISTENERS.remove(refresh);
        h.removeCallbacks(ticker);
        if (ext != null) {
            ext.stop();
            ext = null;
        }
    }

    @Override
    public void onMediaChanged() {
        update();
    }

    /** True when another app (Spotify, YouTube Music, ...) is the one playing, not Mika's own player. */
    private boolean useExt() {
        return !PlayerService.active() && ext != null && ext.controller != null && ext.title.length() > 0;
    }

    @Override
    public void onConfigurationChanged(android.content.res.Configuration c) {
        super.onConfigurationChanged(c);
        build();
        refresh.run();
    }

    private final Runnable refresh = new Runnable() {
        @Override
        public void run() {
            update();
        }
    };

    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            if (!seeking && seek != null) {
                int dur = useExt() ? (int) ext.duration : PlayerService.duration();
                int pos = useExt() ? (int) ext.position() : PlayerService.position();
                seek.setMax(Math.max(1, dur));
                seek.setProgress(pos);
                tvPos.setText(Track.fmt(pos));
                tvDur.setText(Track.fmt(dur));
            }
            if (vol != null) vol.setProgress(audio.getStreamVolume(AudioManager.STREAM_MUSIC));
            if (tvSleep != null) {
                long left = PlayerService.sleepAt - System.currentTimeMillis();
                tvSleep.setText(left > 0 ? "\uD83D\uDE34 " + Track.fmt(left) : "");
            }
            h.postDelayed(this, 500);
        }
    };

    // ------------------------------------------------------------------ UI
    private void build() {
        pal = Pal.of(this);
        landscape = getResources().getDisplayMetrics().widthPixels > getResources().getDisplayMetrics().heightPixels;
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{pal.bgTop, pal.bgBottom}));
        root.setPadding(dp(16), dp(10), dp(16), dp(12));

        // top bar
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(btn("\u2190", 20, new View.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        }));
        TextView title = Ui.text(this, "Now playing", 18, pal.text);
        title.setGravity(Gravity.CENTER);
        top.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        tvSleep = Ui.text(this, "", 13, pal.sub);
        top.addView(tvSleep);
        top.addView(spaced(btn("\u266B", 18, new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(PlayerActivity.this, LibraryActivity.class));
            }
        })));
        root.addView(top, new LinearLayout.LayoutParams(-1, -2));

        // art
        ivArt = new ImageView(this);
        ivArt.setScaleType(ImageView.ScaleType.CENTER_CROP);
        ivArt.setBackground(Ui.pill(this, pal.card, 24));

        LinearLayout info = buildInfo();

        if (landscape) {
            LinearLayout row = new LinearLayout(this);
            int size = Math.min(getResources().getDisplayMetrics().heightPixels - dp(110),
                    getResources().getDisplayMetrics().widthPixels / 2 - dp(40));
            row.addView(ivArt, new LinearLayout.LayoutParams(size, size));
            LinearLayout.LayoutParams il = new LinearLayout.LayoutParams(0, -1, 1f);
            il.leftMargin = dp(24);
            row.addView(info, il);
            row.setGravity(Gravity.CENTER);
            root.addView(row, new LinearLayout.LayoutParams(-1, 0, 1f));
        } else {
            int size = Math.min(getResources().getDisplayMetrics().widthPixels - dp(60),
                    getResources().getDisplayMetrics().heightPixels / 2 - dp(40));
            LinearLayout.LayoutParams al = new LinearLayout.LayoutParams(size, size);
            al.gravity = Gravity.CENTER_HORIZONTAL;
            al.topMargin = dp(14);
            root.addView(ivArt, al);
            root.addView(info, new LinearLayout.LayoutParams(-1, 0, 1f));
        }
        setContentView(root);
    }

    private LinearLayout buildInfo() {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER);

        tvTitle = Ui.text(this, "Nothing playing", 24, pal.text);
        tvTitle.setTypeface(Typeface.DEFAULT_BOLD);
        tvTitle.setSingleLine(true);
        tvTitle.setEllipsize(TextUtils.TruncateAt.MARQUEE);
        tvTitle.setSelected(true);
        tvTitle.setGravity(Gravity.CENTER);
        col.addView(tvTitle, new LinearLayout.LayoutParams(-1, -2));
        tvArtist = Ui.text(this, "", 17, pal.accent);
        tvArtist.setGravity(Gravity.CENTER);
        tvArtist.setSingleLine(true);
        col.addView(tvArtist, new LinearLayout.LayoutParams(-1, -2));
        tvAlbum = Ui.text(this, "", 14, pal.sub);
        tvAlbum.setGravity(Gravity.CENTER);
        tvAlbum.setSingleLine(true);
        col.addView(tvAlbum, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout sRow = new LinearLayout(this);
        sRow.setGravity(Gravity.CENTER_VERTICAL);
        tvPos = Ui.text(this, "0:00", 12, pal.sub);
        tvDur = Ui.text(this, "0:00", 12, pal.sub);
        seek = new SeekBar(this);
        seek.setProgressTintList(ColorStateList.valueOf(pal.accent));
        seek.setThumbTintList(ColorStateList.valueOf(pal.accent));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean user) {
                if (user) tvPos.setText(Track.fmt(p));
            }

            public void onStartTrackingTouch(SeekBar s) {
                seeking = true;
            }

            public void onStopTrackingTouch(SeekBar s) {
                seeking = false;
                if (useExt()) ext.seekTo(s.getProgress());
                else PlayerService.seek(s.getProgress());
            }
        });
        sRow.addView(tvPos);
        sRow.addView(seek, new LinearLayout.LayoutParams(0, -2, 1f));
        sRow.addView(tvDur);
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(-1, -2);
        sl.topMargin = dp(14);
        col.addView(sRow, sl);

        LinearLayout ctrl = new LinearLayout(this);
        ctrl.setGravity(Gravity.CENTER);
        btnShuffle = btn("\u21C4", 20, new View.OnClickListener() {
            public void onClick(View v) {
                PlayerService.shuffle = !PlayerService.shuffle;
                update();
            }
        });
        ctrl.addView(spaced(btnShuffle));
        ctrl.addView(spaced(btn("\u23EE", 26, new View.OnClickListener() {
            public void onClick(View v) {
                if (useExt()) ext.prev();
                else if (PlayerService.active()) PlayerService.send(PlayerActivity.this, PlayerService.ACTION_PREV);
            }
        })));
        btnPlay = Ui.button(this, "\u25B6", 34, pal.accent, 0xFFFFFFFF);
        btnPlay.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (useExt()) ext.playPause();
                else if (PlayerService.active()) PlayerService.send(PlayerActivity.this, PlayerService.ACTION_TOGGLE);
                else startActivity(new Intent(PlayerActivity.this, LibraryActivity.class));
            }
        });
        ctrl.addView(spaced(btnPlay));
        ctrl.addView(spaced(btn("\u23ED", 26, new View.OnClickListener() {
            public void onClick(View v) {
                if (useExt()) ext.next();
                else if (PlayerService.active()) PlayerService.send(PlayerActivity.this, PlayerService.ACTION_NEXT);
            }
        })));
        btnRepeat = btn("\uD83D\uDD01", 20, new View.OnClickListener() {
            public void onClick(View v) {
                PlayerService.repeat = (PlayerService.repeat + 1) % 3;
                update();
            }
        });
        ctrl.addView(spaced(btnRepeat));
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(-2, -2);
        cl.topMargin = dp(10);
        col.addView(ctrl, cl);

        LinearLayout extra = new LinearLayout(this);
        extra.setGravity(Gravity.CENTER);
        extra.addView(spaced(btn("Queue", 14, new View.OnClickListener() {
            public void onClick(View v) {
                showQueue();
            }
        })));
        extra.addView(spaced(btn("Equalizer", 14, new View.OnClickListener() {
            public void onClick(View v) {
                showEq();
            }
        })));
        extra.addView(spaced(btn("Sleep timer", 14, new View.OnClickListener() {
            public void onClick(View v) {
                showSleep();
            }
        })));
        LinearLayout.LayoutParams el = new LinearLayout.LayoutParams(-2, -2);
        el.topMargin = dp(8);
        col.addView(extra, el);

        LinearLayout vRow = new LinearLayout(this);
        vRow.setGravity(Gravity.CENTER_VERTICAL);
        vRow.addView(Ui.text(this, "\uD83D\uDD08", 16, pal.sub));
        vol = new SeekBar(this);
        vol.setMax(audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
        vol.setProgressTintList(ColorStateList.valueOf(pal.accent));
        vol.setThumbTintList(ColorStateList.valueOf(pal.accent));
        vol.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean user) {
                if (user) audio.setStreamVolume(AudioManager.STREAM_MUSIC, p, 0);
            }

            public void onStartTrackingTouch(SeekBar s) {
            }

            public void onStopTrackingTouch(SeekBar s) {
            }
        });
        vRow.addView(vol, new LinearLayout.LayoutParams(0, -2, 1f));
        vRow.addView(Ui.text(this, "\uD83D\uDD0A", 16, pal.sub));
        LinearLayout.LayoutParams vl = new LinearLayout.LayoutParams(-1, -2);
        vl.topMargin = dp(8);
        col.addView(vRow, vl);
        return col;
    }

    private TextView btn(String s, int sp, View.OnClickListener l) {
        TextView t = Ui.button(this, s, sp, pal.card, pal.text);
        t.setOnClickListener(l);
        return t;
    }

    private View spaced(View v) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.leftMargin = dp(5);
        lp.rightMargin = dp(5);
        v.setLayoutParams(lp);
        return v;
    }

    private void tint(TextView t, boolean on) {
        t.setBackground(Ui.pill(this, on ? pal.accent : pal.card, 18));
        t.setTextColor(on ? 0xFFFFFFFF : pal.text);
    }

    private void update() {
        if (tvTitle == null) return;
        if (useExt()) {
            tvTitle.setText(ext.title);
            tvArtist.setText(ext.artist);
            tvAlbum.setText("");
            if (ext.art != null) ivArt.setImageBitmap(ext.art);
            else ivArt.setImageDrawable(null);
            btnPlay.setText(ext.playing ? "\u23F8" : "\u25B6");
            tint(btnShuffle, false);
            btnRepeat.setText("\uD83D\uDD01");
            tint(btnRepeat, false);
            return;
        }
        Track t = PlayerService.current();
        if (t == null) {
            tvTitle.setText("Nothing playing");
            tvArtist.setText("Pick a song from your library");
            tvAlbum.setText("");
            ivArt.setImageDrawable(null);
        } else {
            tvTitle.setText(t.title);
            tvArtist.setText(t.artist);
            tvAlbum.setText(t.album);
            Bitmap a = PlayerService.art();
            if (a != null) ivArt.setImageBitmap(a);
            else ivArt.setImageDrawable(null);
        }
        btnPlay.setText(PlayerService.isPlaying() ? "\u23F8" : "\u25B6");
        tint(btnShuffle, PlayerService.shuffle);
        btnRepeat.setText(PlayerService.repeat == 2 ? "\uD83D\uDD02" : "\uD83D\uDD01");
        tint(btnRepeat, PlayerService.repeat != 0);
    }

    // -------------------------------------------------------------- dialogs
    private void showQueue() {
        if (PlayerService.queue.isEmpty()) {
            Toast.makeText(this, "Queue is empty", Toast.LENGTH_SHORT).show();
            return;
        }
        String[] names = new String[PlayerService.queue.size()];
        for (int i = 0; i < names.length; i++) {
            Track t = PlayerService.queue.get(i);
            names[i] = (i == PlayerService.index ? "\u25B6  " : (i + 1) + ".  ") + t.title
                    + (t.artist.length() > 0 ? " \u2014 " + t.artist : "");
        }
        new AlertDialog.Builder(this).setTitle("Queue (" + names.length + ")")
                .setItems(names, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int which) {
                        PlayerService.jumpTo(which);
                    }
                }).setNegativeButton("Close", null).show();
    }

    private void showSleep() {
        final int[] mins = {0, 15, 30, 45, 60, 90};
        String[] labels = {"Off", "15 minutes", "30 minutes", "45 minutes", "1 hour", "1.5 hours"};
        new AlertDialog.Builder(this).setTitle("Sleep timer")
                .setItems(labels, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int which) {
                        PlayerService.setSleepMinutes(mins[which]);
                    }
                }).show();
    }

    private void showEq() {
        List<String> names = new ArrayList<String>();
        names.add("Off");
        try {
            Equalizer probe = new Equalizer(0, 0);
            for (int i = 0; i < probe.getNumberOfPresets(); i++) names.add(probe.getPresetName((short) i));
            probe.release();
        } catch (Throwable t) {
            Toast.makeText(this, "Equalizer isn't available on this device", Toast.LENGTH_SHORT).show();
            return;
        }
        int cur = Prefs.i(this, "eqPreset", -1) + 1;
        new AlertDialog.Builder(this).setTitle("Equalizer preset")
                .setSingleChoiceItems(names.toArray(new String[0]), cur, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int which) {
                        PlayerService.applyEqPreset(PlayerActivity.this, which - 1);
                        d.dismiss();
                    }
                }).show();
    }
}
