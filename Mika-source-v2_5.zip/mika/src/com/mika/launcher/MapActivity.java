package com.mika.launcher;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Full-screen map: GPS follow, place search, long-press to drop a pin, saved places, hand-off to navigation apps. */
public class MapActivity extends Activity implements MapView.Listener {

    private static final int REQ_LOC = 21;
    private static final String UA = "MikaLauncher/2.1 (Android launcher; contact: none)";

    private Pal pal;
    private MapView map;
    private EditText searchBox;
    private TextView speedChip, btnFollow;
    private LinearLayout pinCard;
    private TextView pinTitle, pinSub;
    private LocationManager lm;
    private boolean follow = true;
    private boolean gotFirstFix = false;
    private double pinLat, pinLon;
    private String pinName = "";
    private Location last;

    // ---- saved places (JSON in prefs)
    static List<Object[]> loadPlaces(Context c) {
        List<Object[]> out = new ArrayList<Object[]>();
        try {
            JSONArray a = new JSONArray(Prefs.s(c, "places", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                out.add(new Object[]{o.getString("name"), o.getDouble("lat"), o.getDouble("lon")});
            }
        } catch (Exception ignored) {
        }
        return out;
    }

    static void savePlaces(Context c, List<Object[]> l) {
        JSONArray a = new JSONArray();
        try {
            for (Object[] p : l) {
                JSONObject o = new JSONObject();
                o.put("name", p[0]);
                o.put("lat", p[1]);
                o.put("lon", p[2]);
                a.put(o);
            }
        } catch (Exception ignored) {
        }
        Prefs.putS(c, "places", a.toString());
    }

    private int dp(int v) {
        return Ui.dp(this, v);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        pal = Pal.of(this);
        MapView.trimCache(this);
        lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        FrameLayout root = new FrameLayout(this);
        map = new MapView(this);
        map.setListener(this);
        map.setNight(pal.dark);
        map.setAccent(pal.accent);
        root.addView(map, new FrameLayout.LayoutParams(-1, -1));

        // restore last camera
        map.setCenter(Double.parseDouble(Prefs.s(this, "mapLat", "48.8566")),
                Double.parseDouble(Prefs.s(this, "mapLon", "2.3522")));
        map.setZoom(Prefs.i(this, "mapZoom", 5));
        refreshSaved();

        // top bar: back + search
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(12), dp(10), dp(12), 0);
        TextView back = Ui.button(this, "\u2190", 20, panelColor(), pal.text);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        top.addView(back);
        searchBox = new EditText(this);
        searchBox.setHint("Search places or addresses");
        searchBox.setSingleLine(true);
        searchBox.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        searchBox.setTextColor(pal.text);
        searchBox.setHintTextColor(pal.sub);
        searchBox.setTextSize(16);
        searchBox.setBackground(Ui.pill(this, panelColor(), 18));
        searchBox.setPadding(dp(16), dp(10), dp(16), dp(10));
        searchBox.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent e) {
                doSearch();
                return true;
            }
        });
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(0, -2, 1f);
        sl.leftMargin = dp(10);
        top.addView(searchBox, sl);
        TextView go = Ui.button(this, "Go", 16, pal.accent, 0xFFFFFFFF);
        go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doSearch();
            }
        });
        LinearLayout.LayoutParams gl = new LinearLayout.LayoutParams(-2, -2);
        gl.leftMargin = dp(8);
        top.addView(go, gl);
        root.addView(top, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));

        // speed chip
        speedChip = Ui.button(this, "-- km/h", 18, panelColor(), pal.text);
        FrameLayout.LayoutParams sc = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.START);
        sc.topMargin = dp(70);
        sc.leftMargin = dp(12);
        root.addView(speedChip, sc);

        // right-hand buttons
        LinearLayout side = new LinearLayout(this);
        side.setOrientation(LinearLayout.VERTICAL);
        side.addView(sideBtn("\u2795", new View.OnClickListener() {
            public void onClick(View v) {
                map.zoomBy(1f);
            }
        }));
        side.addView(sideBtn("\u2796", new View.OnClickListener() {
            public void onClick(View v) {
                map.zoomBy(-1f);
            }
        }));
        btnFollow = sideBtn("\uD83C\uDFAF", new View.OnClickListener() {
            public void onClick(View v) {
                follow = true;
                if (last != null) {
                    map.setCenter(last.getLatitude(), last.getLongitude());
                    if (map.getZoom() < 15) map.setZoom(15);
                } else {
                    Toast.makeText(MapActivity.this, "Waiting for location\u2026", Toast.LENGTH_SHORT).show();
                }
                updateFollowBtn();
            }
        });
        side.addView(btnFollow);
        side.addView(sideBtn("\u2B50", new View.OnClickListener() {
            public void onClick(View v) {
                showPlaces();
            }
        }));
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(-2, -2, Gravity.END | Gravity.CENTER_VERTICAL);
        sp.rightMargin = dp(12);
        root.addView(side, sp);

        // pin card
        pinCard = new LinearLayout(this);
        pinCard.setOrientation(LinearLayout.VERTICAL);
        pinCard.setBackground(Ui.pill(this, panelColor(), 22));
        pinCard.setPadding(dp(18), dp(14), dp(18), dp(14));
        pinTitle = Ui.text(this, "", 18, pal.text);
        pinTitle.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        pinSub = Ui.text(this, "", 13, pal.sub);
        pinCard.addView(pinTitle);
        pinCard.addView(pinSub);
        LinearLayout actions = new LinearLayout(this);
        actions.setPadding(0, dp(10), 0, 0);
        actions.addView(pinBtn("Navigate", pal.accent, 0xFFFFFFFF, new View.OnClickListener() {
            public void onClick(View v) {
                navigate();
            }
        }));
        actions.addView(pinBtn("Save", pal.card, pal.text, new View.OnClickListener() {
            public void onClick(View v) {
                savePinDialog();
            }
        }));
        actions.addView(pinBtn("Clear", pal.card, pal.text, new View.OnClickListener() {
            public void onClick(View v) {
                clearPin();
            }
        }));
        pinCard.addView(actions);
        pinCard.setVisibility(View.GONE);
        FrameLayout.LayoutParams pc = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.START);
        pc.leftMargin = dp(12);
        pc.bottomMargin = dp(24);
        root.addView(pinCard, pc);

        setContentView(root);
        updateFollowBtn();
        Toast.makeText(this, "Long-press the map to drop a pin", Toast.LENGTH_SHORT).show();
    }

    private int panelColor() {
        return pal.dark ? 0xE61A1E2A : 0xE6FFFFFF;
    }

    private TextView sideBtn(String glyph, View.OnClickListener l) {
        TextView t = Ui.button(this, glyph, 20, panelColor(), pal.text);
        t.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(54), dp(54));
        lp.bottomMargin = dp(8);
        t.setLayoutParams(lp);
        t.setPadding(0, 0, 0, 0);
        return t;
    }

    private TextView pinBtn(String s, int bg, int fg, View.OnClickListener l) {
        TextView t = Ui.button(this, s, 15, bg, fg);
        t.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.rightMargin = dp(8);
        t.setLayoutParams(lp);
        return t;
    }

    private void updateFollowBtn() {
        btnFollow.setBackground(Ui.pill(this, follow ? pal.accent : panelColor(), 18));
        btnFollow.setTextColor(follow ? 0xFFFFFFFF : pal.text);
    }

    private void refreshSaved() {
        List<double[]> pts = new ArrayList<double[]>();
        for (Object[] p : loadPlaces(this)) pts.add(new double[]{(Double) p[1], (Double) p[2]});
        map.setSaved(pts);
    }

    // -------------------------------------------------------------- lifecycle
    @Override
    protected void onResume() {
        super.onResume();
        startLocation();
    }

    @Override
    protected void onPause() {
        super.onPause();
        try {
            lm.removeUpdates(locListener);
        } catch (Exception ignored) {
        }
        Prefs.putS(this, "mapLat", String.valueOf(map.centerLat()));
        Prefs.putS(this, "mapLon", String.valueOf(map.centerLon()));
        Prefs.putI(this, "mapZoom", Math.round(map.getZoom()));
    }

    private boolean hasPerm() {
        return Build.VERSION.SDK_INT < 23
                || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void startLocation() {
        if (!hasPerm()) {
            if (Build.VERSION.SDK_INT >= 23) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOC);
            }
            return;
        }
        try {
            for (String p : lm.getProviders(true)) {
                if (p.equals(LocationManager.GPS_PROVIDER) || p.equals(LocationManager.NETWORK_PROVIDER)) {
                    lm.requestLocationUpdates(p, 1000, 0, locListener);
                    Location l = lm.getLastKnownLocation(p);
                    if (l != null && (last == null || l.getTime() > last.getTime())) applyLocation(l);
                }
            }
        } catch (SecurityException ignored) {
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        startLocation();
    }

    private final LocationListener locListener = new LocationListener() {
        @Override
        public void onLocationChanged(Location l) {
            applyLocation(l);
        }

        @Override
        public void onStatusChanged(String p, int s, Bundle e) {
        }

        @Override
        public void onProviderEnabled(String p) {
        }

        @Override
        public void onProviderDisabled(String p) {
        }
    };

    private void applyLocation(Location l) {
        // prefer GPS fixes over network fixes when both are recent
        if (last != null && LocationManager.GPS_PROVIDER.equals(last.getProvider())
                && !LocationManager.GPS_PROVIDER.equals(l.getProvider())
                && l.getTime() - last.getTime() < 10000) return;
        last = l;
        map.setMe(l);
        boolean mph = Prefs.b(this, "speedMph", false);
        float v = l.hasSpeed() ? l.getSpeed() * (mph ? 2.23694f : 3.6f) : 0f;
        speedChip.setText(Math.round(v) + (mph ? " mph" : " km/h"));
        if (!gotFirstFix) {
            gotFirstFix = true;
            map.setCenter(l.getLatitude(), l.getLongitude());
            if (map.getZoom() < 14) map.setZoom(15);
        } else if (follow) {
            map.setCenter(l.getLatitude(), l.getLongitude());
        }
    }

    // ----------------------------------------------------------- map callbacks
    @Override
    public void onUserMoved() {
        if (follow) {
            follow = false;
            updateFollowBtn();
        }
    }

    @Override
    public void onTap() {
        hideKeyboard();
    }

    @Override
    public void onLongPress(double lat, double lon) {
        dropPin(lat, lon, null);
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(searchBox.getWindowToken(), 0);
    }

    // --------------------------------------------------------------- pins
    private void dropPin(final double lat, final double lon, String name) {
        pinLat = lat;
        pinLon = lon;
        pinName = name == null ? "" : name;
        map.setPin(lat, lon);
        pinTitle.setText(name == null ? "Dropped pin" : name);
        pinSub.setText(String.format(Locale.US, "%.5f, %.5f", lat, lon));
        pinCard.setVisibility(View.VISIBLE);
        if (name == null) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        JSONObject o = new JSONObject(get("https://nominatim.openstreetmap.org/reverse?format=json&zoom=17&lat="
                                + lat + "&lon=" + lon));
                        final String addr = o.optString("display_name", "");
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (pinLat == lat && pinLon == lon && addr.length() > 0) {
                                    pinName = addr.split(",")[0];
                                    pinTitle.setText(pinName);
                                    pinSub.setText(addr);
                                }
                            }
                        });
                    } catch (Exception ignored) {
                    }
                }
            }).start();
        }
    }

    private void clearPin() {
        map.clearPin();
        pinCard.setVisibility(View.GONE);
    }

    private void navigate() {
        try {
            String label = Uri.encode(pinName.length() > 0 ? pinName : "Destination");
            Uri uri = Uri.parse(String.format(Locale.US, "geo:%f,%f?q=%f,%f(%s)", pinLat, pinLon, pinLat, pinLon, label));
            Intent i = new Intent(Intent.ACTION_VIEW, uri);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "Install a navigation app (Google Maps, Waze, OsmAnd\u2026) to get directions",
                    Toast.LENGTH_LONG).show();
        }
    }

    private void savePinDialog() {
        final EditText et = new EditText(this);
        et.setText(pinName.length() > 0 ? pinName : "");
        et.setHint("Name (e.g. Home, Work)");
        new AlertDialog.Builder(this).setTitle("Save place").setView(et)
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        String n = et.getText().toString().trim();
                        if (n.length() == 0) n = "Saved place";
                        List<Object[]> l = loadPlaces(MapActivity.this);
                        l.add(new Object[]{n, pinLat, pinLon});
                        savePlaces(MapActivity.this, l);
                        refreshSaved();
                        Toast.makeText(MapActivity.this, "Saved \u201C" + n + "\u201D", Toast.LENGTH_SHORT).show();
                    }
                }).setNegativeButton("Cancel", null).show();
    }

    private void showPlaces() {
        final List<Object[]> l = loadPlaces(this);
        if (l.isEmpty()) {
            Toast.makeText(this, "No saved places yet. Long-press the map, then tap Save.", Toast.LENGTH_LONG).show();
            return;
        }
        String[] names = new String[l.size()];
        for (int i = 0; i < names.length; i++) names[i] = "\u2B50  " + l.get(i)[0];
        new AlertDialog.Builder(this).setTitle("Saved places")
                .setItems(names, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        Object[] p = l.get(which);
                        follow = false;
                        updateFollowBtn();
                        map.setCenter((Double) p[1], (Double) p[2]);
                        map.setZoom(Math.max(map.getZoom(), 15));
                        dropPin((Double) p[1], (Double) p[2], String.valueOf(p[0]));
                    }
                })
                .setNeutralButton("Delete\u2026", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        deletePlaceDialog();
                    }
                })
                .setNegativeButton("Close", null).show();
    }

    private void deletePlaceDialog() {
        final List<Object[]> l = loadPlaces(this);
        String[] names = new String[l.size()];
        for (int i = 0; i < names.length; i++) names[i] = String.valueOf(l.get(i)[0]);
        new AlertDialog.Builder(this).setTitle("Delete which place?")
                .setItems(names, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        l.remove(which);
                        savePlaces(MapActivity.this, l);
                        refreshSaved();
                    }
                }).setNegativeButton("Cancel", null).show();
    }

    // ---------------------------------------------------------------- search
    private static String get(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestProperty("User-Agent", UA);
        c.setRequestProperty("Accept-Language", Locale.getDefault().getLanguage());
        c.setConnectTimeout(8000);
        c.setReadTimeout(8000);
        try {
            BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
            r.close();
            return sb.toString();
        } finally {
            c.disconnect();
        }
    }

    private void doSearch() {
        final String q = searchBox.getText().toString().trim();
        hideKeyboard();
        if (q.length() == 0) return;
        Toast.makeText(this, "Searching\u2026", Toast.LENGTH_SHORT).show();
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    JSONArray arr = new JSONArray(get("https://nominatim.openstreetmap.org/search?format=json&limit=6&q="
                            + URLEncoder.encode(q, "UTF-8")));
                    final List<String> names = new ArrayList<String>();
                    final List<double[]> pts = new ArrayList<double[]>();
                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject o = arr.getJSONObject(i);
                        names.add(o.optString("display_name"));
                        pts.add(new double[]{o.getDouble("lat"), o.getDouble("lon")});
                    }
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            showResults(names, pts);
                        }
                    });
                } catch (Exception e) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(MapActivity.this, "Search failed. Check your connection.",
                                    Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
        }).start();
    }

    private void showResults(final List<String> names, final List<double[]> pts) {
        if (names.isEmpty()) {
            Toast.makeText(this, "No results", Toast.LENGTH_SHORT).show();
            return;
        }
        new AlertDialog.Builder(this).setTitle("Results")
                .setItems(names.toArray(new String[0]), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        double[] p = pts.get(which);
                        follow = false;
                        updateFollowBtn();
                        map.setCenter(p[0], p[1]);
                        map.setZoom(16);
                        dropPin(p[0], p[1], names.get(which).split(",")[0]);
                    }
                }).show();
    }
}
