package com.mika.launcher;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.widget.ImageView;

/** Image view with pinch-zoom, pan, double-tap zoom and left/right swipe callbacks. */
public class ZoomImageView extends ImageView {

    interface Listener {
        void onSwipe(int direction); // +1 next, -1 previous

        void onTap();
    }

    private final Matrix m = new Matrix();
    private final float[] v = new float[9];
    private float minScale = 1f;
    private Bitmap bmp;
    private Listener listener;
    private final ScaleGestureDetector sgd;
    private final GestureDetector gd;

    public ZoomImageView(Context c) {
        super(c);
        setScaleType(ScaleType.MATRIX);
        sgd = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector d) {
                float cur = scale();
                float f = d.getScaleFactor();
                float target = Math.max(minScale, Math.min(minScale * 6f, cur * f));
                f = target / cur;
                m.postScale(f, f, d.getFocusX(), d.getFocusY());
                clamp();
                setImageMatrix(m);
                return true;
            }
        });
        gd = new GestureDetector(c, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onScroll(MotionEvent e1, MotionEvent e2, float dx, float dy) {
                if (sgd.isInProgress() || scale() <= minScale * 1.02f) return false;
                m.postTranslate(-dx, -dy);
                clamp();
                setImageMatrix(m);
                return true;
            }

            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2, float vx, float vy) {
                if (scale() <= minScale * 1.02f && Math.abs(vx) > 1000 && Math.abs(vx) > Math.abs(vy) * 1.5f
                        && listener != null) {
                    listener.onSwipe(vx < 0 ? 1 : -1);
                    return true;
                }
                return false;
            }

            @Override
            public boolean onDoubleTap(MotionEvent e) {
                if (scale() > minScale * 1.5f) {
                    fit();
                } else {
                    float f = (minScale * 2.5f) / scale();
                    m.postScale(f, f, e.getX(), e.getY());
                    clamp();
                    setImageMatrix(m);
                }
                return true;
            }

            @Override
            public boolean onSingleTapConfirmed(MotionEvent e) {
                if (listener != null) listener.onTap();
                return true;
            }
        });
    }

    void setListener(Listener l) {
        listener = l;
    }

    void setBitmapFit(Bitmap b) {
        bmp = b;
        setImageBitmap(b);
        fit();
    }

    private float scale() {
        m.getValues(v);
        return v[Matrix.MSCALE_X];
    }

    private void fit() {
        if (bmp == null || getWidth() == 0) return;
        float s = Math.min((float) getWidth() / bmp.getWidth(), (float) getHeight() / bmp.getHeight());
        minScale = s;
        m.reset();
        m.postScale(s, s);
        m.postTranslate((getWidth() - bmp.getWidth() * s) / 2f, (getHeight() - bmp.getHeight() * s) / 2f);
        setImageMatrix(m);
    }

    private void clamp() {
        if (bmp == null) return;
        m.getValues(v);
        float s = v[Matrix.MSCALE_X];
        float cw = bmp.getWidth() * s, ch = bmp.getHeight() * s;
        float tx = v[Matrix.MTRANS_X], ty = v[Matrix.MTRANS_Y];
        float nx = tx, ny = ty;
        if (cw <= getWidth()) nx = (getWidth() - cw) / 2f;
        else nx = Math.max(getWidth() - cw, Math.min(0, tx));
        if (ch <= getHeight()) ny = (getHeight() - ch) / 2f;
        else ny = Math.max(getHeight() - ch, Math.min(0, ty));
        m.postTranslate(nx - tx, ny - ty);
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        fit();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        sgd.onTouchEvent(e);
        gd.onTouchEvent(e);
        return true;
    }
}
