Mika launcher 2.5 - source
Build: needs aapt (v1), JDK 17+, dalvik-exchange (dx), zipalign, apksigner and an android.jar (API 33).
  ANDROID_JAR=/path/to/android.jar ./build.sh
Output: build/Mika-Launcher.apk (debug-signed; create ~/.android/debug.keystore first, or edit build.sh).
Source layout: src/com/mika/launcher/*.java, res/, AndroidManifest.xml
