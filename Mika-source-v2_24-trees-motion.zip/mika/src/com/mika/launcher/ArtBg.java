package com.mika.launcher;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.os.SystemClock;

/**
 * Card background: blurred album art (centre-cropped) under a theme-coloured scrim, with rounded corners.
 * Call {@link #animate(Drawable)} for the player: the same picture then drifts and breathes very slowly,
 * two soft glows in the cover's own colour float over it, a faint light sweep passes now and then,
 * and a new cover cross-fades in from the previous background.
 */
final class ArtBg extends Drawable implements Runnable {
    private final Bitmap bmp;
    private final float radius;
    private final boolean dark;
    private final int strokeColor;
    private final float strokeW;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint scrim = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fx = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path clip = new Path();
    private final RectF rect = new RectF();
    private final Rect src = new Rect();
    private final Matrix mx = new Matrix();

    // motion (off unless animate() is called)
    private boolean moving;
    private Drawable prev;
    private long startMs;
    private boolean running;
    private int glowColor = 0xFFFFFFFF;
    private static final long FADE_MS = 700L;
    private static final long FRAME_MS = 33L; // ~30 fps is plenty for a slow background

    ArtBg(Bitmap blurred, float radiusPx, boolean dark, int strokeColor, float strokePx) {
        bmp = blurred;
        radius = radiusPx;
        this.dark = dark;
        this.strokeColor = strokeColor;
        strokeW = strokePx;
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(strokePx);
        stroke.setColor(strokeColor);
    }

    /** Turns the slow motion on. {@code from} is the background being replaced (cross-faded), or null. */
    ArtBg animate(Drawable from) {
        moving = true;
        prev = from instanceof ArtBg ? from : null;
        startMs = SystemClock.uptimeMillis();
        glowColor = vivid(bmp);
        return this;
    }

    /** The most colourful average of the (tiny) blurred cover, lifted so it glows. */
    private static int vivid(Bitmap b) {
        try {
            int w = b.getWidth(), h = b.getHeight();
            float[] best = null;
            float bestS = -1f;
            float[] hsv = new float[3];
            for (int gy = 0; gy < 3; gy++) {
                for (int gx = 0; gx < 3; gx++) {
                    int p = b.getPixel(Math.min(w - 1, (gx * 2 + 1) * w / 6), Math.min(h - 1, (gy * 2 + 1) * h / 6));
                    android.graphics.Color.colorToHSV(p, hsv);
                    float score = hsv[1] * (0.35f + hsv[2]);
                    if (score > bestS) {
                        bestS = score;
                        best = hsv.clone();
                    }
                }
            }
            if (best == null) return 0xFFFFFFFF;
            best[1] = Math.min(1f, best[1] * 1.1f + 0.1f);
            best[2] = Math.max(0.75f, best[2]);
            return android.graphics.Color.HSVToColor(best);
        } catch (Throwable t) {
            return 0xFFFFFFFF;
        }
    }

    @Override
    protected void onBoundsChange(Rect b) {
        rect.set(b);
        clip.reset();
        clip.addRoundRect(rect, radius, radius, Path.Direction.CW);
        // centre-crop source rect
        float bw = bmp.getWidth(), bh = bmp.getHeight();
        float s = Math.max(b.width() / bw, b.height() / bh);
        int sw = Math.round(b.width() / s), sh = Math.round(b.height() / s);
        int sx = Math.max(0, (int) ((bw - sw) / 2)), sy = Math.max(0, (int) ((bh - sh) / 2));
        src.set(sx, sy, Math.min((int) bw, sx + sw), Math.min((int) bh, sy + sh));
        int top = dark ? 0x77000000 : 0x88FFFFFF, bot = dark ? 0xC0000000 : 0xDDFFFFFF;
        scrim.setShader(new LinearGradient(0, b.top, 0, b.bottom, top, bot, Shader.TileMode.CLAMP));
        if (prev != null) prev.setBounds(b);
    }

    @Override
    public void draw(Canvas c) {
        float t = moving ? (SystemClock.uptimeMillis() - startMs) / 1000f : 0f;
        float fade = 1f;
        if (moving && prev != null) {
            long el = SystemClock.uptimeMillis() - startMs;
            if (el >= FADE_MS) {
                prev = null;
            } else {
                fade = el / (float) FADE_MS;
                fade = fade * fade * (3f - 2f * fade);          // smoothstep
                prev.draw(c);
            }
        }
        int sv = c.save();
        c.clipPath(clip);
        int layer = -1;
        if (fade < 1f) layer = c.saveLayerAlpha(rect, (int) (255 * fade), Canvas.ALL_SAVE_FLAG);
        if (moving) {
            // Ken Burns: slow zoom "breathing" plus a lazy drift; 1.14x leaves enough margin so no edge ever shows
            float zoom = 1.14f + 0.04f * (float) Math.sin(t * 0.21f);
            float dx = rect.width() * 0.035f * (float) Math.sin(t * 0.13f + 0.7f);
            float dy = rect.height() * 0.030f * (float) Math.cos(t * 0.10f);
            mx.setRectToRect(new RectF(src), rect, Matrix.ScaleToFit.FILL);
            mx.postScale(zoom, zoom, rect.centerX(), rect.centerY());
            mx.postTranslate(dx, dy);
            c.drawBitmap(bmp, mx, paint);
        } else {
            c.drawBitmap(bmp, src, rect, paint);
        }
        c.drawRect(rect, scrim);
        if (moving) drawGlow(c, t);
        if (layer >= 0) c.restoreToCount(layer);
        c.restoreToCount(sv);
        if (strokeW > 0) {
            float h = strokeW / 2f;
            c.drawRoundRect(new RectF(rect.left + h, rect.top + h, rect.right - h, rect.bottom - h), radius, radius, stroke);
        }
        if (moving && !running) {
            running = true;
            scheduleSelf(this, SystemClock.uptimeMillis() + FRAME_MS);
        }
    }

    /** Two soft glows in the cover colour on slow looping paths, plus a faint diagonal light sweep every ~16 s. */
    private void drawGlow(Canvas c, float t) {
        float w = rect.width(), h = rect.height(), big = Math.max(w, h);
        int a = dark ? 70 : 46;
        int col = glowColor & 0x00FFFFFF;
        float x1 = rect.left + w * (0.30f + 0.28f * (float) Math.sin(t * 0.16f));
        float y1 = rect.top + h * (0.30f + 0.20f * (float) Math.cos(t * 0.12f));
        fx.setShader(new RadialGradient(x1, y1, big * 0.62f, (a << 24) | col, col, Shader.TileMode.CLAMP));
        c.drawRect(rect, fx);
        float x2 = rect.left + w * (0.72f + 0.24f * (float) Math.cos(t * 0.14f + 1.3f));
        float y2 = rect.top + h * (0.72f + 0.18f * (float) Math.sin(t * 0.11f + 0.4f));
        fx.setShader(new RadialGradient(x2, y2, big * 0.55f, ((int) (a * 0.8f) << 24) | col, col, Shader.TileMode.CLAMP));
        c.drawRect(rect, fx);
        // light sweep: a narrow soft band that crosses the screen diagonally, then rests
        float cyc = (t % 16f) / 16f;
        if (cyc < 0.5f) {
            float k = cyc / 0.5f;
            float pos = -0.3f + 1.6f * k;                        // along the diagonal, from off-screen to off-screen
            float env = (float) Math.sin(Math.PI * k);           // fades in and out
            float cx = rect.left + w * pos, cy = rect.top + h * pos * 0.55f;
            float bw = big * 0.28f;
            int sa = (int) ((dark ? 30 : 38) * env);
            if (sa > 0) {
                int white = 0x00FFFFFF;
                fx.setShader(new LinearGradient(cx - bw, cy - bw * 0.8f, cx + bw, cy + bw * 0.8f,
                        new int[]{white, (sa << 24) | white, white}, new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
                c.drawRect(rect, fx);
            }
        }
        fx.setShader(null);
    }

    @Override
    public void run() {
        running = false;
        if (moving) {
            invalidateSelf();
        }
    }

    @Override
    public boolean setVisible(boolean visible, boolean restart) {
        boolean ch = super.setVisible(visible, restart);
        if (moving) {
            if (!visible) {
                unscheduleSelf(this);
                running = false;
            } else if (!running) {
                invalidateSelf();
            }
        }
        return ch;
    }

    @Override
    public void setAlpha(int a) {
        paint.setAlpha(a);
    }

    @Override
    public void setColorFilter(ColorFilter cf) {
        paint.setColorFilter(cf);
    }

    @Override
    public int getOpacity() {
        return PixelFormat.TRANSLUCENT;
    }
}
