package com.mika.launcher;

import android.content.Context;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import android.os.SystemClock;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

import javax.microedition.khronos.egl.EGL10;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.egl.EGLDisplay;
import javax.microedition.khronos.opengles.GL10;

/**
 * OpenGL ES 2.0 view of the user's car (assets/car.glb). Speed-driven: the wheels spin, the road
 * scrolls and the body settles with the GPS speed, and everything eases to a halt when the car stops.
 */
class Car3DView extends GLSurfaceView implements GLSurfaceView.Renderer {
    private static final String CAR_VS =
            "uniform mat4 uVP; uniform mat4 uM;\n"
                    + "attribute vec3 aPos; attribute vec3 aNrm; attribute vec4 aCol;\n"
                    + "varying vec3 vN; varying vec3 vP; varying vec4 vC;\n"
                    + "void main(){ vec4 w = uM*vec4(aPos,1.0); vP = w.xyz; vN = (uM*vec4(aNrm,0.0)).xyz; vC = aCol;\n"
                    + "  gl_Position = uVP*w; }\n";
    private static final String CAR_FS =
            "precision mediump float;\n"
                    + "uniform vec3 uEye; uniform vec3 uAccent; uniform float uDay; uniform float uLights; uniform vec3 uSky;\n"
                    + "uniform vec3 uPaint; uniform float uBrake; uniform vec3 uKey; uniform float uQ;\n"
                    + "varying vec3 vN; varying vec3 vP; varying vec4 vC;\n"
                    + "void main(){\n"
                    + "  vec3 n = normalize(vN); vec3 v = normalize(uEye - vP);\n"
                    + "  if (dot(n, v) < 0.0) n = -n;\n"
                    + "  vec3 l = normalize(uKey);\n"
                    + "  float d = max(dot(n, l), 0.0) * (0.72 + 0.34 * uDay);\n"
                    + "  float fill = max(dot(n, normalize(vec3(-uKey.x * 1.55, 0.25, -0.6))), 0.0) * 0.22;\n"
                    + "  float hemi = (0.34 + 0.16 * n.y) * (0.88 + 0.30 * uDay);\n"
                    + "  vec3 amb = mix(vec3(1.0), uSky * 1.5 + 0.1, 0.22);\n"
                    + "  vec3 h = normalize(l + v);\n"
                    + "  float sp = pow(max(dot(n, h), 0.0), 40.0) * (0.75 + 0.25 * uDay);\n"
                    + "  vec3 base = vC.a < -0.5 ? uPaint : vC.rgb;\n"
                    + "  float lum = dot(base, vec3(0.3, 0.59, 0.11));\n"
                    + "  float gloss = 0.25 + 0.5 * (1.0 - lum);\n"
                    + "  float rim = pow(1.0 - max(dot(n, v), 0.0), 3.0);\n"
                    + "  vec3 col = base * (hemi * amb + d * 0.85 + fill) + vec3(sp * gloss) + uAccent * rim * 0.28;\n"
                    // High: sky / road reflection in the paint, a tight highlight and darker rocker panels and arches
                    + "  if (uQ > 0.5) {\n"
                    + "    float ndv = max(dot(n, v), 0.0);\n"
                    + "    vec3 rf = reflect(-v, n);\n"
                    + "    float upR = smoothstep(-0.25, 0.85, rf.y);\n"
                    + "    vec3 env = mix(uSky * 0.30, uSky * 1.15 + 0.06, upR);\n"
                    + "    float fres = 0.05 + 0.95 * pow(1.0 - ndv, 4.0);\n"
                    + "    float pk = vC.a < -0.5 ? 0.55 : 0.16;\n"
                    + "    col += env * fres * pk * (0.55 + 0.45 * gloss);\n"
                    + "    col += vec3(pow(max(dot(n, h), 0.0), 140.0) * 0.55 * (0.5 + 0.5 * uDay));\n"
                    + "    col *= mix(0.62, 1.0, smoothstep(0.04, 0.55, vP.y));\n"
                    + "  }\n"
                    + "  if (vC.a > 0.5) {\n"
                    + "    bool tail = vC.a > 1.5;\n"
                    + "    vec3 lamp = tail ? vec3(1.0, 0.10, 0.06) : vec3(1.0, 0.95, 0.80);\n"
                    + "    float L = tail ? max(uLights, uBrake) : uLights;\n"
                    + "    col = mix(col, lamp, 0.10 + 0.80 * L) + lamp * L * 0.9;\n"
                    + "  }\n"
                    + "  gl_FragColor = vec4(col, 1.0);\n"
                    + "}\n";
    private static final String GND_VS =
            "uniform mat4 uVP; attribute vec3 aPos; varying vec3 vP;\n"
                    + "void main(){ vP = aPos; gl_Position = uVP*vec4(aPos,1.0); }\n";
    private static final String GND_FS =
            "#ifdef GL_FRAGMENT_PRECISION_HIGH\nprecision highp float;\n#else\nprecision mediump float;\n#endif\n"
                    + "uniform float uScroll; uniform vec3 uEye; uniform vec3 uAccent; uniform vec3 uFog; uniform vec3 uAsphalt;\n"
                    + "uniform float uLights; uniform vec2 uHead; uniform vec2 uTail;\n"
                    + "uniform float uMist; uniform float uWet; uniform float uFlash; uniform float uNav; uniform vec3 uJ; uniform vec2 uJd;\n"
                    + "uniform vec3 uGrass; uniform float uScn; uniform float uSS; uniform float uLamp; uniform float uSnowG; uniform float uQ;\n"
                    + "varying vec3 vP;\n"
                    + "float h21(vec2 c){ return fract(sin(dot(c, vec2(12.9898, 78.233))) * 43758.5453); }\n"
                    // value noise that repeats every `per` cells along x, so the ring of scenery wraps without a seam
                    + "float vn(vec2 p, float per){ vec2 i = floor(p); vec2 f = fract(p); f = f * f * (3.0 - 2.0 * f);\n"
                    + "  float a = h21(vec2(mod(i.x, per), i.y)); float b = h21(vec2(mod(i.x + 1.0, per), i.y));\n"
                    + "  float c = h21(vec2(mod(i.x, per), i.y + 1.0)); float d = h21(vec2(mod(i.x + 1.0, per), i.y + 1.0));\n"
                    + "  return mix(mix(a, b, f.x), mix(c, d, f.x), f.y); }\n"
                    + "void main(){\n"
                    + "  vec2 p = vP.xz; float az = abs(p.y);\n"
                    + "  float dist = length(vP - uEye);\n"
                    + "  float road = 1.0 - smoothstep(5.3, 5.7, az);\n"
                    + "  float gx = p.x + uSS;\n"
                    + "  vec3 off = uAsphalt * 0.55;\n"
                    + "  float grain = 0.0;\n"
                    + "  if (uScn > 0.5) {\n"
                    + "    float n1 = vn(vec2(gx / 4.0, p.y / 4.0), 80.0);\n"
                    + "    float n2 = 0.5;\n"
                    + "    if (dist < 90.0) n2 = vn(vec2(gx / 1.6, p.y / 1.6), 200.0);\n"
                    + "    vec3 gr = uGrass * (0.78 + 0.34 * n1 + 0.18 * n2);\n"
                    + "    float lm = dot(uFog, vec3(0.30, 0.59, 0.11));\n"
                    + "    gr = mix(gr, vec3(0.86, 0.90, 0.96) * (0.30 + 0.70 * lm), uSnowG * (0.75 + 0.25 * n2));\n"
                    + "    vec3 gravel = uAsphalt * 1.45 + vec3(0.03);\n"
                    + "    off = mix(gravel, gr, smoothstep(5.9, 6.7, az));\n"
                    + "    if (dist < 38.0) grain = (vn(vec2(gx / 0.5, p.y / 0.5), 640.0) - 0.5) * (1.0 - smoothstep(14.0, 38.0, dist));\n"
                    + "  }\n"
                    + "  vec3 col = mix(off, uAsphalt * (1.0 + 0.10 * grain), road);\n"
                    + "  float band = 0.5 + 0.5 * sin((p.x + uScroll) * 2.0943951);\n"
                    + "  col *= 0.96 + 0.04 * band * road;\n"
                    // lane dashes soften with distance so they do not shimmer
                    + "  float fx = clamp(0.00035 * dist * dist, 0.012, 0.9);\n"
                    + "  float m6 = mod(p.x + uScroll, 6.0);\n"
                    + "  float dash = smoothstep(0.0, fx, m6) * (1.0 - smoothstep(3.0 - fx, 3.0 + fx, m6));\n"
                    + "  float ll = (1.0 - smoothstep(0.06, 0.11 + 0.0008 * dist, abs(az - 2.75))) * dash;\n"
                    + "  col = mix(col, vec3(0.86), ll * 0.85);\n"
                    // side road at the next turn: flared mouth, asphalt, soft edge lines (uJ = junction x, side, fade; uJd = direction)
                    + "  float mm = 0.0;\n"
                    + "  if (uJ.z > 0.01) {\n"
                    + "    vec2 q = p - vec2(uJ.x, uJ.y * 4.0);\n"
                    + "    float t = dot(q, uJd); float l = dot(q, vec2(-uJd.y, uJd.x));\n"
                    + "    float hw = 3.1 + 2.7 * exp(-max(t, 0.0) / 2.3);\n"
                    + "    mm = (1.0 - smoothstep(hw - 0.12, hw + 0.12, abs(l))) * smoothstep(-0.2, 0.3, t) * uJ.z;\n"
                    + "    col = mix(col, uAsphalt * (1.0 + 0.10 * grain), mm);\n"
                    + "    float bl = (1.0 - smoothstep(0.05, 0.10, abs(abs(l) - 2.75))) * smoothstep(3.5, 6.0, t) * uJ.z;\n"
                    + "    col = mix(col, vec3(0.80), bl * 0.65);\n"
                    + "  }\n"
                    // navigation: a soft route ribbon with scrolling chevrons in the car's lane, ahead of the car
                    + "  if (uNav > 0.01) {\n"
                    + "    float lat = abs(p.y);\n"
                    + "    float ahead = smoothstep(1.6, 3.6, p.x) * (1.0 - smoothstep(24.0, 60.0, p.x)) * uNav;\n"
                    + "    float core = 1.0 - smoothstep(0.36, 0.56, lat);\n"
                    + "    float rim = 1.0 - smoothstep(0.03, 0.08, abs(lat - 0.50));\n"
                    + "    float u = mod(p.x + uScroll, 3.0) - 1.5;\n"
                    + "    float chev = (1.0 - smoothstep(0.06, 0.14, abs(u - (0.45 - 1.2 * lat)))) * (1.0 - step(0.5, lat));\n"
                    + "    col = mix(col, uAccent, core * 0.30 * ahead);\n"
                    + "    col = mix(col, uAccent, rim * 0.55 * ahead);\n"
                    + "    col = mix(col, mix(uAccent, vec3(1.0), 0.70), chev * 0.90 * ahead);\n"
                    + "  }\n"
                    + "  float e = abs(az - 5.15);\n"
                    + "  col += uAccent * 0.30 * exp(-e * 4.0) * (1.0 - mm);\n"
                    + "  col = mix(col, uAccent, (1.0 - smoothstep(0.05, 0.13, e)) * 0.95 * (1.0 - mm));\n"
                    + "  float d = length(vec2(p.x / 2.9, p.y / 1.25));\n"
                    + "  col *= mix(mix(0.25, 0.50, uScn), 1.0, smoothstep(0.7, 1.3, d));\n"
                    + "  col *= 1.0 - 0.22 * uWet;\n"
                    // High: aggregate speckle and patchy wear on the asphalt, and a sky sheen on wet road at low angles
                    + "  if (uQ > 0.5) {\n"
                    + "    if (dist < 22.0 && road > 0.5) {\n"
                    + "      float spk = h21(vec2(mod(floor(gx * 18.0), 5760.0), floor(p.y * 18.0)));\n"
                    + "      col *= 1.0 + (spk - 0.5) * 0.16 * (1.0 - smoothstep(8.0, 22.0, dist));\n"
                    + "    }\n"
                    + "    float wear = vn(vec2(gx / 8.0, p.y / 8.0), 40.0);\n"
                    + "    col *= mix(1.0, 0.90 + 0.20 * wear, road * (1.0 - smoothstep(30.0, 90.0, dist)));\n"
                    + "    if (uWet > 0.02) {\n"
                    + "      float fr = pow(1.0 - clamp((uEye.y - vP.y) / max(dist, 0.001), 0.0, 1.0), 4.0);\n"
                    + "      col = mix(col, uFog * 0.85 + 0.04, road * uWet * (0.15 + 0.55 * fr));\n"
                    + "    }\n"
                    + "  }\n"
                    // head-light beams in front of the car, red glow behind it
                    + "  vec3 add = vec3(0.0);\n"
                    + "  for (int i = 0; i < 2; i++) {\n"
                    + "    float sg = i == 0 ? -1.0 : 1.0;\n"
                    + "    float t = max(p.x - uHead.x, 0.0);\n"
                    + "    float w = 0.34 + 0.22 * t;\n"
                    + "    float lat = p.y - (sg * uHead.y + sg * 0.05 * t);\n"
                    + "    float beam = exp(-(lat * lat) / (w * w)) * exp(-t * 0.10) * smoothstep(-0.3, 0.8, p.x - uHead.x);\n"
                    + "    add += vec3(1.0, 0.93, 0.74) * beam * 0.80;\n"
                    + "    float tt = max(uTail.x - p.x, 0.0);\n"
                    + "    float wt = 0.30 + 0.24 * tt;\n"
                    + "    float latT = p.y - sg * uTail.y;\n"
                    + "    float tail = exp(-(latT * latT) / (wt * wt)) * exp(-tt * 0.55) * smoothstep(-0.3, 0.5, uTail.x - p.x);\n"
                    + "    add += vec3(1.0, 0.10, 0.06) * tail * 0.50;\n"
                    + "  }\n"
                    + "  col += add * uLights * (1.0 + 0.9 * uWet);\n"
                    // street-lamp light pools (lamps stand every 40 m on the far side)
                    + "  float lx = mod(gx + 20.0, 40.0) - 20.0;\n"
                    + "  float pool = exp(-(lx * lx) / 34.0 - ((p.y + 4.6) * (p.y + 4.6)) / 20.0);\n"
                    + "  col += vec3(1.0, 0.78, 0.48) * pool * uLamp * 0.60 * (1.0 + 0.8 * uWet);\n"
                    + "  col += vec3(0.30, 0.32, 0.45) * uFlash * 0.45;\n"
                    + "  col = mix(col, uFog, smoothstep(10.0 - 7.0 * uMist, 150.0 - 128.0 * uMist, dist));\n"
                    + "  gl_FragColor = vec4(col, 1.0);\n"
                    + "}\n";
    // roadside scenery: trees, rail and lamps live on a 320 m ring that scrolls with the road
    private static final String SCN_VS =
            "uniform mat4 uVP; uniform float uScr; uniform float uTime; uniform float uWind; uniform vec3 uJ; uniform vec2 uJd;\n"
                    + "attribute vec3 aPos; attribute vec3 aNrm; attribute vec4 aCol; attribute float aCx; attribute float aCz;\n"
                    + "varying vec3 vP; varying vec3 vN; varying vec4 vC; varying vec3 vL;\n"
                    + "void main(){\n"
                    + "  float sx = mod(aCx - uScr + 160.0, 320.0) - 160.0;\n"
                    + "  vec3 p = aPos; p.x += sx - aCx;\n"
                    + "  if (aCol.a > 0.25 && aCol.a < 0.75) {\n"
                    + "    float h = max(aPos.y - 0.8, 0.0);\n"
                    + "    float ph = uTime * 1.7 + aCx * 0.37 + aPos.z * 0.21;\n"
                    + "    p.x += (0.012 + 0.07 * uWind) * h * sin(ph) + uWind * 0.05 * h;\n"
                    + "    p.z += (0.008 + 0.05 * uWind) * h * sin(ph * 0.8 + 1.0);\n"
                    // leaves flutter on their own, a little faster and finer than the crown sway
                    + "    float lf = (0.010 + 0.035 * uWind) * clamp(h, 0.0, 1.0);\n"
                    + "    p += lf * vec3(sin(uTime * 5.1 + aPos.x * 3.1 + aPos.y * 4.7), sin(uTime * 4.3 + aPos.z * 3.7 + aPos.x * 1.9), sin(uTime * 5.7 + aPos.y * 2.9 + aPos.z * 2.3));\n"
                    + "  }\n"
                    // a side road leaves the main road here: trees, rail and lamps in its way shrink into the ground
                    + "  if (uJ.z > 0.01 && aCz * uJ.y > 0.0) {\n"
                    + "    vec2 q = vec2(sx, aCz) - vec2(uJ.x, uJ.y * 4.0);\n"
                    + "    float jt = dot(q, uJd); float jl = dot(q, vec2(-uJd.y, uJd.x));\n"
                    + "    float k = 1.0 - uJ.z * (1.0 - smoothstep(6.4, 8.4, abs(jl))) * smoothstep(-6.0, -3.0, jt);\n"
                    + "    vec3 ctr = vec3(sx, 0.0, aCz);\n"
                    + "    p = ctr + (p - ctr) * k;\n"
                    + "  }\n"
                    + "  vP = p; vN = aNrm; vC = aCol; vL = aPos;\n"
                    + "  gl_Position = uVP * vec4(p, 1.0);\n"
                    + "}\n";
    private static final String SCN_FS =
            "#ifdef GL_FRAGMENT_PRECISION_HIGH\nprecision highp float;\n#else\nprecision mediump float;\n#endif\n"
                    + "uniform vec3 uEye; uniform vec3 uFog; uniform vec3 uAmb; uniform vec3 uSunCol; uniform float uScr;\n"
                    + "uniform float uMist; uniform float uSnow; uniform float uWet; uniform float uLamp; uniform float uFlash; uniform float uGlow; uniform float uQ;\n"
                    + "varying vec3 vP; varying vec3 vN; varying vec4 vC; varying vec3 vL;\n"
                    + "void main(){\n"
                    + "  float dist = length(vP - uEye);\n"
                    // things that come close to the camera dissolve instead of blocking the view
                    + "  float al = smoothstep(3.0, 9.0, dist);\n"
                    + "  float dth = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));\n"
                    + "  if (dth > al) discard;\n"
                    + "  vec3 n = normalize(vN);\n"
                    + "  float ndl = max(dot(n, normalize(vec3(0.40, 0.80, 0.45))), 0.0);\n"
                    + "  vec3 col = vC.rgb;\n"
                    + "  float fol = step(0.25, vC.a) * (1.0 - step(0.75, vC.a));\n"
                    + "  col = mix(col, vec3(0.90, 0.93, 0.98), uSnow * smoothstep(0.30, 0.80, n.y) * (0.35 + 0.65 * fol));\n"
                    + "  col *= uAmb + uSunCol * ndl;\n"
                    // light shining through the leaves from behind (warmer, greener) and fine leaf speckle that stays on the tree
                    + "  vec3 sd = normalize(vec3(0.40, 0.80, 0.45));\n"
                    + "  col += vC.rgb * vec3(1.0, 1.0, 0.45) * uSunCol * fol * max(dot(n, -sd), 0.0) * 0.16;\n"
                    + "  if (uQ > 0.5 && fol > 0.5 && dist < 70.0) {\n"
                    + "    vec3 cell = floor(vL * 7.0);\n"
                    + "    float lh = fract(sin(dot(cell, vec3(12.9898, 78.233, 37.719))) * 43758.5453);\n"
                    + "    col *= 1.0 + (lh - 0.5) * 0.34 * (1.0 - smoothstep(22.0, 70.0, dist));\n"
                    + "  }\n"
                    // High: sky light from above and darker foliage / trunks near the ground give the trees some volume
                    + "  if (uQ > 0.5) col *= (0.86 + 0.20 * n.y) * mix(1.0, mix(0.74, 1.0, smoothstep(0.3, 3.2, vP.y)), 0.5 + 0.5 * fol);\n"
                    + "  col *= 1.0 - 0.22 * uWet;\n"
                    + "  col += vC.rgb * uGlow * 0.6;\n"
                    // warm light from the nearest lamp on trees and rail
                    + "  float lx = mod(vP.x + uScr + 20.0, 40.0) - 20.0;\n"
                    + "  float dz = vP.z + 5.2;\n"
                    + "  float lit = uLamp * exp(-(lx * lx) / 55.0 - (dz * dz) / 70.0) * (1.0 - smoothstep(4.0, 9.0, vP.y));\n"
                    + "  col += vC.rgb * vec3(1.0, 0.76, 0.46) * lit * 0.9;\n"
                    + "  if (vC.a > 0.75) col = vec3(1.0, 0.86, 0.60) * (0.40 + 1.3 * uLamp);\n"
                    + "  col += vec3(0.30, 0.32, 0.45) * uFlash * 0.40;\n"
                    + "  col = mix(col, uFog, smoothstep(10.0 - 7.0 * uMist, 150.0 - 128.0 * uMist, dist));\n"
                    + "  gl_FragColor = vec4(col, 1.0);\n"
                    + "}\n";
    // soft car shadow on the road
    private static final String SH_VS =
            "uniform mat4 uVP; attribute vec2 aPos; varying vec2 vL;\n"
                    + "void main(){ vL = aPos; gl_Position = uVP * vec4(aPos.x, 0.012, aPos.y, 1.0); }\n";
    private static final String SH_FS =
            "precision mediump float;\n"
                    + "uniform vec4 uBox; uniform float uA; varying vec2 vL;\n"
                    + "void main(){\n"
                    + "  vec2 q = abs(vL - uBox.zw) - uBox.xy + vec2(0.55);\n"
                    + "  float d = length(max(q, 0.0)) - 0.55;\n"
                    + "  float a = (1.0 - smoothstep(-0.30, 0.95, d)) * uA;\n"
                    + "  gl_FragColor = vec4(0.0, 0.0, 0.0, a);\n"
                    + "}\n";
    private static final String SKY_VS =
            "attribute vec2 aPos; void main(){ gl_Position = vec4(aPos, 0.999, 1.0); }\n";
    private static final String SKY_FS =
            "#ifdef GL_FRAGMENT_PRECISION_HIGH\nprecision highp float;\n#else\nprecision mediump float;\n#endif\n"
                    + "uniform vec2 uRes; uniform vec3 uTop; uniform vec3 uFog;\n"
                    + "uniform float uDay; uniform float uTwi; uniform float uTime; uniform float uHor;\n"
                    + "uniform float uCloud; uniform float uRainy; uniform float uCT; uniform float uFlash; uniform float uQ;\n"
                    + "float hash(vec2 p){ vec3 q = fract(vec3(p.xyx) * 0.1031); q += dot(q, q.yzx + 33.33); return fract((q.x + q.y) * q.z); }\n"
                    + "float vnoise(vec2 p){ vec2 i = floor(p); vec2 f = fract(p); f = f * f * (3.0 - 2.0 * f);\n"
                    + "  return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), f.x), mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), f.x), f.y); }\n"
                    + "void main(){\n"
                    + "  vec2 p = gl_FragCoord.xy; float v = p.y / uRes.y;\n"
                    + "  float s = clamp((v - uHor) / (1.0 - uHor), 0.0, 1.0);\n"      // 0 at the horizon, 1 at the top
                    + "  vec3 col = mix(uFog, uTop, pow(s, 0.65));\n"
                    + "  float night = 1.0 - uDay;\n"
                    + "  float up = smoothstep(0.10, 0.45, s);\n"
                    // stars
                    + "  vec2 g = p / (uRes.y * 0.040); vec2 id = floor(g); vec2 f = fract(g);\n"
                    + "  float h = hash(id);\n"
                    + "  vec2 sp = vec2(hash(id + 3.7), hash(id + 9.1)) * 0.6 + 0.2;\n"
                    + "  float star = step(0.88, h) * (1.0 - smoothstep(0.0, 0.11, length(f - sp)));\n"
                    + "  col += vec3(0.9, 0.95, 1.0) * star * (0.65 + 0.35 * sin(uTime * 2.0 + h * 60.0)) * night * night * up * (1.0 - uCloud);\n"
                    // moon
                    + "  vec2 mc = vec2(0.78 * uRes.x, (uHor + 0.04 + 0.20 * night) * uRes.y);\n"
                    + "  float mr = length(p - mc) / uRes.y;\n"
                    + "  float moonW = (1.0 - smoothstep(0.2, 0.85, uDay)) * (1.0 - 0.92 * uCloud);\n"
                    + "  float disc = 1.0 - smoothstep(0.040, 0.044, mr);\n"
                    + "  float cut = 1.0 - smoothstep(0.036, 0.040, length(p - (mc + vec2(0.020, 0.010) * uRes.y)) / uRes.y);\n"
                    + "  col += vec3(0.86, 0.91, 1.0) * disc * (1.0 - 0.8 * cut) * moonW;\n"
                    + "  col += vec3(0.45, 0.55, 0.85) * exp(-mr * 16.0) * 0.22 * moonW;\n"
                    // sun
                    + "  vec2 sc = vec2(0.78 * uRes.x, (uHor + 0.04 + 0.20 * uDay) * uRes.y);\n"
                    + "  float sr = length(p - sc) / uRes.y;\n"
                    + "  float sunW = smoothstep(0.10, 0.60, uDay) * (1.0 - 0.93 * uCloud);\n"
                    + "  vec3 sunCol = mix(vec3(1.0, 0.52, 0.22), vec3(1.0, 0.96, 0.80), uDay);\n"
                    + "  col += sunCol * ((1.0 - smoothstep(0.046, 0.052, sr)) + exp(-sr * 8.0) * 0.60) * sunW;\n"
                    // clouds
                    + "  vec2 cuv = vec2(p.x / uRes.y * 1.6 + uCT, v * 5.0);\n"
                    + "  float cn = vnoise(cuv * vec2(1.0, 1.6)) * 0.6 + vnoise(cuv * 2.3 + 7.0 + vec2(uCT * 0.7, 0.0)) * 0.4;\n"
                    + "  if (uQ > 0.5) cn = cn * 0.86 + vnoise(cuv * 5.2 + 21.0 + vec2(uCT * 1.3, 0.0)) * 0.14;\n"
                    + "  float thr = mix(0.55, 0.20, uCloud);\n"
                    + "  float cl = smoothstep(thr, thr + mix(0.25, 0.32, uCloud), cn);\n"
                    + "  cl *= smoothstep(mix(0.10, 0.0, uCloud), mix(0.30, 0.14, uCloud), s) * (1.0 - 0.6 * (1.0 - uCloud) * smoothstep(0.75, 1.0, s));\n"
                    + "  vec3 ccDay = mix(mix(vec3(0.96, 0.97, 1.0), vec3(1.0, 0.72, 0.55), uTwi), vec3(0.40, 0.43, 0.49), uRainy * 0.85);\n"
                    + "  vec3 ccNight = vec3(0.075, 0.09, 0.14) + vec3(0.06, 0.07, 0.10) * cn;\n"
                    + "  vec3 cc = mix(ccNight, ccDay, uDay) * (0.84 + 0.30 * cn);\n"
                    + "  float ca = uDay * mix(0.62, 0.95, uCloud) + night * 0.90 * smoothstep(0.15, 0.50, uCloud);\n"
                    + "  col = mix(col, cc, cl * ca);\n"
                    + "  col += vec3(0.62, 0.68, 1.0) * uFlash * (0.20 + 0.70 * cl);\n"
                    // distant hills melt the sky into the road haze
                    + "  float nx = p.x / uRes.y;\n"
                    + "  float h1 = 0.034 + 0.018 * sin(nx * 3.1 + 1.3) + 0.010 * sin(nx * 7.3 + 4.0) + 0.005 * sin(nx * 13.0);\n"
                    + "  float far = 1.0 - smoothstep(0.0, 0.004, v - (uHor + h1));\n"
                    + "  col = mix(col, mix(uFog, uTop * 0.55, 0.42), far);\n"
                    + "  float h2 = 0.012 + 0.011 * sin(nx * 4.7 + 0.4) + 0.006 * sin(nx * 10.0 + 2.0);\n"
                    + "  float nr = 1.0 - smoothstep(0.0, 0.004, v - (uHor + h2));\n"
                    + "  col = mix(col, mix(uFog, uTop * 0.40, 0.55), nr);\n"
                    // town lights on the hills at night
                    + "  float win = step(0.93, hash(floor(p / (uRes.y * 0.012)))) * far * night * smoothstep(0.003, 0.012, v - uHor);\n"
                    + "  col += vec3(1.0, 0.85, 0.5) * win * 0.55;\n"
                    // High: a touch of dither takes the banding out of the sky gradient
                    + "  if (uQ > 0.5) col += (hash(p) - 0.5) * (1.5 / 255.0);\n"
                    + "  gl_FragColor = vec4(col, 1.0); }\n";
    private static final String PRE_VS =
            "attribute vec2 aPos; void main(){ gl_Position = vec4(aPos, 0.0, 1.0); }\n";
    private static final String PRE_FS =
            "#ifdef GL_FRAGMENT_PRECISION_HIGH\nprecision highp float;\n#else\nprecision mediump float;\n#endif\n"
                    + "uniform vec2 uRes; uniform float uT; uniform float uRain; uniform float uSnow; uniform float uWind;\n"
                    + "uniform float uWT; uniform float uDay; uniform float uMist; uniform vec3 uFog;\n"
                    + "float hash(vec2 p){ vec3 q = fract(vec3(p.xyx) * 0.1031); q += dot(q, q.yzx + 33.33); return fract((q.x + q.y) * q.z); }\n"
                    // slanted rain streak layer
                    + "float rainL(vec2 p, float sc, float spd, float len, float slant, float dens){\n"
                    + "  vec2 uv = p / uRes.y; uv.x += uv.y * slant;\n"
                    + "  vec2 g = vec2(uv.x * sc, uv.y * sc * 0.16); g.y += uT * spd;\n"
                    + "  vec2 id = floor(g); vec2 f = fract(g);\n"
                    + "  float on = step(hash(id), dens);\n"
                    + "  float hx = 0.15 + 0.7 * hash(id + 4.3);\n"
                    + "  float y0 = hash(id + 8.9) * (1.0 - len);\n"
                    + "  float ln = 1.0 - smoothstep(0.0, 0.10, abs(f.x - hx));\n"
                    + "  float inside = step(y0, f.y) * step(f.y, y0 + len);\n"
                    + "  float fade = 1.0 - (f.y - y0) / len;\n"
                    + "  return on * ln * inside * clamp(fade, 0.0, 1.0); }\n"
                    // soft snow flakes
                    + "float snowL(vec2 p, float sc, float spd, float sz, float slant, float dens){\n"
                    + "  vec2 uv = p / uRes.y; uv.x += uv.y * slant;\n"
                    + "  vec2 g = uv * sc; g.y += uT * spd;\n"
                    + "  vec2 id = floor(g); vec2 f = fract(g);\n"
                    + "  float h = hash(id); float on = step(h, dens);\n"
                    + "  vec2 c = 0.5 + 0.30 * vec2(sin(uT * 1.1 + h * 40.0), sin(uT * 0.8 + h * 17.0));\n"
                    + "  return on * (1.0 - smoothstep(sz * 0.5, sz, length(f - c))); }\n"
                    // long horizontal wind streaks
                    + "float windL(vec2 p, float rows, float spd, float len, float dens, float seed){\n"
                    + "  vec2 uv = p / uRes.y;\n"
                    + "  vec2 g = vec2(uv.x * 0.9 - uWT * spd, uv.y * rows);\n"
                    + "  vec2 id = floor(g); vec2 f = fract(g);\n"
                    + "  float on = step(hash(id + seed), dens);\n"
                    + "  float x0 = hash(id + 3.1) * (1.0 - len);\n"
                    + "  float yc = 0.2 + 0.6 * hash(id + 7.7);\n"
                    + "  float ln = 1.0 - smoothstep(0.0, 0.05, abs(f.y - yc));\n"
                    + "  float t = (f.x - x0) / len;\n"
                    + "  float inside = step(0.0, t) * step(t, 1.0);\n"
                    + "  return on * ln * inside * sin(3.14159 * clamp(t, 0.0, 1.0)); }\n"
                    + "void main(){\n"
                    + "  vec2 p = gl_FragCoord.xy;\n"
                    + "  float slant = 0.08 + 0.55 * uWind;\n"
                    + "  float ra = 0.0;\n"
                    + "  if (uRain > 0.01) {\n"
                    + "    float dn = 0.22 + 0.78 * uRain;\n"
                    + "    ra = rainL(p, 120.0, 5.0, 0.35, slant, dn * 0.9) * 0.22\n"
                    + "       + rainL(p, 72.0, 7.0, 0.45, slant, dn * 0.8) * 0.34\n"
                    + "       + rainL(p, 40.0, 10.0, 0.55, slant, dn * 0.6) * 0.50;\n"
                    + "  }\n"
                    + "  float sa = 0.0;\n"
                    + "  if (uSnow > 0.01) {\n"
                    + "    float dn = 0.25 + 0.60 * uSnow;\n"
                    + "    float sl = 0.05 + 0.50 * uWind;\n"
                    + "    sa = snowL(p, 42.0, 0.35, 0.16, sl, dn * 0.6) * 0.55\n"
                    + "       + snowL(p, 26.0, 0.55, 0.20, sl, dn * 0.6) * 0.75\n"
                    + "       + snowL(p, 15.0, 0.80, 0.26, sl, dn * 0.5) * 0.95;\n"
                    + "  }\n"
                    + "  float wa = 0.0;\n"
                    + "  if (uWind > 0.05) {\n"
                    + "    wa = (windL(p, 14.0, 0.9, 0.55, 0.45, 1.0) * 0.30 + windL(p, 24.0, 1.4, 0.40, 0.40, 5.0) * 0.22) * uWind * uWind;\n"
                    + "  }\n"
                    + "  float aP = clamp(ra + sa + wa, 0.0, 1.0);\n"
                    + "  vec3 pc = vec3(0.84, 0.89, 0.97) * (0.55 + 0.45 * uDay);\n"
                    + "  float aV = uMist * 0.22;\n"
                    + "  float aT = aP + aV * (1.0 - aP);\n"
                    + "  vec3 rgb = (pc * aP + uFog * aV * (1.0 - aP)) / max(aT, 0.0001);\n"
                    + "  gl_FragColor = vec4(rgb, aT); }\n";
    private static final String GLOW_VS =
            "uniform mat4 uVP; attribute vec3 aPos; attribute vec2 aUv; varying vec2 vUv;\n"
                    + "void main(){ vUv = aUv; gl_Position = uVP * vec4(aPos, 1.0); }\n";
    private static final String GLOW_FS =
            "precision mediump float;\n"
                    + "varying vec2 vUv; uniform vec3 uCol; uniform float uA;\n"
                    + "void main(){ float d = length(vUv);\n"
                    + "  float g = (exp(-d * d * 5.0) + 0.7 * exp(-d * d * 38.0)) * (1.0 - smoothstep(0.80, 1.0, d));\n"
                    + "  gl_FragColor = vec4(uCol * g * uA, 1.0); }\n";

    private final float[] accent = new float[3];
    private final Context ctx;
    private Glb model;

    // day / night + lights (render thread)
    private float day = 1f;            // eased 0 (night) .. 1 (day)
    private float lights = 0f;         // eased 0 (off) .. 1 (on)
    private boolean dayInit = false;
    private float dayTarget = 1f, lightsTarget = 0f;
    private float dayCheck = 0f;
    private volatile boolean skyDirty = false;
    private final float[] skyTop = new float[3], skyHor = new float[3], asphalt = new float[3];

    // weather (written from the UI thread, eased on the render thread)
    private volatile int wxCode = 0;
    private volatile float wxWind = 0f; // km/h
    private boolean wxInit = false;
    private float cloud = 0f, rain = 0f, snow = 0f, mist = 0f, storm = 0f, windS = 0f;
    private float cloudT = 0f, windT = 0f, flash = 0f, flashTimer = 3f;
    private boolean flashAgain = false;
    private int lightMode = 0;
    private static final float[] N_TOP = {0.02f, 0.03f, 0.07f}, N_HOR = {0.08f, 0.10f, 0.16f}, N_ASP = {0.11f, 0.12f, 0.145f};
    private static final float[] D_TOP = {0.18f, 0.46f, 0.88f}, D_HOR = {0.70f, 0.84f, 0.96f}, D_ASP = {0.31f, 0.32f, 0.35f};
    private static final float[] T_TOP = {0.30f, 0.22f, 0.46f}, T_HOR = {0.98f, 0.52f, 0.30f};

    private static void mix3(float[] out, float[] a, float[] b, float t) {
        for (int i = 0; i < 3; i++) out[i] = a[i] + (b[i] - a[i]) * t;
    }

    // lamps (world space of the car, before bob / pitch): {x, y, z, type}; ground-light anchors
    private float[][] lamps = new float[0][];
    private float headX = 2f, headZ = 0.7f, tailX = -2.3f, tailZ = 0.6f;

    // GL state (render thread)
    private int carProg, gndProg, skyProg, glowProg, preProg, scnProg, shProg;
    // roadside scenery + car shadow
    private FloatBuffer shBuf;
    private int scnFar, scnNear; // vertex buffer objects (0 = none)
    private int scnFarN, scnNearN;
    private int scnLevel = 0;                 // 0 full, 1 light, 2 off (plain road)
    private boolean scnDirty = true;
    private float sceneScr = 0f;
    private final float[] grass = new float[3], amb = new float[3], sunCol = new float[3];
    private float shHL = 2.4f, shHW = 1.0f, shOX = 0f, shOZ = 0f;
    private FloatBuffer[] carBuf = new FloatBuffer[5];
    private int[] carCount = new int[5];
    private FloatBuffer gndBuf, skyBuf, glowBuf;
    private final int[] carVbo = new int[5];
    private int gndVbo, skyVbo, shVbo;
    private static final float[][] CORNERS = {{-1, -1}, {1, -1}, {-1, 1}, {1, -1}, {1, 1}, {-1, 1}};
    private final float[] glowV = new float[6 * 5];
    private final float[] tmpIn = new float[4], tmpOut = new float[4];
    private final float[] proj = new float[16], view = new float[16], vp = new float[16];
    private final float[] swap = new float[16], bodyM = new float[16], wheelM = new float[16];
    private float aspect = 1.6f;
    private int vw = 1, vh = 1;
    private long lastNs = 0;

    // ---- frame pacing. A 90 Hz screen with a GPU that can only just do 60 fps flips between 90 / 45 / 90 fps and looks like stutter.
    // So the view asks the system for ONE steady rate it can really hold (Surface.setFrameRate, Android 11+; on a divisor of the
    // panel rate it also waits between frames itself). Auto starts at the best rate, steps down only when frames come late and
    // remembers where it settled. Quality is not touched; Settings > "Car frame rate" can pin a rate.
    private float dispHz = 60f;
    private float[] rates = {60f};
    private int rateIdx = 0, rateApplied = -1;
    private int fpsSetting = 0;                       // 0 auto, else the wanted fps (120 = display maximum)
    private float rateLate = 0f, rateSince = 0f;
    private long throttleNs = 0L, nextFrameNs = 0L;

    private void initPacing(Context c) {
        try {
            android.view.Display d = ((android.view.WindowManager) c.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();
            dispHz = d.getRefreshRate();
        } catch (Throwable t) {
            dispHz = 60f;
        }
        int hz = Math.max(30, Math.round(dispHz));
        java.util.TreeSet<Integer> set = new java.util.TreeSet<Integer>(java.util.Collections.reverseOrder());
        set.add(hz);
        if (hz > 62) set.add(60);
        for (int k = 2; k <= 4; k++) if (hz / k >= 30) set.add(hz / k);
        set.add(30);
        rates = new float[set.size()];
        int i = 0;
        for (int r : set) rates[i++] = r;
        fpsSetting = Prefs.i(ctx, "carFpsSet", 0);
        pickRate();
    }

    /** Chooses the starting step: the pinned rate, else what Auto settled on last time, else the best. */
    private void pickRate() {
        int want = fpsSetting > 0 ? fpsSetting : Prefs.i(ctx, "carFps", 0);
        int idx = 0;
        if (want > 0) {
            idx = rates.length - 1;
            for (int i = 0; i < rates.length; i++) {
                if (rates[i] <= want + 0.5f) {
                    idx = i;
                    break;
                }
            }
        }
        rateIdx = idx;
        rateApplied = -1;
        rateLate = 0f;
        rateSince = 0f;
    }

    private void applyRate() {
        rateApplied = rateIdx;
        float r = rates[rateIdx];
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            try {
                android.view.Surface sf = getHolder().getSurface();
                if (sf != null && sf.isValid()) {
                    if (android.os.Build.VERSION.SDK_INT >= 31) {
                        sf.setFrameRate(r, android.view.Surface.FRAME_RATE_COMPATIBILITY_FIXED_SOURCE,
                                android.view.Surface.CHANGE_FRAME_RATE_ONLY_IF_SEAMLESS);
                    } else {
                        sf.setFrameRate(r, android.view.Surface.FRAME_RATE_COMPATIBILITY_FIXED_SOURCE);
                    }
                }
            } catch (Throwable t) {
                // not supported here: the throttle below / the governor still keep it steady
            }
        }
        int hz = Math.round(dispHz);
        float ratio = hz / r;
        throttleNs = (r < hz - 1 && Math.abs(ratio - Math.round(ratio)) < 0.02f) ? (long) (1e9 / r) : 0L;
        nextFrameNs = 0L;
    }

    private boolean rateAtFloor() {
        return fpsSetting > 0 || rateIdx >= rates.length - 1;
    }

    private void paceGovern(float raw) {
        if (fpsSetting > 0 || !activeNow || raw <= 0f || raw > 0.25f) return;
        float period = 1f / rates[rateIdx];
        rateSince += raw;
        rateLate = rateLate * (float) Math.exp(-raw / 3f) + (raw > period * 1.4f ? 1f : 0f);
        if (rateSince > 4f && rateLate > 0.15f * rates[rateIdx] * 3f && rateIdx < rates.length - 1) {
            rateIdx++;
            rateLate = 0f;
            rateSince = 0f;
            govScore = 0f; // the quality governor starts counting again at the new rate
            try {
                Prefs.putI(ctx, "carFps", Math.round(rates[rateIdx]));
            } catch (Throwable t) {
                // not worth failing a frame over
            }
        }
    }

    @Override
    public void surfaceChanged(android.view.SurfaceHolder holder, int format, int w, int h) {
        super.surfaceChanged(holder, format, w, h);
        rateApplied = -1; // a new surface forgets the frame-rate hint
    }

    // ---- graphics quality. Tier 1 ("High") adds 24-bit depth, paint reflections, ambient occlusion, richer asphalt and clouds;
    // tier 0 is the v2.20 look. Auto starts at High and drops to the lower tier by itself when frames start to stutter.
    private volatile int gfxMode = 0;                 // setting: 0 auto, 1 high, 2 standard
    private int gfxModeSeen = -1;
    private boolean autoStart = true;                 // false after the governor had to step down in two sessions
    private static volatile int govCap = 1;           // shared by both car slides: 0 = the governor stepped down
    private static boolean govCounted = false;
    private volatile boolean activeNow = false;
    private float govBase = 0.0167f, govEma = 0.0167f, govScore = 0f, govActive = 0f;
    private float qNow = 1f;

    private int startTier() {
        if (gfxMode == 2) return 0;
        if (gfxMode == 1) return 1;
        return autoStart ? 1 : 0;
    }

    private int tierNow() {
        if (gfxMode == 2) return 0;
        if (gfxMode == 1) return 1;
        return autoStart && govCap > 0 ? 1 : 0;
    }

    /**
     * Watches the real frame interval while the slide is on screen. A run of late frames (more than 1.6 x the screen's normal
     * interval, weighted over about 3 seconds) in Auto mode drops everything to the standard tier; two such sessions make
     * Auto start at standard from then on (choosing a quality in Settings resets that).
     */
    private void govern(float raw) {
        if (!activeNow || raw <= 0f || raw > 0.25f) return;
        govActive += raw;
        govEma += (raw - govEma) * 0.05f;
        if (govActive < 2f) govBase = govEma;
        else govBase = Math.max(0.0055f, Math.min(govBase, govEma));
        boolean late = raw > govBase * 1.6f && raw > 0.022f;
        govScore = govScore * (float) Math.exp(-raw / 3f) + (late ? 1f : 0f);
        if (govActive > 6f && govScore > 7f && gfxMode == 0 && govCap > 0 && rateAtFloor()) {
            govCap = 0;
            android.util.Log.w("Car3DView", "frames are late: dropping to the standard graphics tier");
            if (!govCounted) {
                govCounted = true;
                try {
                    Prefs.putI(ctx, "carGfxDrops", Prefs.i(ctx, "carGfxDrops", 0) + 1);
                } catch (Throwable t) {
                    // not worth failing a frame over
                }
            }
        }
    }
    private float speed = 0f, prevSpeed = 0f, scroll = 0f, wheelAng = 0f, time = 0f;

    // rear-view camera (third slide), body paint and brake lights
    private final boolean rear;
    private volatile int paintIdx = 3;
    private float brake = 0f;
    /** Body paint: black, grey, white, red. */
    private static final float[][] PAINT = {
            {0.035f, 0.037f, 0.042f}, {0.40f, 0.42f, 0.45f}, {0.78f, 0.79f, 0.82f}, {0.553f, 0.004f, 0.125f}};

    // written from the UI thread
    private volatile float targetSpeed = 0f;
    private volatile long speedAt = 0L;

    Car3DView(Context c, int accentColor) {
        this(c, accentColor, false);
    }

    Car3DView(Context c, int accentColor, boolean rearView) {
        super(c);
        rear = rearView;
        ctx = c.getApplicationContext();
        accent[0] = ((accentColor >> 16) & 0xFF) / 255f;
        accent[1] = ((accentColor >> 8) & 0xFF) / 255f;
        accent[2] = (accentColor & 0xFF) / 255f;
        try {
            InputStream in = c.getAssets().open("car.glb");
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] b = new byte[16384];
            int n;
            while ((n = in.read(b)) > 0) bo.write(b, 0, n);
            in.close();
            model = Glb.parse(bo.toByteArray());
        } catch (Throwable t) {
            model = null;
        }
        // model space (X fwd, Y left, Z up) -> world (X fwd, Y up, Z right-handed)
        Matrix.setIdentityM(swap, 0);
        swap[0] = 1; swap[1] = 0; swap[2] = 0;
        swap[4] = 0; swap[5] = 0; swap[6] = -1;
        swap[8] = 0; swap[9] = 1; swap[10] = 0;
        if (model != null) {
            lamps = model.lamps;
            float hx = -1e9f, hz = 0f, tx = 1e9f, tz = 0f;
            int hn = 0, tn = 0;
            for (float[] l : lamps) {
                if (l[3] == 1f) {
                    hx = Math.max(hx, l[0]);
                    hz += Math.abs(l[1]);
                    hn++;
                } else {
                    tx = Math.min(tx, l[0]);
                    tz += Math.abs(l[1]);
                    tn++;
                }
            }
            if (hn > 0) {
                headX = hx;
                headZ = hz / hn;
            }
            if (tn > 0) {
                tailX = tx;
                tailZ = tz / tn;
            }
        }
        setEGLContextClientVersion(2);
        gfxMode = Prefs.i(ctx, "carGfx", 0);
        autoStart = Prefs.i(ctx, "carGfxDrops", 0) < 2;
        setEGLConfigChooser(new AAChooser(Prefs.b(ctx, "carAA", true), startTier() >= 1));
        // keep the GL context (shaders, meshes) alive when the launcher is paused: coming back to the home screen used to rebuild all of it
        setPreserveEGLContextOnPause(true);
        prewarm(Math.max(0, Math.min(2, Prefs.i(ctx, "carScenery", 0))));
        initPacing(c);
        setRenderer(this);
        setRenderMode(RENDERMODE_WHEN_DIRTY);
    }

    /**
     * Asks for a 4x (then 2x) multisampled surface (when anti-aliasing is on) and a 24-bit depth buffer (when graphics
     * quality is High; tried first, then 16-bit), so the car, trees and rail have smooth edges and far things do not
     * flicker; every step falls back to something simpler.
     */
    private static final class AAChooser implements GLSurfaceView.EGLConfigChooser {
        private final boolean aa, deep;

        AAChooser(boolean aa, boolean deep) {
            this.aa = aa;
            this.deep = deep;
        }

        private static int[] attrs(int samples, int depth) {
            if (samples > 0) {
                return new int[]{EGL10.EGL_RED_SIZE, 8, EGL10.EGL_GREEN_SIZE, 8, EGL10.EGL_BLUE_SIZE, 8, EGL10.EGL_ALPHA_SIZE, 0,
                        EGL10.EGL_DEPTH_SIZE, depth, EGL10.EGL_RENDERABLE_TYPE, 4,
                        EGL10.EGL_SAMPLE_BUFFERS, 1, EGL10.EGL_SAMPLES, samples, EGL10.EGL_NONE};
            }
            return new int[]{EGL10.EGL_RED_SIZE, 8, EGL10.EGL_GREEN_SIZE, 8, EGL10.EGL_BLUE_SIZE, 8, EGL10.EGL_ALPHA_SIZE, 0,
                    EGL10.EGL_DEPTH_SIZE, depth, EGL10.EGL_RENDERABLE_TYPE, 4, EGL10.EGL_NONE};
        }

        @Override
        public EGLConfig chooseConfig(EGL10 egl, EGLDisplay display) {
            int[] tries = aa ? new int[]{4, 2, 0} : new int[]{0};
            int[] depths = deep ? new int[]{24, 16} : new int[]{16};
            for (int t : tries) {
                for (int d : depths) {
                    int[] num = new int[1];
                    int[] a = attrs(t, d);
                    if (!egl.eglChooseConfig(display, a, null, 0, num) || num[0] <= 0) continue;
                    EGLConfig[] cfg = new EGLConfig[num[0]];
                    if (!egl.eglChooseConfig(display, a, cfg, num[0], num)) continue;
                    int[] v = new int[1];
                    for (int i = 0; i < num[0]; i++) { // first config that really has the depth bits we asked for
                        EGLConfig c = cfg[i];
                        if (c == null) continue;
                        egl.eglGetConfigAttrib(display, c, EGL10.EGL_DEPTH_SIZE, v);
                        if (v[0] >= d) return c;
                    }
                }
            }
            int[] num = new int[1];
            int[] any = {EGL10.EGL_RENDERABLE_TYPE, 4, EGL10.EGL_NONE};
            egl.eglChooseConfig(display, any, null, 0, num);
            EGLConfig[] cfg = new EGLConfig[Math.max(1, num[0])];
            egl.eglChooseConfig(display, any, cfg, cfg.length, num);
            return cfg[0];
        }
    }

    boolean hasModel() {
        return model != null;
    }

    /** Body colour: 0 black, 1 grey, 2 white, 3 red. */
    void setPaint(int idx) {
        paintIdx = Math.max(0, Math.min(PAINT.length - 1, idx));
        requestRender();
    }

    /** Feed the latest GPS speed (m/s). Anything below ~3 km/h counts as standing still. */
    void setSpeed(float ms) {
        targetSpeed = ms < 0.8f ? 0f : ms;
        speedAt = SystemClock.elapsedRealtime();
    }

    /** Navigation on / off: fades the route ribbon (with chevrons) in or out on the road ahead of the car. */
    void setNav(boolean on) {
        navTarget = on ? 1f : 0f;
        if (getRenderMode() == RENDERMODE_WHEN_DIRTY) nav = navTarget; // not on screen: no easing, the next still frame is right
        requestRender();
    }

    private volatile float navTarget = 0f;
    private float nav = 0f;

    // guidance road sign: slides along the road side towards the car as the next turn gets close
    private static final float SIGN_START = 100f;   // scene metres ahead where the sign first appears (out of the haze)
    private volatile int sigKindT = -1;
    private volatile float sigDistT = 1e9f;
    private volatile boolean sigOnT = false;
    private boolean signActive = false, signDone = false, signFree = false;
    private float signX = 0f, signLastD = 1e9f;
    private int signKind = -1;
    private final int[] signBuf = new int[Scenery.SIGN_KINDS]; // vertex buffer objects (0 = not built yet)
    private final int[] signN = new int[Scenery.SIGN_KINDS];

    // side road at the turn (junction x in scene metres, side +1 right / -1 left, fade, direction)
    private volatile boolean branchOnT = true;
    private float jx = 0f, jA = 0f, jSide = 0f, jDx = 0f, jDz = 1f;

    /** Draw a side road where the sign says to turn (Settings > Day & night > "Side road at the turn"). */
    void setBranch(boolean on) {
        branchOnT = on;
    }

    private static boolean branchKind(int k) {
        return k == 0 || k == 1 || k == 3 || k == 4;
    }

    private void updateBranch(float dt) {
        boolean ok = signActive && branchOnT && branchKind(signKind);
        if (ok) {
            jSide = Scenery.signSide(signKind);
            jx = signX;
            if (signKind == 3 || signKind == 4) {
                jDx = 0.62f;
                jDz = 0.78f * jSide;
            } else {
                jDx = 0f;
                jDz = jSide;
            }
        }
        float t = ok ? 1f : 0f;
        if (ok && signX < -40f) t *= Math.max(0f, (signX + 70f) / 30f);
        jA += (t - jA) * (1f - (float) Math.exp(-dt / 0.5f));
        if (Math.abs(t - jA) < 0.004f) jA = t;
    }

    /** Road sign for the next turn: kind (see Scenery.sign, -1 = none), real distance to the turn in metres, on / off. */
    void setSign(int kind, double meters, boolean on) {
        sigKindT = kind;
        sigDistT = (float) meters;
        sigOnT = on;
    }

    /** Weather for the sky: WMO weather code (Open-Meteo) and wind speed in km/h. Pass 0 / 0 for a clear, calm sky. */
    void setWeather(int code, float windKmh) {
        wxCode = code;
        wxWind = windKmh;
    }

    /** The day / night or lights setting changed: pick it up on the next frame instead of within a second. */
    void skyChanged() {
        skyDirty = true;
    }

    /** Render continuously only while the page is on screen. */
    void setActive(boolean on) {
        setRenderMode(on ? RENDERMODE_CONTINUOUSLY : RENDERMODE_WHEN_DIRTY);
        activeNow = on;
        if (on) {
            govActive = 0f;
            govScore = 0f;
            rateLate = 0f;
            rateSince = 0f;
            nextFrameNs = 0L;
            lastNs = 0;
            requestRender();
        }
    }

    // ------------------------------------------------------------------ GL
    private static int shader(int type, String src) {
        int s = GLES20.glCreateShader(type);
        GLES20.glShaderSource(s, src);
        GLES20.glCompileShader(s);
        int[] ok = new int[1];
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0);
        if (ok[0] == 0) {
            android.util.Log.e("Car3DView", "shader compile failed: " + GLES20.glGetShaderInfoLog(s));
            GLES20.glDeleteShader(s);
            return 0;
        }
        return s;
    }

    /** Returns 0 when the program could not be built (that layer is then simply skipped). */
    private static int program(String vs, String fs) {
        int v = shader(GLES20.GL_VERTEX_SHADER, vs), f = shader(GLES20.GL_FRAGMENT_SHADER, fs);
        if (v == 0 || f == 0) return 0;
        int p = GLES20.glCreateProgram();
        GLES20.glAttachShader(p, v);
        GLES20.glAttachShader(p, f);
        GLES20.glLinkProgram(p);
        int[] ok = new int[1];
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0);
        if (ok[0] == 0) {
            android.util.Log.e("Car3DView", "program link failed: " + GLES20.glGetProgramInfoLog(p));
            return 0;
        }
        return p;
    }

    /** Uploads a mesh to the GPU once (it used to be copied from client memory by the driver on every draw call). */
    private static int vbo(FloatBuffer b, int floats) {
        int[] id = new int[1];
        GLES20.glGenBuffers(1, id, 0);
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, id[0]);
        b.position(0);
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, floats * 4, b, GLES20.GL_STATIC_DRAW);
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0);
        return id[0];
    }

    private static void freeVbo(int id) {
        if (id != 0) GLES20.glDeleteBuffers(1, new int[]{id}, 0);
    }

    // Roadside scenery and sign meshes are built once, on a background thread started with the first view (not on the GL thread)
    private static final Scenery[] SCN_CACHE = new Scenery[2];
    private static final float[][] SIGN_CACHE = new float[Scenery.SIGN_KINDS][];

    private static synchronized Scenery sceneryFor(int level) {
        if (SCN_CACHE[level] == null) SCN_CACHE[level] = Scenery.build(level);
        return SCN_CACHE[level];
    }

    private static synchronized float[] signMesh(int kind) {
        if (SIGN_CACHE[kind] == null) SIGN_CACHE[kind] = Scenery.sign(kind);
        return SIGN_CACHE[kind];
    }

    private static boolean prewarmed = false;

    private static synchronized void prewarm(final int level) {
        if (prewarmed) return;
        prewarmed = true;
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (level >= 0 && level < 2) sceneryFor(level);
                    for (int k = 0; k < Scenery.SIGN_KINDS; k++) signMesh(k);
                } catch (Throwable e) {
                    // built on demand instead
                }
            }
        }, "mika-scenery");
        t.setPriority(Thread.MIN_PRIORITY);
        t.start();
    }

    private static FloatBuffer buf(float[] a) {
        FloatBuffer f = ByteBuffer.allocateDirect(a.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        f.put(a).position(0);
        return f;
    }

    // GL location lookups are string searches in the driver: cache them (they were ~60 per frame)
    private final android.util.SparseArray<java.util.HashMap<String, Integer>> locCache = new android.util.SparseArray<java.util.HashMap<String, Integer>>();

    private int uloc(int prog, String name) {
        return loc(prog, name, false);
    }

    private int aloc(int prog, String name) {
        return loc(prog, name, true);
    }

    private int loc(int prog, String name, boolean attr) {
        int key = attr ? -prog - 1 : prog;
        java.util.HashMap<String, Integer> m = locCache.get(key);
        if (m == null) {
            m = new java.util.HashMap<String, Integer>();
            locCache.put(key, m);
        }
        Integer v = m.get(name);
        if (v == null) {
            v = Integer.valueOf(attr ? GLES20.glGetAttribLocation(prog, name) : GLES20.glGetUniformLocation(prog, name));
            m.put(name, v);
        }
        return v.intValue();
    }

    private float dtS = 0.016f; // smoothed frame step for motion, hides frame-time jitter

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        locCache.clear(); // new GL context: program ids / locations are new
        java.util.Arrays.fill(signBuf, 0); // buffers of the old context are gone
        scnFar = scnNear = 0;
        rateApplied = -1;
        carProg = program(CAR_VS, CAR_FS);
        gndProg = program(GND_VS, GND_FS);
        skyProg = program(SKY_VS, SKY_FS);
        glowProg = program(GLOW_VS, GLOW_FS);
        preProg = program(PRE_VS, PRE_FS);
        scnProg = program(SCN_VS, SCN_FS);
        shProg = program(SH_VS, SH_FS);
        scnDirty = true;
        if (model != null) {
            carBuf[0] = buf(model.body.v);
            carCount[0] = model.body.count;
            for (int i = 0; i < 4; i++) {
                carBuf[i + 1] = buf(model.wheels[i].v);
                carCount[i + 1] = model.wheels[i].count;
            }
            for (int i = 0; i < 5; i++) carVbo[i] = carBuf[i] == null ? 0 : vbo(carBuf[i], carBuf[i].capacity());
        }
        if (model != null) { // car footprint for the shadow (model space: X forward, Y left)
            float x0 = 1e9f, x1 = -1e9f, y0 = 1e9f, y1 = -1e9f;
            for (int gI = 0; gI < 5; gI++) {
                float[] v = gI == 0 ? model.body.v : model.wheels[gI - 1].v;
                for (int i = 0; i + 1 < v.length; i += Glb.STRIDE) {
                    x0 = Math.min(x0, v[i]); x1 = Math.max(x1, v[i]);
                    y0 = Math.min(y0, v[i + 1]); y1 = Math.max(y1, v[i + 1]);
                }
            }
            if (x1 > x0 && y1 > y0) {
                shHL = (x1 - x0) / 2f; shHW = (y1 - y0) / 2f;
                shOX = (x0 + x1) / 2f; shOZ = -(y0 + y1) / 2f;
            }
        }
        {
            float qx = shHL + 2.5f, qz = shHW + 2.5f; // quad around the car that the shadow is painted on
            shBuf = buf(new float[]{shOX - qx, shOZ - qz, shOX + qx, shOZ - qz, shOX - qx, shOZ + qz,
                    shOX + qx, shOZ - qz, shOX + qx, shOZ + qz, shOX - qx, shOZ + qz});
        }
        float g = 300f;
        gndBuf = buf(new float[]{-g, 0, -g, g, 0, -g, -g, 0, g, g, 0, -g, g, 0, g, -g, 0, g});
        skyBuf = buf(new float[]{-1, -1, 1, -1, -1, 1, 1, -1, 1, 1, -1, 1});
        gndVbo = vbo(gndBuf, 18);
        skyVbo = vbo(skyBuf, 12);
        shVbo = vbo(shBuf, 12);
        glowBuf = ByteBuffer.allocateDirect(glowV.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);
        GLES20.glDisable(GLES20.GL_CULL_FACE);
        lastNs = 0;
        dayInit = false;
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int w, int h) {
        vw = Math.max(1, w);
        vh = Math.max(1, h);
        GLES20.glViewport(0, 0, vw, vh);
        aspect = (float) vw / vh;
        Matrix.perspectiveM(proj, 0, FOV, aspect, 1.0f, 400f);
        proj[9] = -CAR_LIFT; // lifts the whole scene (car, road, horizon) a little so the bottom dock has room
    }

    private static final float FOV = 36f;
    private static final float[] G_NIGHT = {0.035f, 0.075f, 0.075f}, G_DAY = {0.26f, 0.50f, 0.17f};
    private static final float[] A_NIGHT = {0.17f, 0.21f, 0.35f}, A_DAY = {0.50f, 0.55f, 0.62f};

    /** Soft shadow under the car: a blurred rounded box pushed away from the sun, fainter in cloud and at night. */
    private void drawShadow() {
        if (shProg == 0 || shBuf == null || model == null) return;
        GLES20.glUseProgram(shProg);
        GLES20.glUniformMatrix4fv(uloc(shProg, "uVP"), 1, false, vp, 0);
        float a = (0.34f + 0.30f * day) * (1f - 0.55f * Math.min(1f, cloud));
        float sun = day * (1f - Math.min(1f, cloud));
        GLES20.glUniform4f(uloc(shProg, "uBox"), shHL - 0.05f, shHW - 0.02f,
                shOX + 0.10f * sun, shOZ - 0.40f * sun);
        GLES20.glUniform1f(uloc(shProg, "uA"), a);
        int pa = aloc(shProg, "aPos");
        GLES20.glDisable(GLES20.GL_DEPTH_TEST);
        GLES20.glEnable(GLES20.GL_BLEND);
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA);
        GLES20.glEnableVertexAttribArray(pa);
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, shVbo);
        GLES20.glVertexAttribPointer(pa, 2, GLES20.GL_FLOAT, false, 8, 0);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 6);
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0);
        GLES20.glDisableVertexAttribArray(pa);
        GLES20.glDisable(GLES20.GL_BLEND);
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);
    }

    private void drawScenery(float ex, float ey, float ez, float lampOn, float rainy) {
        if (scnProg == 0 || scnFar == 0) return;
        GLES20.glUseProgram(scnProg);
        GLES20.glUniformMatrix4fv(uloc(scnProg, "uVP"), 1, false, vp, 0);
        GLES20.glUniform1f(uloc(scnProg, "uScr"), sceneScr);
        GLES20.glUniform1f(uloc(scnProg, "uTime"), time);
        GLES20.glUniform1f(uloc(scnProg, "uWind"), windS);
        GLES20.glUniform3f(uloc(scnProg, "uEye"), ex, ey, ez);
        GLES20.glUniform3f(uloc(scnProg, "uFog"), skyHor[0], skyHor[1], skyHor[2]);
        GLES20.glUniform3f(uloc(scnProg, "uAmb"), amb[0], amb[1], amb[2]);
        GLES20.glUniform3f(uloc(scnProg, "uSunCol"), sunCol[0], sunCol[1], sunCol[2]);
        GLES20.glUniform1f(uloc(scnProg, "uMist"), mist);
        GLES20.glUniform1f(uloc(scnProg, "uSnow"), Math.min(1f, snow * 1.4f));
        GLES20.glUniform1f(uloc(scnProg, "uWet"), Math.max(rain, storm * 0.9f));
        GLES20.glUniform1f(uloc(scnProg, "uLamp"), lampOn);
        GLES20.glUniform1f(uloc(scnProg, "uFlash"), flash);
        GLES20.glUniform1f(uloc(scnProg, "uQ"), qNow);
        GLES20.glUniform1f(uloc(scnProg, "uGlow"), 0f);
        GLES20.glUniform3f(uloc(scnProg, "uJ"), jx, jSide, jA);
        GLES20.glUniform2f(uloc(scnProg, "uJd"), jDx, jDz);
        int aPos = aloc(scnProg, "aPos");
        int aNrm = aloc(scnProg, "aNrm");
        int aCol = aloc(scnProg, "aCol");
        int aCx = aloc(scnProg, "aCx");
        GLES20.glEnableVertexAttribArray(aPos);
        GLES20.glEnableVertexAttribArray(aNrm);
        GLES20.glEnableVertexAttribArray(aCol);
        GLES20.glEnableVertexAttribArray(aCx);
        drawScn(scnFar, scnFarN, aPos, aNrm, aCol, aCx);
        if (ez > 5.5f && scnNear != 0) drawScn(scnNear, scnNearN, aPos, aNrm, aCol, aCx); // only a wide-back camera sees this side
        drawSign(aPos, aNrm, aCol, aCx, 0.10f + 0.55f * lampOn); // retro-reflective: brighter when the lights are on
        GLES20.glDisableVertexAttribArray(aPos);
        GLES20.glDisableVertexAttribArray(aNrm);
        GLES20.glDisableVertexAttribArray(aCol);
        GLES20.glDisableVertexAttribArray(aCx);
        if (glowProg != 0 && lampOn > 0.01f) drawLampGlow(ex, ey, ez, lampOn);
    }

    /** Spawns the guidance sign when the turn is about as far away (in driving time) as the sign is in the scene, then keeps it in step. */
    private void updateSign(float dt, float vis, float realSpeed) {
        float d = sigDistT;
        if (!sigOnT || sigKindT < 0 || navTarget < 0.5f) {
            signActive = false;
            signDone = false;
            signLastD = 1e9f;
            return;
        }
        boolean jump = d > signLastD + 25f; // the turn was passed: the next maneuver is further away
        signLastD = d;
        if (jump) {
            signDone = false;
            if (signActive) signFree = true; // let the old sign drift past on its own
        }
        float desired = d / Math.max(realSpeed, 3f) * Math.max(vis, 4f); // scene metres: same time-to-turn as the real car
        if (!signActive && !signDone && desired <= SIGN_START && d > 8f) {
            signActive = true;
            signFree = false;
            signX = desired;
            signKind = sigKindT;
            if (signBuf[signKind] == 0) {
                float[] m = signMesh(signKind);
                signBuf[signKind] = vbo(buf(m), m.length);
                signN[signKind] = m.length / Scenery.STRIDE;
            }
        }
        if (signActive) {
            signX -= vis * dtS;
            if (!signFree) signX += (desired - signX) * (1f - (float) Math.exp(-dt / 1.6f));
            if (signX < -70f) {
                signActive = false;
                signDone = true;
            }
        }
    }

    private void drawSign(int aPos, int aNrm, int aCol, int aCx, float glow) {
        if (!signActive || signKind < 0 || signBuf[signKind] == 0 || signX > 160f) return;
        // with a side road the sign stands before the junction, as on a real road
        float sx = signX - (branchOnT && branchKind(signKind) ? 12f : 0f);
        GLES20.glUniform1f(uloc(scnProg, "uScr"), -sx); // the shader slides aCx = 0 geometry to x = sx
        GLES20.glUniform1f(uloc(scnProg, "uGlow"), glow);
        GLES20.glUniform3f(uloc(scnProg, "uJ"), jx, jSide, 0f); // the sign itself is never cleared away
        drawScn(signBuf[signKind], signN[signKind], aPos, aNrm, aCol, aCx);
        GLES20.glUniform1f(uloc(scnProg, "uGlow"), 0f);
        GLES20.glUniform3f(uloc(scnProg, "uJ"), jx, jSide, jA);
        GLES20.glUniform1f(uloc(scnProg, "uScr"), sceneScr);
    }

    private void drawScn(int vbo, int count, int aPos, int aNrm, int aCol, int aCx) {
        if (vbo == 0 || count == 0) return;
        int st = Scenery.STRIDE * 4;
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vbo);
        GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, st, 0);
        GLES20.glVertexAttribPointer(aNrm, 3, GLES20.GL_FLOAT, false, st, 12);
        GLES20.glVertexAttribPointer(aCol, 4, GLES20.GL_FLOAT, false, st, 24);
        GLES20.glVertexAttribPointer(aCx, 1, GLES20.GL_FLOAT, false, st, 40);
        int aCz = aloc(scnProg, "aCz");
        GLES20.glEnableVertexAttribArray(aCz);
        GLES20.glVertexAttribPointer(aCz, 1, GLES20.GL_FLOAT, false, st, 44);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, count);
        GLES20.glDisableVertexAttribArray(aCz);
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0);
    }

    /** Soft additive halos on the street-lamp heads at night (same positions the scenery scrolls through). */
    private void drawLampGlow(float ex, float ey, float ez, float lampOn) {
        GLES20.glUseProgram(glowProg);
        GLES20.glUniformMatrix4fv(uloc(glowProg, "uVP"), 1, false, vp, 0);
        int uCol = uloc(glowProg, "uCol");
        int uA = uloc(glowProg, "uA");
        int aPos = aloc(glowProg, "aPos");
        int aUv = aloc(glowProg, "aUv");
        float rx = view[0], ry = view[4], rz = view[8];
        float ux = view[1], uy = view[5], uz = view[9];
        GLES20.glEnable(GLES20.GL_BLEND);
        GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE);
        GLES20.glDepthMask(false);
        GLES20.glEnableVertexAttribArray(aPos);
        GLES20.glEnableVertexAttribArray(aUv);
        GLES20.glUniform3f(uCol, 1.0f, 0.80f, 0.52f);
        GLES20.glUniform1f(uA, lampOn * 0.85f);
        final float[][] c = CORNERS;
        for (int k = -4; k < 4; k++) {
            float x = (k * Scenery.LAMP_STEP - sceneScr + Scenery.RING / 2) % Scenery.RING;
            if (x < 0) x += Scenery.RING;
            x -= Scenery.RING / 2;
            if (Math.abs(x - ex) > 110f) continue;
            if (jA > 0.3f && jSide < 0f && Math.abs(x - jx) < 8f) continue; // lamp cleared for the side road
            float cx = x, cy = Scenery.LAMP_Y - 0.15f, cz = -Scenery.LAMP_Z;
            float dx = ex - cx, dy = ey - cy, dz = ez - cz;
            float dl = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
            float off = 0.3f / Math.max(dl, 0.5f);
            cx += dx * off;
            cy += dy * off;
            cz += dz * off;
            float sz = 2.1f;
            for (int i = 0; i < 6; i++) {
                float a = c[i][0], b = c[i][1];
                glowV[i * 5] = cx + (rx * a + ux * b) * sz;
                glowV[i * 5 + 1] = cy + (ry * a + uy * b) * sz;
                glowV[i * 5 + 2] = cz + (rz * a + uz * b) * sz;
                glowV[i * 5 + 3] = a;
                glowV[i * 5 + 4] = b;
            }
            glowBuf.position(0);
            glowBuf.put(glowV).position(0);
            glowBuf.position(0);
            GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 20, glowBuf);
            glowBuf.position(3);
            GLES20.glVertexAttribPointer(aUv, 2, GLES20.GL_FLOAT, false, 20, glowBuf);
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 6);
            glowBuf.position(0);
        }
        GLES20.glDisableVertexAttribArray(aPos);
        GLES20.glDisableVertexAttribArray(aUv);
        GLES20.glDepthMask(true);
        GLES20.glDisable(GLES20.GL_BLEND);
    }

    @Override
    public void onDrawFrame(GL10 gl) {
        if (rateApplied != rateIdx) applyRate();
        if (throttleNs > 0L) { // wait out the rest of the frame slot (target rate is a divisor of the panel rate)
            long t0 = System.nanoTime();
            if (nextFrameNs == 0L || nextFrameNs < t0 - 2 * throttleNs) nextFrameNs = t0;
            long wait = nextFrameNs - t0 - 3000000L;
            if (wait > 1000000L) SystemClock.sleep(wait / 1000000L);
            nextFrameNs += throttleNs;
        }
        long now = System.nanoTime();
        long prevNs = lastNs;
        float dt = lastNs == 0 ? 0.016f : Math.min(0.05f, (now - lastNs) / 1e9f);
        lastNs = now;
        float rawDt = prevNs == 0 ? 0f : (now - prevNs) / 1e9f;
        paceGovern(rawDt);
        govern(rawDt);
        time += dt;
        dtS += (dt - dtS) * 0.15f;

        // ---- speed easing: speeds up / slows down smoothly, stops fully when the car stops
        float tgt = SystemClock.elapsedRealtime() - speedAt > 5000 ? 0f : targetSpeed;
        prevSpeed = speed;
        speed += (tgt - speed) * (1f - (float) Math.exp(-dt / 0.7f));
        if (tgt == 0f && speed < 0.05f) speed = 0f;
        float vis = 11f * (1f - (float) Math.exp(-speed / 9f)); // saturating visual speed (m/s)
        float accel = dt > 0 ? (speed - prevSpeed) / dt : 0f;
        scroll = (scroll + vis * dtS) % 6f;
        sceneScr = (sceneScr + vis * dtS) % Scenery.RING;
        wheelAng += vis * dtS / (model != null ? model.wheelRadius : 0.35f);
        wheelAng %= (float) (Math.PI * 2);
        float moving = Math.min(1f, speed / 6f);
        float brakeT = (speed > 1.5f && tgt < speed - 1.2f) ? 1f : 0f; // slowing down: brake lights
        brake += (brakeT - brake) * (1f - (float) Math.exp(-dt / 0.12f));
        nav += (navTarget - nav) * (1f - (float) Math.exp(-dt / 0.45f));
        if (Math.abs(navTarget - nav) < 0.004f) nav = navTarget;
        updateSign(dt, vis, tgt);
        updateBranch(dt);

        // ---- day / night + lights (settings are read about once a second; changes ease in over ~1 s)
        dayCheck -= dt;
        if (dayCheck <= 0f || !dayInit || skyDirty) {
            dayCheck = 1f;
            skyDirty = false;
            try {
                dayTarget = SkyClock.daylight(ctx);
                int lm = Prefs.i(ctx, "carLights", 0);
                lightMode = lm;
                lightsTarget = lm == 1 ? 1f : lm == 2 ? 0f : Math.max(0f, Math.min(1f, (0.70f - dayTarget) / 0.40f));
            } catch (Throwable t) {
                dayTarget = 1f;
                lightsTarget = 0f;
            }
            int sl = 0;
            try {
                sl = Prefs.i(ctx, "carScenery", 0);
            } catch (Throwable t) {
                sl = 0;
            }
            sl = Math.max(0, Math.min(2, sl));
            try {
                gfxMode = Math.max(0, Math.min(2, Prefs.i(ctx, "carGfx", 0)));
            } catch (Throwable t) {
                gfxMode = 0;
            }
            int fs = Prefs.i(ctx, "carFpsSet", 0);
            if (fs != fpsSetting) {
                fpsSetting = fs;
                pickRate();
            }
            if (gfxMode != gfxModeSeen) { // the user picked a quality: forget earlier step-downs
                if (gfxModeSeen != -1) {
                    try {
                        Prefs.putI(ctx, "carFps", 0);
                    } catch (Throwable t) {
                        // ignore
                    }
                    if (fpsSetting == 0) pickRate();
                    govCap = 1;
                    govCounted = false;
                    autoStart = true;
                    try {
                        Prefs.putI(ctx, "carGfxDrops", 0);
                    } catch (Throwable t) {
                        // ignore
                    }
                }
                gfxModeSeen = gfxMode;
            }
            if (sl != scnLevel) {
                scnLevel = sl;
                scnDirty = true;
            }
            if (!dayInit) {
                day = dayTarget;
                lights = lightsTarget;
                dayInit = true;
            }
        }
        if (scnDirty) { // (re)build the roadside scenery: first frame or when the setting changed
            scnDirty = false;
            freeVbo(scnFar);
            freeVbo(scnNear);
            scnFar = 0;
            scnNear = 0;
            scnFarN = scnNearN = 0;
            if (scnLevel < 2 && scnProg != 0) {
                Scenery sc = sceneryFor(scnLevel);
                scnFar = vbo(buf(sc.far), sc.far.length);
                scnFarN = sc.farCount;
                scnNear = vbo(buf(sc.near), sc.near.length);
                scnNearN = sc.nearCount;
            }
        }
        // ---- weather targets from the WMO code
        int wc = wxCode;
        float tC, tR = 0f, tS = 0f, tM = 0f, tSt = 0f;
        if (wc == 0) tC = 0.04f;
        else if (wc == 1) tC = 0.18f;
        else if (wc == 2) tC = 0.50f;
        else if (wc == 3) tC = 0.88f;
        else if (wc == 45 || wc == 48) { tC = 0.75f; tM = 0.85f; }
        else if (wc >= 51 && wc <= 57) { tC = 0.85f; tR = wc == 51 ? 0.25f : wc == 53 ? 0.35f : 0.45f; }
        else if (wc >= 61 && wc <= 67) { tC = 0.95f; tR = wc == 61 ? 0.45f : wc == 63 ? 0.70f : wc == 66 ? 0.60f : 1f; }
        else if (wc >= 71 && wc <= 77) { tC = 0.90f; tS = wc == 71 ? 0.35f : wc == 73 ? 0.65f : wc == 77 ? 0.40f : 1f; }
        else if (wc >= 80 && wc <= 82) { tC = 0.95f; tR = wc == 80 ? 0.50f : wc == 81 ? 0.80f : 1f; }
        else if (wc == 85 || wc == 86) { tC = 0.92f; tS = wc == 85 ? 0.50f : 1f; }
        else if (wc >= 95) { tC = 1f; tR = 1f; tSt = 1f; }
        else tC = 0.3f;
        tM = Math.min(1f, tM + 0.18f * tR + 0.25f * tS);
        float tW = Math.max(0f, Math.min(1f, (wxWind - 12f) / 45f));
        float wk = 1f - (float) Math.exp(-dt / 1.4f);
        if (!wxInit) {
            cloud = tC; rain = tR; snow = tS; mist = tM; storm = tSt; windS = tW;
            wxInit = true;
        }
        cloud += (tC - cloud) * wk;
        rain += (tR - rain) * wk;
        snow += (tS - snow) * wk;
        mist += (tM - mist) * wk;
        storm += (tSt - storm) * wk;
        windS += (tW - windS) * wk;
        float rainy = Math.max(rain, storm);
        cloudT += dt * (0.015f + 0.32f * windS);
        windT += dt * windS * 2.2f;
        // lightning
        if (storm > 0.5f) {
            flashTimer -= dt;
            if (flashTimer <= 0f) {
                flash = 1f;
                flashTimer = 2.5f + (float) Math.random() * 7f;
                flashAgain = Math.random() < 0.5;
            }
        }
        flash = Math.max(0f, flash - dt * 3.2f);
        if (flashAgain && flash > 0f && flash < 0.45f) {
            flash = 0.85f;
            flashAgain = false;
        }
        // head-lights come on by themselves in rain, storms and fog (automatic mode only)
        float lightsEff = lightMode == 0 ? Math.max(lightsTarget, Math.max(0.85f * rainy, 0.9f * Math.min(1f, mist))) : lightsTarget;

        float k = 1f - (float) Math.exp(-dt / 0.9f);
        day += (dayTarget - day) * k;
        lights += (lightsEff - lights) * k;
        if (Math.abs(dayTarget - day) < 0.002f) day = dayTarget;
        if (Math.abs(lightsEff - lights) < 0.002f) lights = lightsEff;
        float twi = 4f * day * (1f - day);
        mix3(skyTop, N_TOP, D_TOP, day);
        mix3(skyTop, skyTop, T_TOP, twi * 0.55f);
        mix3(skyHor, N_HOR, D_HOR, day);
        mix3(skyHor, skyHor, T_HOR, twi * 0.60f);
        mix3(asphalt, N_ASP, D_ASP, day);
        {
            float g = Math.min(1f, cloud * 0.80f);
            float dk = 1f - 0.38f * rainy;
            float lt = skyTop[0] * 0.3f + skyTop[1] * 0.59f + skyTop[2] * 0.11f;
            float lh = skyHor[0] * 0.3f + skyHor[1] * 0.59f + skyHor[2] * 0.11f;
            for (int i = 0; i < 3; i++) {
                skyTop[i] += (lt * dk * (i == 2 ? 1.05f : 1f) + 0.03f - skyTop[i]) * g;
                skyHor[i] += (lh * dk * 0.95f * (i == 2 ? 1.04f : 1f) + 0.02f - skyHor[i]) * g * 0.9f;
            }
            float mm = Math.min(1f, mist) * 0.75f;
            float fogC = 0.20f + 0.58f * day;
            for (int i = 0; i < 3; i++) {
                skyHor[i] += (fogC - skyHor[i]) * mm;
                skyTop[i] += (fogC * 0.9f - skyTop[i]) * mm * 0.6f;
                asphalt[i] *= 1f - 0.28f * Math.max(rain, storm * 0.9f);
            }
        }

        // ---- scenery light and ground colour follow day, dusk, clouds and rain
        float lampOn = scnLevel >= 2 ? 0f
                : Math.max(Math.max(0f, Math.min(1f, (0.70f - day) / 0.40f)), 0.5f * rainy * (1f - 0.5f * day));
        mix3(grass, G_NIGHT, G_DAY, day);
        {
            float glum = grass[0] * 0.3f + grass[1] * 0.59f + grass[2] * 0.11f;
            float cg = Math.min(1f, cloud) * 0.35f;
            for (int i = 0; i < 3; i++) {
                grass[i] += (glum - grass[i]) * cg;
                grass[i] *= 1f - 0.30f * rainy;
            }
            grass[0] += twi * 0.04f;
            mix3(amb, A_NIGHT, A_DAY, day);
            float sunK = (float) Math.pow(day, 1.3) * (1f - 0.75f * Math.min(1f, cloud)) * (1f - 0.6f * rainy) * 0.85f;
            float tw = Math.min(1f, twi * 1.6f);
            sunCol[0] = (0.95f + (1.0f - 0.95f) * tw) * sunK;
            sunCol[1] = (0.88f + (0.55f - 0.88f) * tw) * sunK;
            sunCol[2] = (0.72f + (0.30f - 0.72f) * tw) * sunK;
            for (int i = 0; i < 3; i++) amb[i] += cloud * 0.10f * day;
        }

        // ---- camera: low and wide so the sky has room above the horizon
        float yaw = rear ? (float) Math.toRadians(160f + 6f * Math.sin(time * 0.31f))
                : (float) Math.toRadians(38f + 5f * Math.sin(time * 0.35f));
        float el = (float) Math.toRadians(CAM_EL + 0.8f * Math.sin(time * 0.23f));
        float tv = (float) Math.tan(Math.toRadians(FOV / 2));
        float dist = Math.max(2.25f / tv, 3.2f / (tv * aspect)) * CAM_DIST * (rear ? 0.88f : 1f);
        float tx = 0f, ty = CAM_TY, tz = 0f;
        float ex = tx + dist * (float) (Math.cos(el) * Math.cos(yaw));
        float ey = ty + dist * (float) Math.sin(el);
        float ez = tz + dist * (float) (Math.cos(el) * Math.sin(yaw));
        Matrix.setLookAtM(view, 0, ex, ey, ez, tx, ty, tz, 0, 1, 0);
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0);
        float pitch = (float) Math.atan2(ey - ty, Math.hypot(ex - tx, ez - tz));
        float horizon = 0.5f + 0.5f * (float) Math.tan(pitch) / tv + 0.5f * CAR_LIFT; // screen height (0..1) of the horizon line

        qNow = tierNow();
        GLES20.glClearColor(skyHor[0], skyHor[1], skyHor[2], 1f);
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);

        // ---- sky
        if (skyProg != 0) {
            GLES20.glDisable(GLES20.GL_DEPTH_TEST);
            // below the horizon the road covers the sky (and the cleared colour equals the sky's haze colour there), so only the sky band is shaded
            int skyY = Math.max(0, Math.min(vh - 1, (int) ((horizon - 0.04f) * vh)));
            GLES20.glEnable(GLES20.GL_SCISSOR_TEST);
            GLES20.glScissor(0, skyY, vw, vh - skyY);
            GLES20.glUseProgram(skyProg);
            GLES20.glUniform2f(uloc(skyProg, "uRes"), vw, vh);
            GLES20.glUniform3f(uloc(skyProg, "uTop"), skyTop[0], skyTop[1], skyTop[2]);
            GLES20.glUniform3f(uloc(skyProg, "uFog"), skyHor[0], skyHor[1], skyHor[2]);
            GLES20.glUniform1f(uloc(skyProg, "uDay"), day);
            GLES20.glUniform1f(uloc(skyProg, "uTwi"), twi);
            GLES20.glUniform1f(uloc(skyProg, "uTime"), time);
            GLES20.glUniform1f(uloc(skyProg, "uHor"), horizon);
            GLES20.glUniform1f(uloc(skyProg, "uCloud"), cloud);
            GLES20.glUniform1f(uloc(skyProg, "uRainy"), rainy);
            GLES20.glUniform1f(uloc(skyProg, "uCT"), cloudT);
            GLES20.glUniform1f(uloc(skyProg, "uFlash"), flash);
            GLES20.glUniform1f(uloc(skyProg, "uQ"), qNow);
            int sa = aloc(skyProg, "aPos");
            GLES20.glEnableVertexAttribArray(sa);
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, skyVbo);
            GLES20.glVertexAttribPointer(sa, 2, GLES20.GL_FLOAT, false, 8, 0);
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 6);
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0);
            GLES20.glDisableVertexAttribArray(sa);
            GLES20.glDisable(GLES20.GL_SCISSOR_TEST);
            GLES20.glEnable(GLES20.GL_DEPTH_TEST);
        }

        // ---- road (+ head-light beams and tail-light glow)
        if (gndProg != 0) {
            GLES20.glUseProgram(gndProg);
            GLES20.glUniformMatrix4fv(uloc(gndProg, "uVP"), 1, false, vp, 0);
            GLES20.glUniform1f(uloc(gndProg, "uScroll"), scroll);
            GLES20.glUniform3f(uloc(gndProg, "uEye"), ex, ey, ez);
            GLES20.glUniform3f(uloc(gndProg, "uAccent"), accent[0], accent[1], accent[2]);
            GLES20.glUniform3f(uloc(gndProg, "uFog"), skyHor[0], skyHor[1], skyHor[2]);
            GLES20.glUniform3f(uloc(gndProg, "uAsphalt"), asphalt[0], asphalt[1], asphalt[2]);
            GLES20.glUniform1f(uloc(gndProg, "uLights"), lights);
            GLES20.glUniform2f(uloc(gndProg, "uHead"), headX, headZ);
            GLES20.glUniform2f(uloc(gndProg, "uTail"), tailX, tailZ);
            GLES20.glUniform1f(uloc(gndProg, "uMist"), mist);
            GLES20.glUniform1f(uloc(gndProg, "uWet"), Math.max(rain, storm * 0.9f));
            GLES20.glUniform1f(uloc(gndProg, "uFlash"), flash);
            GLES20.glUniform1f(uloc(gndProg, "uNav"), nav);
            GLES20.glUniform1f(uloc(gndProg, "uQ"), qNow);
            GLES20.glUniform3f(uloc(gndProg, "uJ"), jx, jSide, jA);
            GLES20.glUniform2f(uloc(gndProg, "uJd"), jDx, jDz);
            GLES20.glUniform3f(uloc(gndProg, "uGrass"), grass[0], grass[1], grass[2]);
            GLES20.glUniform1f(uloc(gndProg, "uScn"), scnLevel < 2 ? 1f : 0f);
            GLES20.glUniform1f(uloc(gndProg, "uSS"), sceneScr);
            GLES20.glUniform1f(uloc(gndProg, "uLamp"), lampOn);
            GLES20.glUniform1f(uloc(gndProg, "uSnowG"), Math.min(1f, snow * 1.4f));
            int ga = aloc(gndProg, "aPos");
            GLES20.glEnableVertexAttribArray(ga);
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, gndVbo);
            GLES20.glVertexAttribPointer(ga, 3, GLES20.GL_FLOAT, false, 12, 0);
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 6);
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0);
            GLES20.glDisableVertexAttribArray(ga);
        }

        // ---- car shadow, then trees / rail / lamps
        if (scnLevel < 2) {
            drawShadow();
            drawScenery(ex, ey, ez, lampOn, rainy);
        }

        // ---- car
        if (model == null || carProg == 0) {
            drawPrecip();
            return;
        }
        float bob = 0.012f * moving * (float) Math.sin(time * 17f) + 0.003f * (float) Math.sin(time * 41f);
        float pitchDeg = Math.max(-1.6f, Math.min(1.6f, accel * 0.35f)); // degrees: nose up when accelerating
        Matrix.setIdentityM(wheelM, 0);
        Matrix.translateM(wheelM, 0, 0, bob, 0);
        Matrix.rotateM(wheelM, 0, pitchDeg, 0, 0, 1);
        if (windS > 0.02f) { // strong wind rocks the body a little
            float roll = windS * (0.30f * (float) Math.sin(time * 2.1f) + 0.18f * (float) Math.sin(time * 5.3f + 1f));
            Matrix.rotateM(wheelM, 0, roll, 1, 0, 0);
        }
        Matrix.multiplyMM(bodyM, 0, wheelM, 0, swap, 0);

        GLES20.glUseProgram(carProg);
        int uVP = uloc(carProg, "uVP");
        int uM = uloc(carProg, "uM");
        GLES20.glUniformMatrix4fv(uVP, 1, false, vp, 0);
        GLES20.glUniform3f(uloc(carProg, "uEye"), ex, ey, ez);
        GLES20.glUniform3f(uloc(carProg, "uAccent"), accent[0], accent[1], accent[2]);
        GLES20.glUniform1f(uloc(carProg, "uDay"), day);
        GLES20.glUniform1f(uloc(carProg, "uLights"), lights);
        GLES20.glUniform1f(uloc(carProg, "uBrake"), brake);
        GLES20.glUniform1f(uloc(carProg, "uQ"), qNow);
        float[] pc = PAINT[paintIdx];
        GLES20.glUniform3f(uloc(carProg, "uPaint"), pc[0], pc[1], pc[2]);
        if (rear) GLES20.glUniform3f(uloc(carProg, "uKey"), -0.45f, 0.85f, 0.35f);
        else GLES20.glUniform3f(uloc(carProg, "uKey"), 0.45f, 0.85f, 0.35f);
        GLES20.glUniform3f(uloc(carProg, "uSky"), skyHor[0], skyHor[1], skyHor[2]);
        int aPos = aloc(carProg, "aPos");
        int aNrm = aloc(carProg, "aNrm");
        int aCol = aloc(carProg, "aCol");
        GLES20.glEnableVertexAttribArray(aPos);
        GLES20.glEnableVertexAttribArray(aNrm);
        GLES20.glEnableVertexAttribArray(aCol);

        drawGroup(0, bodyM, uM, aPos, aNrm, aCol);
        float deg = (float) Math.toDegrees(wheelAng);
        for (int i = 0; i < 4; i++) {
            Glb.Group w = model.wheels[i];
            System.arraycopy(bodyM, 0, wheelM, 0, 16);
            Matrix.translateM(wheelM, 0, w.px, w.py, w.pz);
            Matrix.rotateM(wheelM, 0, deg, 0, 1, 0);
            Matrix.translateM(wheelM, 0, -w.px, -w.py, -w.pz);
            drawGroup(i + 1, wheelM, uM, aPos, aNrm, aCol);
        }
        GLES20.glDisableVertexAttribArray(aPos);
        GLES20.glDisableVertexAttribArray(aNrm);
        GLES20.glDisableVertexAttribArray(aCol);

        // ---- lamp glow: soft additive sprites around the lit lamps
        if (glowProg != 0 && (lights > 0.01f || brake > 0.01f) && lamps.length > 0) drawGlow(ex, ey, ez);
        drawPrecip();
    }

    /** Rain, snow, wind streaks and a light mist veil drawn over everything (screen space). */
    private void drawPrecip() {
        if (preProg == 0 || rain + snow + mist + windS < 0.01f) return;
        GLES20.glDisable(GLES20.GL_DEPTH_TEST);
        GLES20.glEnable(GLES20.GL_BLEND);
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA);
        GLES20.glUseProgram(preProg);
        GLES20.glUniform2f(uloc(preProg, "uRes"), vw, vh);
        GLES20.glUniform1f(uloc(preProg, "uT"), time % 1000f);
        GLES20.glUniform1f(uloc(preProg, "uRain"), rain);
        GLES20.glUniform1f(uloc(preProg, "uSnow"), snow);
        GLES20.glUniform1f(uloc(preProg, "uWind"), windS);
        GLES20.glUniform1f(uloc(preProg, "uWT"), windT);
        GLES20.glUniform1f(uloc(preProg, "uDay"), day);
        GLES20.glUniform1f(uloc(preProg, "uMist"), mist);
        GLES20.glUniform3f(uloc(preProg, "uFog"), skyHor[0], skyHor[1], skyHor[2]);
        int pa = aloc(preProg, "aPos");
        GLES20.glEnableVertexAttribArray(pa);
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, skyVbo);
        GLES20.glVertexAttribPointer(pa, 2, GLES20.GL_FLOAT, false, 8, 0);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 6);
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0);
        GLES20.glDisableVertexAttribArray(pa);
        GLES20.glDisable(GLES20.GL_BLEND);
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);
    }

    private void drawGlow(float ex, float ey, float ez) {
        GLES20.glUseProgram(glowProg);
        GLES20.glUniformMatrix4fv(uloc(glowProg, "uVP"), 1, false, vp, 0);
        int uCol = uloc(glowProg, "uCol");
        int uA = uloc(glowProg, "uA");
        int aPos = aloc(glowProg, "aPos");
        int aUv = aloc(glowProg, "aUv");
        float rx = view[0], ry = view[4], rz = view[8]; // camera right
        float ux = view[1], uy = view[5], uz = view[9]; // camera up
        GLES20.glEnable(GLES20.GL_BLEND);
        GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE);
        GLES20.glDepthMask(false);
        GLES20.glEnableVertexAttribArray(aPos);
        GLES20.glEnableVertexAttribArray(aUv);
        for (float[] l : lamps) {
            tmpIn[0] = l[0];
            tmpIn[1] = l[1];
            tmpIn[2] = l[2];
            tmpIn[3] = 1f;
            Matrix.multiplyMV(tmpOut, 0, bodyM, 0, tmpIn, 0);
            float cx = tmpOut[0], cy = tmpOut[1], cz = tmpOut[2];
            float dx = ex - cx, dy = ey - cy, dz = ez - cz;
            float dl = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
            float off = 0.22f / dl;
            cx += dx * off;
            cy += dy * off;
            cz += dz * off;
            boolean head = l[3] == 1f;
            float sz = head ? 0.60f : 0.50f;
            if (head) GLES20.glUniform3f(uCol, 1.0f, 0.93f, 0.78f);
            else GLES20.glUniform3f(uCol, 1.0f, 0.12f, 0.08f);
            GLES20.glUniform1f(uA, head ? lights * 0.95f : Math.max(lights, brake) * 0.80f);
            final float[][] c = CORNERS;
            for (int i = 0; i < 6; i++) {
                float a = c[i][0], b = c[i][1];
                glowV[i * 5] = cx + (rx * a + ux * b) * sz;
                glowV[i * 5 + 1] = cy + (ry * a + uy * b) * sz;
                glowV[i * 5 + 2] = cz + (rz * a + uz * b) * sz;
                glowV[i * 5 + 3] = a;
                glowV[i * 5 + 4] = b;
            }
            glowBuf.position(0);
            glowBuf.put(glowV).position(0);
            glowBuf.position(0);
            GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 20, glowBuf);
            glowBuf.position(3);
            GLES20.glVertexAttribPointer(aUv, 2, GLES20.GL_FLOAT, false, 20, glowBuf);
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 6);
            glowBuf.position(0);
        }
        GLES20.glDisableVertexAttribArray(aPos);
        GLES20.glDisableVertexAttribArray(aUv);
        GLES20.glDepthMask(true);
        GLES20.glDisable(GLES20.GL_BLEND);
    }

    // camera framing (tuned so the horizon sits about two thirds up and the car stands on the road)
    private static final float CAR_LIFT = 0.13f; // fraction of half the screen height
    private static final float CAM_EL = 6f, CAM_DIST = 1.15f, CAM_TY = 1.3f;

    private void drawGroup(int i, float[] m, int uM, int aPos, int aNrm, int aCol) {
        if (carVbo[i] == 0 || carCount[i] == 0) return;
        GLES20.glUniformMatrix4fv(uM, 1, false, m, 0);
        int stride = Glb.STRIDE * 4;
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, carVbo[i]);
        GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, stride, 0);
        GLES20.glVertexAttribPointer(aNrm, 3, GLES20.GL_FLOAT, false, stride, 12);
        GLES20.glVertexAttribPointer(aCol, 4, GLES20.GL_FLOAT, false, stride, 24);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, carCount[i]);
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0);
    }
}
