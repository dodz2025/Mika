package com.mika.launcher;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextClock;
import android.widget.TextView;

/**
 * Home-screen "Car" slide, full screen: the 3D car (sky, weather, road) edge to edge with a light HUD on top:
 * speed + clock + page buttons (top left), weather / day-night / driving pills (top right) and one glass pill
 * at the bottom with the apps button, your pinned apps and, when something is playing, the now-playing controls.
 */
final class CarPage extends FrameLayout {
    interface Host {
        void openDrawer();

        void showHome();

        void openMusic();

        void openLayout();

        void resize();

        void openSettings();

        /** 0 = previous, 1 = play / pause, 2 = next. */
        void mediaAction(int action);

        void openPlayer();
    }

    /** Preview presets for the weather pill: {name, WMO code, wind km/h}. */
    private static final String[] WX_NAME = {"Clear", "Cloudy", "Rain", "Storm", "Snow", "Fog", "Windy"};
    private static final int[] WX_CODE = {0, 3, 65, 95, 75, 45, 1};
    private static final float[] WX_WIND = {5f, 12f, 18f, 48f, 10f, 5f, 58f};

    private final Host host;
    private final Car3DView gl;
    private final LimitSign limitSign;
    private final TextView tvPrayer;
    private final TextView tvSpeed, tvUnit, tvState, tvSky, tvWx, tvStatus, tvTitle, tvArtist;
    private final TextClock clock;
    private final LinearLayout pill, dock, nowGroup;
    private final View divider, btnPlay;
    private final ImageView ivArt;
    private final Bar bar;
    private final int accent, sideMargin;
    private final float sc;
    private final View fadeL, fadeR;

    // navigation card (top centre, only while driving to a destination)
    private final NavCard navCard;
    private final NavArrow navArrow;
    private final TextView tvNavDist, tvNavStreet, tvNavEta;
    private final Bar navBar;
    private View navLeftCol, navRightCol, navPaintRow;
    private boolean navShown = false, navNarrow = false, nHave = false;
    private int navLevel = 0;
    private long arrivedUntil = 0;
    private String arrivedName = "", navKey = "";
    private String nType = "", nMod = "", nDist = "", nStreet = "", nEta = "";
    private float nProg = 0f;
    private double nMeters = 1e9;
    private final Runnable arrivedTick = new Runnable() {
        @Override
        public void run() {
            renderNav();
        }
    };
    private boolean moving = false;
    private boolean active = false;
    private boolean resumed = false;

    // second car slide (rear view) shares status, media, speed and weather with this one
    private CarPage peer;
    private boolean lead;
    private static final int[] PAINT_UI = {0xFF1A1C20, 0xFF8A9098, 0xFFEDEEF0, 0xFFC2102E}; // black, grey, white, red
    private static final String[] PAINT_NAME = {"Black", "Grey", "White", "Red"};
    private final View[] swatch = new View[4];

    /** Links the front and rear car slides; `lead` receives the pushes from MainActivity and passes them on. */
    static void pair(CarPage lead, CarPage other) {
        lead.peer = other;
        lead.lead = true;
        other.peer = lead;
        other.lead = false;
    }

    // weather
    private int liveCode = -1;
    private float liveWind = 0f;
    private String liveTemp = "";

    // now playing (cached so repeated pushes don't relayout)
    private boolean nowInit = false, hasNow = false, nowPlaying = false;
    private String nowTitle = "", nowArtist = "";
    private Bitmap nowArt = null;

    CarPage(Context c, Pal pal, Host h, boolean rear) {
        super(c);
        host = h;
        accent = pal.accent;
        DisplayMetrics dm = c.getResources().getDisplayMetrics();
        float shortDp = Math.min(dm.widthPixels, dm.heightPixels) / dm.density;
        sc = Math.max(0.85f, Math.min(1.25f, shortDp / 400f));
        int edge = Prefs.i(c, "edge", -1);
        sideMargin = Math.max(s(18), edge >= 0 ? Ui.dp(c, edge) : 0);
        int topMargin = Math.max(s(14), edge >= 0 ? Ui.dp(c, edge) : 0);

        gl = new Car3DView(c, pal.accent, rear);
        addView(gl, new FrameLayout.LayoutParams(-1, -1));

        // soft black fade on the left and right edges (the HUD is added after these, so it stays on top)
        fadeL = new View(c);
        fadeR = new View(c);
        addView(fadeL, new FrameLayout.LayoutParams(0, -1, Gravity.LEFT));
        addView(fadeR, new FrameLayout.LayoutParams(0, -1, Gravity.RIGHT));
        applyFade();

        // ------------------------------------------------ top left: speed, clock, status, page buttons
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        tvSpeed = hud(Ui.text(c, "0", 54, 0xFFFFFFFF));
        tvSpeed.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        tvSpeed.setIncludeFontPadding(false);
        tvUnit = hud(Ui.text(c, "km/h", 15, 0xCCFFFFFF));
        LinearLayout spdCol = new LinearLayout(c);
        spdCol.setOrientation(LinearLayout.VERTICAL);
        spdCol.addView(tvSpeed);
        spdCol.addView(tvUnit);
        LinearLayout spdRow = new LinearLayout(c);
        spdRow.setGravity(Gravity.CENTER_VERTICAL);
        spdRow.addView(spdCol);
        limitSign = new LimitSign(c);
        limitSign.setVisibility(View.GONE);
        LinearLayout.LayoutParams lsl = new LinearLayout.LayoutParams(s(52), s(52));
        lsl.leftMargin = s(12);
        spdRow.addView(limitSign, lsl);
        col.addView(spdRow);

        clock = new TextClock(c);
        String fmt = Prefs.b(c, "h24", true) ? "HH:mm" : "h:mm a";
        clock.setFormat24Hour(fmt);
        clock.setFormat12Hour(fmt);
        clock.setTextSize(24);
        clock.setTextColor(0xFFFFFFFF);
        clock.setTypeface(Typeface.DEFAULT_BOLD);
        clock.setIncludeFontPadding(false);
        hud(clock);
        LinearLayout.LayoutParams ckl = new LinearLayout.LayoutParams(-2, -2);
        ckl.topMargin = s(12);
        col.addView(clock, ckl);

        tvStatus = hud(Ui.text(c, "", 12, 0xCCFFFFFF));
        col.addView(tvStatus);

        tvPrayer = hud(Ui.text(c, "", 12, 0xFFFFFFFF));
        tvPrayer.setPadding(s(12), s(5), s(12), s(5));
        tvPrayer.setVisibility(View.GONE);
        LinearLayout.LayoutParams prayLp = new LinearLayout.LayoutParams(-2, -2);
        prayLp.topMargin = s(6);
        col.addView(tvPrayer, prayLp);

        LinearLayout btns = new LinearLayout(c);
        btns.setGravity(Gravity.CENTER_VERTICAL);
        btns.addView(pageBtn(Icons.CAR, true, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                host.showHome();
            }
        }, null));
        btns.addView(pageBtn(Icons.MUSIC, false, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                host.openMusic();
            }
        }, null));
        btns.addView(pageBtn(Icons.LAYOUT, false, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                host.openLayout();
            }
        }, new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                host.resize();
                return true;
            }
        }));
        btns.addView(pageBtn(Icons.GEAR, false, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                host.openSettings();
            }
        }, new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                host.resize();
                return true;
            }
        }));
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-2, -2);
        bl.topMargin = s(12);
        col.addView(btns, bl);
        FrameLayout.LayoutParams cl = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.LEFT);
        cl.leftMargin = sideMargin;
        cl.topMargin = topMargin;
        addView(col, cl);
        navLeftCol = col;

        // ------------------------------------------------ top right: weather / sky / driving pills
        LinearLayout pills = new LinearLayout(c);
        pills.setGravity(Gravity.CENTER_VERTICAL);
        tvWx = topPill(c);
        tvSky = topPill(c);
        tvState = topPill(c);
        pills.addView(tvWx);
        LinearLayout.LayoutParams gap = new LinearLayout.LayoutParams(-2, -2);
        gap.leftMargin = s(8);
        pills.addView(tvSky, gap);
        LinearLayout.LayoutParams gap2 = new LinearLayout.LayoutParams(-2, -2);
        gap2.leftMargin = s(8);
        pills.addView(tvState, gap2);
        LinearLayout right = new LinearLayout(c);
        right.setOrientation(LinearLayout.VERTICAL);
        right.setGravity(Gravity.RIGHT);
        right.addView(pills, new LinearLayout.LayoutParams(-2, -2));

        // car colour: black / grey / white / red
        LinearLayout paintRow = new LinearLayout(c);
        paintRow.setGravity(Gravity.CENTER_VERTICAL);
        paintRow.setPadding(s(8), s(5), s(8), s(5));
        paintRow.setBackground(Ui.pill(c, 0x66000000, 18));
        for (int i = 0; i < 4; i++) {
            final int idx = i;
            View sw = new View(c);
            sw.setContentDescription(PAINT_NAME[i]);
            sw.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Prefs.putI(getContext(), "carPaint", idx);
                    applyPaint();
                    if (peer != null) peer.applyPaint();
                }
            });
            LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(s(28), s(28));
            if (i > 0) sl.leftMargin = s(8);
            paintRow.addView(sw, sl);
            swatch[i] = sw;
        }
        LinearLayout.LayoutParams prl = new LinearLayout.LayoutParams(-2, -2);
        prl.topMargin = s(8);
        right.addView(paintRow, prl);
        FrameLayout.LayoutParams pl = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.RIGHT);
        pl.rightMargin = sideMargin;
        pl.topMargin = topMargin;
        addView(right, pl);
        navRightCol = right;
        navPaintRow = paintRow;

        // ------------------------------------------------ top centre, under the pills: navigation card
        navCard = new NavCard(c);
        navCard.setOrientation(LinearLayout.VERTICAL);
        navCard.setPadding(s(12), s(9), s(16), s(10));
        navCard.setVisibility(View.GONE);
        LinearLayout navRow = new LinearLayout(c);
        navRow.setGravity(Gravity.CENTER_VERTICAL);
        navArrow = new NavArrow(c);
        navRow.addView(navArrow, new LinearLayout.LayoutParams(s(44), s(44)));
        LinearLayout navText = new LinearLayout(c);
        navText.setOrientation(LinearLayout.VERTICAL);
        tvNavDist = Ui.text(c, "", 22, 0xFFFFFFFF);
        tvNavDist.setTypeface(Typeface.DEFAULT_BOLD);
        tvNavDist.setSingleLine(true);
        tvNavDist.setIncludeFontPadding(false);
        tvNavStreet = Ui.text(c, "", 13, 0xCCFFFFFF);
        tvNavStreet.setSingleLine(true);
        tvNavStreet.setEllipsize(android.text.TextUtils.TruncateAt.END);
        navText.addView(tvNavDist);
        navText.addView(tvNavStreet);
        LinearLayout.LayoutParams ntl = new LinearLayout.LayoutParams(-2, -2);
        ntl.leftMargin = s(10);
        navRow.addView(navText, ntl);
        navCard.addView(navRow, new LinearLayout.LayoutParams(-2, -2));
        tvNavEta = Ui.text(c, "", 12, 0xCCFFFFFF);
        tvNavEta.setSingleLine(true);
        tvNavEta.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams nel = new LinearLayout.LayoutParams(-2, -2);
        nel.topMargin = s(4);
        navCard.addView(tvNavEta, nel);
        navBar = new Bar(c, accent);
        LinearLayout.LayoutParams nbl = new LinearLayout.LayoutParams(-1, Math.max(3, Ui.dp(c, 3)));
        nbl.topMargin = s(6);
        navCard.addView(navBar, nbl);
        FrameLayout.LayoutParams ncl = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        ncl.topMargin = topMargin + s(44);
        addView(navCard, ncl);
        styleNavCard(false);

        tvSky.setText(SkyClock.label(c));
        tvSky.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Context cx = getContext();
                Prefs.putI(cx, "skyMode", (SkyClock.mode(cx) + 1) % 3);
                tvSky.setText(SkyClock.label(cx));
                gl.skyChanged();
                if (peer != null) peer.refreshPills();
            }
        });
        // weather pill: tap to preview Live -> Clear -> Cloudy -> Rain -> Storm -> Snow -> Fog -> Windy
        tvWx.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Context cx = getContext();
                Prefs.putI(cx, "carWx", (Prefs.i(cx, "carWx", 0) + 1) % (WX_NAME.length + 1));
                applyWeather();
                if (peer != null) peer.applyWeather();
            }
        });

        // ------------------------------------------------ bottom: one glass pill
        pill = new LinearLayout(c);
        pill.setGravity(Gravity.CENTER_VERTICAL);
        pill.setPadding(s(10), s(6), s(10), s(6));
        pill.setBackground(Ui.glass(c, 0x8C22252D, 0x30FFFFFF, 40));

        View apps = Ui.iconButton(c, Icons.APPS, 48, 24, accent, 0xFFFFFFFF);
        apps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                host.openDrawer();
            }
        });
        LinearLayout.LayoutParams al = new LinearLayout.LayoutParams(s(48), s(48));
        al.rightMargin = s(6);
        pill.addView(apps, al);

        dock = new LinearLayout(c);
        dock.setGravity(Gravity.CENTER_VERTICAL);
        pill.addView(dock, new LinearLayout.LayoutParams(-2, -2));

        divider = new View(c);
        divider.setBackgroundColor(0x33FFFFFF);
        LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(Math.max(1, Ui.dp(c, 1)), s(44));
        dl.leftMargin = s(10);
        dl.rightMargin = s(12);
        pill.addView(divider, dl);

        // now playing: [cover][title / artist] + progress, then the controls
        nowGroup = new LinearLayout(c);
        nowGroup.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout left = new LinearLayout(c);
        left.setOrientation(LinearLayout.VERTICAL);
        LinearLayout top = new LinearLayout(c);
        top.setGravity(Gravity.CENTER_VERTICAL);
        ivArt = new ImageView(c);
        ivArt.setScaleType(ImageView.ScaleType.CENTER_CROP);
        ivArt.setBackground(Ui.pill(c, 0x33FFFFFF, 12));
        ivArt.setClipToOutline(true);
        top.addView(ivArt, new LinearLayout.LayoutParams(s(46), s(46)));
        LinearLayout tcol = new LinearLayout(c);
        tcol.setOrientation(LinearLayout.VERTICAL);
        tvTitle = Ui.text(c, "", 15, 0xFFFFFFFF);
        tvTitle.setTypeface(Typeface.DEFAULT_BOLD);
        tvTitle.setSingleLine(true);
        tvTitle.setEllipsize(android.text.TextUtils.TruncateAt.MARQUEE);
        tvTitle.setMarqueeRepeatLimit(-1);
        tvTitle.setSelected(true);
        tvArtist = Ui.text(c, "", 12, 0xCCFFFFFF);
        tvArtist.setSingleLine(true);
        tvArtist.setEllipsize(android.text.TextUtils.TruncateAt.END);
        tcol.addView(tvTitle);
        tcol.addView(tvArtist);
        LinearLayout.LayoutParams tcl = new LinearLayout.LayoutParams(0, -2, 1f);
        tcl.leftMargin = s(12);
        top.addView(tcol, tcl);
        left.addView(top, new LinearLayout.LayoutParams(-1, -2));
        bar = new Bar(c, accent);
        LinearLayout.LayoutParams barl = new LinearLayout.LayoutParams(-1, Math.max(3, Ui.dp(c, 3)));
        barl.topMargin = s(6);
        left.addView(bar, barl);
        nowGroup.addView(left, new LinearLayout.LayoutParams(0, -2, 1f));
        View.OnClickListener open = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                host.openPlayer();
            }
        };
        left.setOnClickListener(open);

        LinearLayout ctrl = new LinearLayout(c);
        ctrl.setGravity(Gravity.CENTER_VERTICAL);
        ctrl.addView(ctlBtn(Icons.PREV, 38, 18, false, 0));
        btnPlay = ctlBtn(Icons.PLAY, 46, 22, true, 1);
        ctrl.addView(btnPlay);
        ctrl.addView(ctlBtn(Icons.NEXT, 38, 18, false, 2));
        LinearLayout.LayoutParams ctl = new LinearLayout.LayoutParams(-2, -2);
        ctl.leftMargin = s(12);
        nowGroup.addView(ctrl, ctl);
        pill.addView(nowGroup, new LinearLayout.LayoutParams(0, -2, 1f));

        FrameLayout.LayoutParams pil = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        pil.bottomMargin = Math.max(s(8), edge >= 0 ? Ui.dp(c, edge) : 0);
        addView(pill, pil);
        setNowPlaying(false, "", "", null, false);

        paintState();
        applyWeather();
        applyPaint();
    }

    /** Sky label / weather / paint changed on the other slide: follow it. */
    void refreshPills() {
        tvSky.setText(SkyClock.label(getContext()));
        applyWeather();
        gl.skyChanged();
    }

    /** Applies the saved car colour (Prefs "carPaint": 0 black, 1 grey, 2 white, 3 red) and marks the swatch. */
    void applyPaint() {
        Context cx = getContext();
        int sel = Math.max(0, Math.min(3, Prefs.i(cx, "carPaint", 3)));
        gl.setPaint(sel);
        for (int i = 0; i < 4; i++) {
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(PAINT_UI[i]);
            g.setStroke(Ui.dp(cx, i == sel ? 3 : 1), i == sel ? accent : 0x66FFFFFF);
            swatch[i].setBackground(g);
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        applyFade();
    }

    /** Settings > "Car page side fade": 0 = off, 1 = soft (14% of the width), 2 = wide (24%). Eased, so no visible band. */
    private void applyFade() {
        int mode = Prefs.i(getContext(), "carFade", 1);
        float frac = mode == 1 ? 0.14f : mode == 2 ? 0.24f : 0f;
        int w = getWidth() > 0 ? getWidth() : getResources().getDisplayMetrics().widthPixels;
        int fw = Math.round(w * frac);
        int n = 16;
        int[] cols = new int[n];
        for (int i = 0; i < n; i++) {
            float t = i / (float) (n - 1);
            float sm = t * t * (3f - 2f * t);
            cols[i] = ((int) (255f * (1f - sm)) << 24); // black with eased alpha: opaque at the edge, clear inside
        }
        fadeL.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, cols));
        fadeR.setBackground(new GradientDrawable(GradientDrawable.Orientation.RIGHT_LEFT, cols));
        for (View v : new View[]{fadeL, fadeR}) {
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) v.getLayoutParams();
            if (lp.width != fw) {
                lp.width = fw;
                v.setLayoutParams(lp);
            }
            v.setVisibility(fw > 0 ? View.VISIBLE : View.GONE);
        }
    }

    private int s(int dp) {
        return Ui.dp(getContext(), Math.round(dp * sc));
    }

    private TextView hud(TextView t) {
        t.setShadowLayer(Ui.dp(getContext(), 3), 0f, Ui.dp(getContext(), 1), 0x99000000);
        return t;
    }

    private TextView topPill(Context c) {
        TextView t = Ui.text(c, "", 13, 0xFFFFFFFF);
        t.setGravity(Gravity.CENTER);
        t.setSingleLine(true);
        t.setPadding(s(14), s(7), s(14), s(7));
        t.setBackground(Ui.pill(c, 0x66000000, 18));
        return t;
    }

    private View pageBtn(int icon, boolean on, View.OnClickListener l, View.OnLongClickListener ll) {
        View b = Ui.iconButton(getContext(), icon, 42, 22, on ? accent : 0x52000000, 0xFFFFFFFF);
        b.setOnClickListener(l);
        if (ll != null) b.setOnLongClickListener(ll);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(s(42), s(42));
        lp.rightMargin = s(8);
        b.setLayoutParams(lp);
        return b;
    }

    private View ctlBtn(int icon, int size, int iconDp, boolean primary, final int action) {
        View b = Ui.iconButton(getContext(), icon, size, iconDp, primary ? accent : 0x40FFFFFF, 0xFFFFFFFF);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(s(size), s(size));
        lp.leftMargin = s(3);
        lp.rightMargin = s(3);
        b.setLayoutParams(lp);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                host.mediaAction(action);
            }
        });
        return b;
    }

    // ------------------------------------------------------------------ API for MainActivity
    /** The container for the pinned-app icons inside the bottom pill. */
    LinearLayout dockView() {
        return dock;
    }

    /** Re-sizes the app cells to the pill (called after the cells are added). */
    int cellSizeDp() {
        return Math.round(44 * sc);
    }

    void setStatus(String s) {
        if (lead && peer != null) peer.setStatus(s);
        tvStatus.setText(s);
    }

    /** What is playing now; hidden when nothing is. */
    void setNowPlaying(boolean has, String title, String artist, Bitmap art, boolean playing) {
        if (lead && peer != null) peer.setNowPlaying(has, title, artist, art, playing);
        if (title == null) title = "";
        if (artist == null) artist = "";
        boolean same = nowInit && has == hasNow && playing == nowPlaying && art == nowArt
                && title.equals(nowTitle) && artist.equals(nowArtist);
        if (same) return;
        boolean visChanged = !nowInit || has != hasNow;
        nowInit = true;
        hasNow = has;
        nowPlaying = playing;
        nowTitle = title;
        nowArtist = artist;
        nowArt = art;
        tvTitle.setText(title);
        tvArtist.setText(artist);
        tvArtist.setVisibility(artist.length() == 0 ? View.GONE : View.VISIBLE);
        if (art == null) ivArt.setImageDrawable(null);
        else ivArt.setImageBitmap(art);
        Ui.setIcon(btnPlay, playing ? Icons.PAUSE : Icons.PLAY, 0xFFFFFFFF);
        if (visChanged) {
            nowGroup.setVisibility(has ? View.VISIBLE : View.GONE);
            divider.setVisibility(has ? View.VISIBLE : View.GONE);
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) pill.getLayoutParams();
            if (has) {
                lp.width = -1;
                lp.leftMargin = Math.max(s(18), sideMargin);
                lp.rightMargin = Math.max(s(18), sideMargin);
            } else {
                lp.width = -2;
                lp.leftMargin = 0;
                lp.rightMargin = 0;
            }
            pill.setLayoutParams(lp);
        }
    }

    /** Playback position in thousandths (0..1000). */
    void setProgress(int permille) {
        if (lead && peer != null) peer.setProgress(permille);
        bar.set(permille / 1000f);
    }

    /** Live weather from the forecast: WMO code, wind in km/h and a short temperature text like "18°C". */
    void setLiveWeather(int code, float windKmh, String temp) {
        if (lead && peer != null) peer.setLiveWeather(code, windKmh, temp);
        liveCode = code;
        liveWind = windKmh;
        liveTemp = temp == null ? "" : temp;
        applyWeather();
    }

    /** Picks live weather or the preview chosen with the weather pill, and tells the 3D scene. */
    void applyWeather() {
        Context c = getContext();
        int ov = Prefs.i(c, "carWx", 0);
        boolean fx = Prefs.b(c, "carWxFx", true);
        int code = 0;
        float wind = 0f;
        String label;
        if (ov > 0 && ov <= WX_NAME.length) {
            code = WX_CODE[ov - 1];
            wind = WX_WIND[ov - 1];
            label = WeatherClient.emoji(code, true) + " " + WX_NAME[ov - 1] + " \u00B7 preview";
        } else if (liveCode >= 0) {
            code = liveCode;
            wind = liveWind;
            label = WeatherClient.emoji(code, true) + " " + WeatherClient.describe(code)
                    + (liveTemp.length() > 0 ? " \u00B7 " + liveTemp : "")
                    + (wind >= 40f ? " \u00B7 Windy" : "");
        } else {
            label = "Weather";
        }
        tvWx.setText(label);
        gl.setWeather(fx ? code : 0, fx ? wind : 0f);
    }

    /** Kept for HomePager: nothing to re-sample any more now that the page is full screen. */
    void onSlide() {
        updateGl();
    }

    /** Only the target slide renders continuously (one GL view at a time keeps swipes smooth); a slide that starts sliding in gets one still frame first. */
    private void updateGl() {
        boolean on = resumed && active;
        boolean vis = getWidth() == 0 || Math.abs(getTranslationX()) < getWidth() - 1;
        if (vis && !visSeen && !on) gl.requestRender(); // one still frame when it starts sliding in
        visSeen = vis;
        if (on == glOn) return;
        glOn = on;
        gl.setActive(on);
    }
    private boolean glOn = false;
    private boolean visSeen = false;

    private void paintState() {
        tvState.setText(moving ? "Driving" : "Parked");
        tvState.setBackground(Ui.pill(getContext(), moving ? accent : 0x66000000, 18));
    }

    /** speedMs: GPS speed in m/s (0 when there is no fix). */
    void setSpeed(float speedMs, boolean mph) {
        if (lead && peer != null) peer.setSpeed(speedMs, mph);
        gl.setSpeed(speedMs);
        float shown = speedMs * (mph ? 2.23694f : 3.6f);
        boolean mv = speedMs >= 0.8f;
        tvSpeed.setText(String.valueOf(mv ? Math.round(shown) : 0));
        tvUnit.setText(mph ? "mph" : "km/h");
        renderLimit(mph);
        if (mv != moving) {
            moving = mv;
            paintState();
        }
    }

    // ------------------------------------------------------------------ next prayer
    private final Runnable prayerTick = new Runnable() {
        @Override
        public void run() {
            refreshPrayer();
            postDelayed(this, 30000);
        }
    };

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        post(prayerTick);
    }

    @Override
    protected void onDetachedFromWindow() {
        removeCallbacks(prayerTick);
        super.onDetachedFromWindow();
    }

    /** "Asr  14:47  ·  1h 05m": the next prayer and the time left; the pill lights up in the last 15 minutes. */
    private void refreshPrayer() {
        Context c = getContext();
        long now = System.currentTimeMillis();
        long[] n = Prefs.b(c, "prayerOn", true) ? PrayerTimes.next(c, now) : null;
        if (n == null) {
            tvPrayer.setVisibility(View.GONE);
            return;
        }
        long rem = n[1] - now;
        tvPrayer.setText(PrayerTimes.name(c, (int) n[0]) + "  " + PrayerTimes.fmtTime(c, n[1]) + "  \u00B7  " + PrayerTimes.fmtRemain(c, rem));
        tvPrayer.setBackground(Ui.pill(c, rem < 15 * 60000L ? accent : 0x66000000, 14));
        tvPrayer.setVisibility(View.VISIBLE);
    }

    /** Round speed-limit sign next to the speed; the speed turns red while you are over the limit. */
    private void renderLimit(boolean mph) {
        int lim = SpeedLimit.kmh;
        boolean show = lim > 0 && SpeedLimit.mode(getContext()) != 0;
        if (show != (limitSign.getVisibility() == View.VISIBLE)) limitSign.setVisibility(show ? View.VISIBLE : View.GONE);
        if (!show) {
            tvSpeed.setTextColor(0xFFFFFFFF);
            return;
        }
        boolean over = SpeedLimit.over;
        limitSign.set(mph ? (int) Math.round(lim / 1.609) : lim, SpeedLimit.estimated, over);
        tvSpeed.setTextColor(over ? 0xFFFF5A5A : 0xFFFFFFFF);
    }

    /** European style limit sign: white disc, red ring, black number ("~" above it when the limit is only an estimate). */
    private static final class LimitSign extends View {
        private final android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        private int num = 0;
        private boolean est = false, over = false;

        LimitSign(Context c) {
            super(c);
        }

        void set(int n, boolean e, boolean o) {
            if (n == num && e == est && o == over) return;
            num = n;
            est = e;
            over = o;
            invalidate();
        }

        @Override
        protected void onDraw(android.graphics.Canvas cv) {
            float w = getWidth(), h = getHeight(), r = Math.min(w, h) / 2f, cx = w / 2f, cy = h / 2f;
            p.setStyle(android.graphics.Paint.Style.FILL);
            p.setColor(over ? 0xFFFFE9E9 : 0xFFFFFFFF);
            cv.drawCircle(cx, cy, r, p);
            p.setStyle(android.graphics.Paint.Style.STROKE);
            p.setStrokeWidth(r * 0.22f);
            p.setColor(over ? 0xFFFF2B2B : 0xFFD81F26);
            cv.drawCircle(cx, cy, r * 0.89f, p);
            p.setStyle(android.graphics.Paint.Style.FILL);
            p.setColor(over ? 0xFFC40000 : 0xFF111111);
            p.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
            p.setTextAlign(android.graphics.Paint.Align.CENTER);
            String t = String.valueOf(num);
            p.setTextSize(r * (t.length() >= 3 ? 0.82f : 1.05f));
            cv.drawText(t, cx, cy + p.getTextSize() * 0.35f, p);
            if (est) {
                p.setTextSize(r * 0.5f);
                cv.drawText("~", cx, cy - r * 0.42f, p);
            }
        }
    }

    // ------------------------------------------------------------------ navigation card
    /** Keeps the card clear of the speed column and the colour swatches; very narrow screens fall back to the compact pill. */
    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        super.onLayout(changed, l, t, r, b);
        if (navLeftCol == null || navRightCol == null || navPaintRow == null) return;
        int w = r - l;
        int rightEdge = navRightCol.getLeft() + navPaintRow.getLeft();
        int half = Math.min(w / 2 - navLeftCol.getRight(), rightEdge - w / 2) - s(12);
        int avail = Math.max(s(120), half * 2);
        if (avail != navCard.maxW) {
            navCard.maxW = avail;
            navCard.requestLayout();
        }
        boolean narrow = avail < s(200);
        if (narrow != navNarrow) {
            navNarrow = narrow;
            post(arrivedTick);
        }
    }

    /**
     * Next turn for the guidance card and the route ribbon on the road. `type` / `mod` are the OSRM-style maneuver
     * (see NavState), `meters` the distance to that turn. Settings > Car page > Navigation: full / compact / off.
     */
    void setNav(boolean on, String type, String mod, String dist, String street, String eta, float progress, double meters) {
        if (lead && peer != null) peer.setNav(on, type, mod, dist, street, eta, progress, meters);
        nHave = on;
        nType = type == null ? "" : type;
        nMod = mod == null ? "" : mod;
        nDist = dist == null ? "" : dist;
        nStreet = street == null ? "" : street;
        nEta = eta == null ? "" : eta;
        nProg = progress;
        nMeters = meters;
        renderNav();
    }

    /** Destination reached: a short "You have arrived" card, then it fades away. */
    void navArrived(String name) {
        if (lead && peer != null) peer.navArrived(name);
        arrivedName = name == null ? "" : name;
        arrivedUntil = SystemClock.elapsedRealtime() + 6000;
        nHave = false;
        renderNav();
        removeCallbacks(arrivedTick);
        postDelayed(arrivedTick, 6100);
    }

    private void renderNav() {
        Context c = getContext();
        int mode = Prefs.i(c, "carNav", 0); // 0 full, 1 compact, 2 off
        boolean arrived = !nHave && SystemClock.elapsedRealtime() < arrivedUntil;
        gl.setNav(nHave && mode != 2);
        gl.setBranch(Prefs.b(c, "carBranch", true));
        gl.setSign(signKind(nType, nMod), nMeters, nHave && mode != 2 && Prefs.b(c, "carSign", true));
        if (mode == 2 || (!nHave && !arrived)) {
            hideNav();
            return;
        }
        boolean compact = mode == 1 || navNarrow;
        int lvl = arrived ? 0 : nMeters <= 200 ? 2 : nMeters <= 500 ? 1 : 0;
        String key = arrived ? "A|" + arrivedName + "|" + compact
                : nType + "|" + nMod + "|" + nDist + "|" + nStreet + "|" + nEta + "|" + lvl + "|" + compact;
        if (navShown && key.equals(navKey)) {
            navBar.set(nProg);
            return;
        }
        navKey = key;
        boolean up = lvl > navLevel;
        navLevel = lvl;
        if (arrived) {
            navArrow.set("arrive", "");
            tvNavDist.setText("You have arrived");
            tvNavStreet.setText(arrivedName);
            navBar.set(0f);
        } else {
            navArrow.set(nType, nMod);
            tvNavDist.setText(nDist);
            tvNavStreet.setText(nStreet.length() > 0 ? nStreet : "");
            tvNavEta.setText(nEta);
            navBar.set(nProg);
        }
        styleNavCard(arrived || lvl >= 2);
        int a = compact ? s(32) : s(44);
        LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) navArrow.getLayoutParams();
        if (lp.width != a) {
            lp.width = a;
            lp.height = a;
            navArrow.setLayoutParams(lp);
        }
        tvNavDist.setTextSize(compact ? 18 : 22);
        tvNavStreet.setVisibility(compact || (arrived ? arrivedName.length() == 0 : nStreet.length() == 0) ? View.GONE : View.VISIBLE);
        int det = compact || arrived ? View.GONE : View.VISIBLE;
        tvNavEta.setVisibility(det);
        navBar.setVisibility(det);
        navCard.setPadding(compact ? s(8) : s(12), compact ? s(6) : s(9), compact ? s(14) : s(16), compact ? s(6) : s(10));
        showNav();
        if (up) pulseNav();
    }

    /** Which road sign the next maneuver gets (see Scenery.sign), or -1 for none (start, arrival, "continue"). */
    private static int signKind(String type, String mod) {
        if (type == null || !NavVoice.isManeuver(type) || "arrive".equals(type)) return -1;
        if (type.startsWith("roundabout") || "rotary".equals(type)) return 5;
        if ("uturn".equals(mod)) return 6;
        if ("right".equals(mod) || "sharp right".equals(mod)) return 0;
        if ("left".equals(mod) || "sharp left".equals(mod)) return 1;
        if ("slight right".equals(mod)) return 3;
        if ("slight left".equals(mod)) return 4;
        return "merge".equals(type) || "on ramp".equals(type) || "off ramp".equals(type) || "ramp".equals(type) ? 2 : -1;
    }

    private void styleNavCard(boolean hot) {
        Context c = getContext();
        navCard.setBackground(Ui.glass(c, hot ? 0xCC22252D : 0x8C22252D, hot ? accent : 0x30FFFFFF, 22));
        navArrow.setColor(hot ? accent : 0xFFFFFFFF);
    }

    private void showNav() {
        if (navShown) return;
        navShown = true;
        navCard.animate().cancel();
        navCard.setVisibility(View.VISIBLE);
        navCard.setAlpha(0f);
        navCard.animate().alpha(1f).setDuration(250).start();
    }

    private void hideNav() {
        navKey = "";
        navLevel = 0;
        if (!navShown) return;
        navShown = false;
        navCard.animate().cancel();
        navCard.animate().alpha(0f).setDuration(250).withEndAction(new Runnable() {
            @Override
            public void run() {
                if (!navShown) navCard.setVisibility(View.GONE);
            }
        }).start();
    }

    /** One soft swell when the next turn gets close (500 m, then 200 m). */
    private void pulseNav() {
        navCard.animate().scaleX(1.06f).scaleY(1.06f).setDuration(160).withEndAction(new Runnable() {
            @Override
            public void run() {
                navCard.animate().scaleX(1f).scaleY(1f).setDuration(260).start();
            }
        }).start();
    }

    /** True while the Car page is the visible slide: only then does the GL view render continuously. */
    void setActive(boolean on) {
        active = on;
        updateGl();
    }

    void onHostResume() {
        if (lead && peer != null) peer.onHostResume();
        resumed = true;
        applyPaint();
        applyFade();
        renderNav();
        tvSky.setText(SkyClock.label(getContext()));
        applyWeather();
        gl.skyChanged();
        gl.onResume();
        glOn = false;
        updateGl();
    }

    void onHostPause() {
        if (lead && peer != null) peer.onHostPause();
        resumed = false;
        glOn = false;
        gl.setActive(false);
        gl.onPause();
    }

    /** Glass card whose width is capped (set from onLayout) so it never runs under the speed column or the swatches. */
    private static final class NavCard extends LinearLayout {
        int maxW = Integer.MAX_VALUE;

        NavCard(Context c) {
            super(c);
        }

        @Override
        protected void onMeasure(int wSpec, int hSpec) {
            int mode = MeasureSpec.getMode(wSpec), size = MeasureSpec.getSize(wSpec);
            if (maxW > 0 && (mode == MeasureSpec.UNSPECIFIED || size > maxW)) {
                wSpec = MeasureSpec.makeMeasureSpec(maxW, MeasureSpec.AT_MOST);
            }
            super.onMeasure(wSpec, hSpec);
        }
    }

    /** Turn arrow drawn from the OSRM-style maneuver (turn / fork / ramp with a modifier, roundabout, u-turn, arrive). */
    private static final class NavArrow extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        private final RectF oval = new RectF();
        private String type = "", mod = "";
        private int color = 0xFFFFFFFF;

        NavArrow(Context c) {
            super(c);
        }

        void set(String t, String m) {
            type = t == null ? "" : t;
            mod = m == null ? "" : m;
            invalidate();
        }

        void setColor(int c) {
            if (c == color) return;
            color = c;
            invalidate();
        }

        private void head(Canvas cv, float x, float y, float dx, float dy, float len) {
            for (int sgn = -1; sgn <= 1; sgn += 2) {
                double a = Math.toRadians(150.0 * sgn);
                float rx = (float) (dx * Math.cos(a) - dy * Math.sin(a));
                float ry = (float) (dx * Math.sin(a) + dy * Math.cos(a));
                cv.drawLine(x, y, x + rx * len, y + ry * len, p);
            }
        }

        @Override
        protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight(), u = Math.min(w, h), cx = w / 2f, cy = h / 2f;
            p.setColor(color);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeJoin(Paint.Join.ROUND);
            p.setStrokeWidth(u * 0.11f);
            p.setStyle(Paint.Style.STROKE);
            path.reset();
            if ("arrive".equals(type)) {
                float px = cx - 0.18f * u;
                cv.drawLine(px, cy + 0.34f * u, px, cy - 0.34f * u, p);
                path.moveTo(px, cy - 0.34f * u);
                path.lineTo(cx + 0.30f * u, cy - 0.16f * u);
                path.lineTo(px, cy + 0.02f * u);
                path.close();
                p.setStyle(Paint.Style.FILL);
                cv.drawPath(path, p);
                return;
            }
            if (type.startsWith("roundabout") || "rotary".equals(type)) {
                float r = 0.24f * u, ccy = cy - 0.04f * u;
                oval.set(cx - r, ccy - r, cx + r, ccy + r);
                float start = 100f, sweep = 290f;
                cv.drawArc(oval, start, sweep, false, p);
                double a = Math.toRadians(start + sweep);
                float ex = cx + (float) (r * Math.cos(a)), ey = ccy + (float) (r * Math.sin(a));
                head(cv, ex, ey, (float) -Math.sin(a), (float) Math.cos(a), 0.18f * u);
                cv.drawLine(cx, cy + 0.40f * u, cx, ccy + r, p);
                return;
            }
            if ("uturn".equals(mod)) {
                path.moveTo(cx + 0.16f * u, cy + 0.36f * u);
                path.lineTo(cx + 0.16f * u, cy - 0.10f * u);
                oval.set(cx - 0.16f * u, cy - 0.42f * u, cx + 0.16f * u, cy - 0.10f * u);
                path.arcTo(oval, 0f, -180f);
                path.lineTo(cx - 0.16f * u, cy + 0.04f * u);
                cv.drawPath(path, p);
                head(cv, cx - 0.16f * u, cy + 0.08f * u, 0f, 1f, 0.18f * u);
                return;
            }
            float deg;
            if ("left".equals(mod)) deg = -90f;
            else if ("right".equals(mod)) deg = 90f;
            else if ("slight left".equals(mod)) deg = -40f;
            else if ("slight right".equals(mod)) deg = 40f;
            else if ("sharp left".equals(mod)) deg = -140f;
            else if ("sharp right".equals(mod)) deg = 140f;
            else deg = 0f;
            double a = Math.toRadians(deg);
            float dx = (float) Math.sin(a), dy = (float) -Math.cos(a);
            float bx = cx, by = cy + 0.38f * u;
            float kx = cx, ky = deg == 0f ? cy : cy + 0.08f * u; // corner of the bend
            float len = deg == 0f ? 0.38f * u : 0.42f * u;
            float tx = kx + dx * len, ty = ky + dy * len;
            path.moveTo(bx, by);
            path.lineTo(kx, ky);
            path.lineTo(tx, ty);
            cv.drawPath(path, p);
            head(cv, tx, ty, dx, dy, 0.20f * u);
        }
    }

    /** Thin rounded progress line. */
    private static final class Bar extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();
        private final int fill;
        private float f = 0f;

        Bar(Context c, int fill) {
            super(c);
            this.fill = fill;
        }

        void set(float v) {
            v = Math.max(0f, Math.min(1f, v));
            if (Math.abs(v - f) < 0.001f) return;
            f = v;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight(), rad = h / 2f;
            p.setColor(0x40FFFFFF);
            r.set(0, 0, w, h);
            cv.drawRoundRect(r, rad, rad, p);
            if (f > 0f) {
                p.setColor(fill);
                r.set(0, 0, Math.max(h, w * f), h);
                cv.drawRoundRect(r, rad, rad, p);
            }
        }
    }
}
