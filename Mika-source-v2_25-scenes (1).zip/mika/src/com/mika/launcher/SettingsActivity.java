package com.mika.launcher;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Mika settings. Everything here is free - there are no locked or paid options. */
public class SettingsActivity extends Activity {

    private static final int REQ_WALLPAPER = 7;
    private static final int REQ_LOC = 8;
    private static final int REQ_ADHAN = 9;
    private static final int REQ_BT = 10;

    private Pal pal;
    private LinearLayout list;
    private ScrollView sv;

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) Ui.immersive(this);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.immersive(this);
        build();
    }

    @Override
    protected void onResume() {
        super.onResume();
        build();
    }

    private int dp(int v) {
        return Ui.dp(this, v);
    }

    // ------------------------------------------------------------- building
    private void build() {
        int scroll = sv == null ? 0 : sv.getScrollY();
        pal = Pal.of(this);
        sv = new ScrollView(this);
        sv.setBackgroundColor(pal.dark ? 0xFF0B0E17 : 0xFFEFF2FA);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(18), dp(18), dp(18), dp(40));
        sv.addView(list, new ScrollView.LayoutParams(-1, -2));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        View back = Ui.iconButton(this, Icons.BACK, 44, 22, pal.card, pal.text);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        top.addView(back);
        TextView title = Ui.text(this, "Mika settings", 24, pal.text);
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(-2, -2);
        tl.leftMargin = dp(14);
        top.addView(title, tl);
        list.addView(top);

        header("Appearance");
        action("Theme", Pal.THEMES[Pal.themeIndex(this)].name + "  \u00B7  " + Pal.THEMES.length + " themes",
                new Runnable() {
                    public void run() {
                        themeDialog("themeId", "Choose theme");
                    }
                });
        toggle("Switch theme automatically at night", "Use a different theme during the night hours set in Day & night", "autoTheme", false);
        if (Prefs.b(this, "autoTheme", false)) {
            action("Night theme", Pal.THEMES[Prefs.i(this, "nightTheme", 0) % Pal.THEMES.length].name,
                    new Runnable() {
                        public void run() {
                            themeDialog("nightTheme", "Choose night theme");
                        }
                    });
        }
        choice("Accent colour", Pal.ACCENT_NAMES, "accent", -1, Pal.ACCENT_VALUES);
        action("Wallpaper", Prefs.wallpaperFile(this).exists() ? "Custom wallpaper set" : "Using theme gradient",
                new Runnable() {
                    public void run() {
                        wallpaperMenu();
                    }
                });
        choice("Wallpaper dimming", new String[]{"None", "20%", "40%", "60%", "80%"}, "dim", 40,
                new int[]{0, 20, 40, 60, 80});
        toggle("24-hour clock", null, "h24", true);
        choice("App icon size", new String[]{"Small", "Medium", "Large", "Extra large"}, "iconSize", 56,
                new int[]{44, 56, 72, 88});
        choice("App grid columns", new String[]{"3", "4", "5", "6", "7", "8"}, "cols", 6,
                new int[]{3, 4, 5, 6, 7, 8});

        header("Home dashboard");
        toggle("Weather", "Current conditions and 3-day forecast", "showWeather", true);
        toggle("Now playing", "Track, album art and controls from any music app", "showMusic", true);
        toggle("Player background motion", "The Now playing screen background drifts slowly with soft glow and light, and fades between covers. Turn off to keep it still", "playerMotion", true);
        toggle("Speedometer", "GPS speed and compass heading", "showSpeed", true);
        toggle("Map", "Live mini map on the home screen", "showMap", true);
        toggle("Volume", "Media volume slider", "showVolume", true);
        toggle("Car page", "Swipe the home screen to a 3D view of your car that moves with your speed", "showCarPage", true);
        toggle("Frequent apps", "Shortcuts to the apps you open most", "showFrequent", true);

        header("Speed limit");
        choice("Speed limit sign", new String[]{"Off", "From the map only", "From the map, estimated by road type when missing (~)"}, "limitMode", 2, new int[]{0, 1, 2});
        choice("Alert when over the limit by", new String[]{"Any amount", "5 km/h", "10 km/h"}, "limitTol", 1, new int[]{0, 1, 2});
        toggle("Voice alert", "Says \"Speed limit 60\" once when you go over it", "limitVoice", true);
        choice("Estimate: motorways and highways", new String[]{"90 km/h", "100 km/h", "110 km/h", "120 km/h"}, "limHw", 100, new int[]{90, 100, 110, 120});
        choice("Estimate: main roads", new String[]{"60 km/h", "70 km/h", "80 km/h", "90 km/h"}, "limMain", 70, new int[]{60, 70, 80, 90});
        choice("Estimate: city streets", new String[]{"30 km/h", "40 km/h", "50 km/h", "60 km/h"}, "limCity", 50, new int[]{30, 40, 50, 60});

        header("Prayer times");
        toggle("Show the next prayer on the Car page", "Name, time and time left, from your last known location (no internet needed)", "prayerOn", true);
        choice("Calculation method", PrayerTimes.METHODS, "prayerMethod", 0, new int[]{0, 1, 2, 3, 4});
        choice("Asr", new String[]{"Standard (Shafi'i, Maliki, Hanbali)", "Hanafi"}, "prayerAsr", 0, new int[]{0, 1});
        choice("Prayer names", new String[]{"Arabic", "English"}, "prayerLang", 0, new int[]{0, 1});
        choice("Alert at prayer time", new String[]{"Off", "Notification", "Adhan audio file"}, "prayerAlert", 1, new int[]{0, 1, 2});
        choice("Reminder before the prayer", new String[]{"Off", "10 minutes", "15 minutes"}, "prayerBefore", 0, new int[]{0, 10, 15});
        String adhanName = Prefs.s(this, "adhanName", "");
        action("Adhan audio file", adhanName.length() > 0 ? adhanName : "Tap to choose an audio file (mp3, m4a...) from your phone", new Runnable() {
            @Override
            public void run() {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("audio/*")
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                startActivityForResult(i, REQ_ADHAN);
            }
        });
        action("Test the adhan", "Plays the chosen file now", new Runnable() {
            @Override
            public void run() {
                if (Prefs.s(SettingsActivity.this, "adhanUri", "").length() == 0) {
                    Toast.makeText(SettingsActivity.this, "Choose an audio file first", Toast.LENGTH_SHORT).show();
                    return;
                }
                try {
                    Intent s = new Intent(SettingsActivity.this, AdhanService.class).putExtra("title", "Adhan test");
                    if (Build.VERSION.SDK_INT >= 26) startForegroundService(s);
                    else startService(s);
                } catch (Exception e) {
                    Toast.makeText(SettingsActivity.this, "Couldn't play it", Toast.LENGTH_SHORT).show();
                }
            }
        });
        if (Build.VERSION.SDK_INT >= 31 && !((android.app.AlarmManager) getSystemService(Context.ALARM_SERVICE)).canScheduleExactAlarms()) {
            action("Allow exact alarms", "Without it the prayer alert can come a few minutes late", new Runnable() {
                @Override
                public void run() {
                    startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + getPackageName())));
                }
            });
        }

        header("Car Bluetooth");
        toggle("When the car connects", "Open Mika on the car page and carry on with the music", "btAuto", false);
        int nDev = Prefs.list(this, "btDevices").size();
        action("Car Bluetooth devices", nDev == 0 ? "Tap to choose your car (it must be paired first)" : nDev + " selected", new Runnable() {
            @Override
            public void run() {
                pickBtDevices();
            }
        });
        toggle("Open Mika on the car page", "Needs \"Display over other apps\", see below", "btOpen", true);
        toggle("Resume the music", "The last music app that played, or Mika's player from where it stopped", "btMusic", true);
        boolean overlay = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this);
        action("Display over other apps", overlay ? "Allowed" : "Needed so Android lets Mika open by itself when the car connects. Tap to allow", new Runnable() {
            @Override
            public void run() {
                if (Build.VERSION.SDK_INT >= 23) startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
            }
        });

        header("Day & night");
        choice("Car page sky", new String[]{"Automatic (follow the times below)", "Always day", "Always night"}, "skyMode", 0,
                new int[]{0, 1, 2});
        choice("Car lights", new String[]{"Automatic (at night)", "Always on", "Off"}, "carLights", 0, new int[]{0, 1, 2});
        choice("Navigation on the car page", new String[]{"Full (guidance card + route on the road)", "Compact (arrow and distance)", "Off"}, "carNav", 0, new int[]{0, 1, 2});
        toggle("Road sign before turns", "A green direction sign with an arrow slides along the road side as the next turn gets close (Car page slides)", "carSign", true);
        toggle("Side road at the turn", "A side road leaves the main road at the turn, with the trees and rail cleared, as the sign passes (needs Road sign before turns). Turn it off if it looks wrong or lags", "carBranch", true);
        toggle("Voice guidance", "Speaks each turn about 500 m, 200 m and right before it, and when you arrive or the route is recalculated. Music is lowered, not stopped", "navVoice", true);
        choice("Scene", new String[]{"Countryside", "Desert", "Town", "Seaside road", "Forest", "Tropical (palms)"}, "carScene", 0, new int[]{0, 1, 2, 3, 4, 5});
        choice("Roadside scenery", new String[]{"Full (trees, grass, rail, street lamps)", "Light (fewer trees)", "Off (plain road)"}, "carScenery", 0, new int[]{0, 1, 2});
        toggle("Smooth edges (anti-aliasing)", "Sharper car, trees and rail. Restart the app after changing it; turn it off if the car page stutters", "carAA", true);
        choice("Graphics quality (restart the app after changing)", new String[]{"Auto (recommended: High, steps down by itself if frames stutter)", "High", "Standard (the v2.20 look, lightest)"}, "carGfx", 0, new int[]{0, 1, 2});
        choice("Car frame rate", new String[]{"Auto (steady: starts at the best rate your screen can hold, steps down only if frames come late)", "30 fps", "45 fps", "60 fps", "Display maximum"}, "carFpsSet", 0, new int[]{0, 30, 45, 60, 120});
        choice("Side fade: car page and now playing (AMOLED)", new String[]{"Off", "Soft", "Wide"}, "carFade", 1, new int[]{0, 1, 2});
        toggle("Weather in the car page sky", "Clouds, rain, snow, fog and strong wind follow the real weather (tap the weather pill on the Car page to preview each one)", "carWxFx", true);
        action("Day starts at", SkyClock.fmt(this, SkyClock.dayStart(this)) + "  \u00B7  sky turns to day around this time",
                new Runnable() {
                    public void run() {
                        timeDialog("skyDayMin", "Day starts at", SkyClock.DEF_DAY_MIN);
                    }
                });
        action("Night starts at", SkyClock.fmt(this, SkyClock.nightStart(this)) + "  \u00B7  sky turns to night around this time",
                new Runnable() {
                    public void run() {
                        timeDialog("skyNightMin", "Night starts at", SkyClock.DEF_NIGHT_MIN);
                    }
                });

        header("Weather");
        action("City", Prefs.b(this, "wxManual", false) ? Prefs.s(this, "wxName", "") : "Using current location",
                new Runnable() {
                    public void run() {
                        citySearchDialog();
                    }
                });
        action("Use my current location", "Switch back to automatic location", new Runnable() {
            public void run() {
                Prefs.putB(SettingsActivity.this, "wxManual", false);
                Prefs.cache(SettingsActivity.this).edit().clear().apply();
                requestLocation();
                build();
            }
        });
        choice("Units", new String[]{"Celsius, km/h", "Fahrenheit, mph"}, "wxF", false, null);

        header("Speedometer");
        choice("Speed unit", new String[]{"km/h", "mph"}, "speedMph", false, null);

        header("Map");
        action("Mapbox access token", Prefs.s(this, "mapboxToken", "").length() > 0 ? "Set \u2013 using Mapbox maps, traffic and routing" : "Not set \u2013 using the free open-source map (tap to add your token)",
                new Runnable() {
                    public void run() {
                        tokenDialog();
                    }
                });
        choice("Map engine", new String[]{"Vector 3D", "Classic (OpenStreetMap)"}, "mapEngine", 0, new int[]{0, 1});
        toggle("Use Google Maps app when installed", "Otherwise the Map card opens Mika's own interactive map", "extMaps", false);

        header("Screen & mirroring");
        toggle("Fill the whole screen", "Draw behind the notch and rounded corners so a mirrored picture is complete", "fillScreen", true);
        choice("Screen edge padding", new String[]{"Default", "None", "8 dp", "16 dp", "24 dp", "32 dp", "48 dp"}, "edge", -1,
                new int[]{-1, 0, 8, 16, 24, 32, 48});

        header("Apps");
        choice("Sort app drawer", new String[]{"A to Z", "Most used", "Recently installed"}, "sort", 0,
                new int[]{0, 1, 2});
        toggle("Swipe up to open apps", "Swipe up anywhere on the home screen", "swipeUp", true);
        action("Hidden apps", Prefs.list(this, "hidden").size() + " hidden", new Runnable() {
            public void run() {
                hiddenAppsDialog();
            }
        });
        action("Clear dock", "Remove all pinned apps", new Runnable() {
            public void run() {
                Prefs.putS(SettingsActivity.this, "dock", "");
                Toast.makeText(SettingsActivity.this, "Dock cleared", Toast.LENGTH_SHORT).show();
            }
        });
        action("Reset usage statistics", "Clears the frequent apps list", new Runnable() {
            public void run() {
                Prefs.counts(SettingsActivity.this).edit().clear().apply();
                Toast.makeText(SettingsActivity.this, "Usage statistics reset", Toast.LENGTH_SHORT).show();
            }
        });

        header("System");
        action("Notification access (for Now playing)",
                MediaTracker.hasAccess(this) ? "Enabled" : "Not enabled \u2013 tap to enable",
                new Runnable() {
                    public void run() {
                        try {
                            startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
                        } catch (Exception e) {
                            Toast.makeText(SettingsActivity.this, "Open Settings \u203A Notification access",
                                    Toast.LENGTH_LONG).show();
                        }
                    }
                });
        action("Location permission", "Needed for speedometer and automatic weather", new Runnable() {
            public void run() {
                requestLocation();
            }
        });
        action("Set Mika as default home app", "Choose Mika when Android asks", new Runnable() {
            public void run() {
                try {
                    startActivity(new Intent(Settings.ACTION_HOME_SETTINGS));
                } catch (Exception e) {
                    startActivity(new Intent(Settings.ACTION_SETTINGS));
                }
            }
        });

        header("About");
        action("Mika 2.0", "Free launcher. No ads, no subscription, no locked features.", null);

        setContentView(sv);
        final int restore = scroll;
        sv.post(new Runnable() {
            public void run() {
                sv.scrollTo(0, restore);
            }
        });
    }

    // ---------------------------------------------------------- row helpers
    private void tokenDialog() {
        final EditText et = new EditText(this);
        et.setSingleLine(true);
        et.setHint("pk.eyJ1\u2026");
        et.setText(Prefs.s(this, "mapboxToken", ""));
        new AlertDialog.Builder(this)
                .setTitle("Mapbox access token")
                .setMessage("Paste your public token (starts with pk.) from account.mapbox.com. It enables Mapbox navigation styles, traffic, search and routing.")
                .setView(et)
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        Prefs.putS(SettingsActivity.this, "mapboxToken", et.getText().toString().trim());
                        build();
                    }
                })
                .setNeutralButton("Remove", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        Prefs.putS(SettingsActivity.this, "mapboxToken", "");
                        build();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void header(String s) {
        TextView t = Ui.text(this, s.toUpperCase(), 12, pal.accent);
        t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        t.setLetterSpacing(0.12f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.topMargin = dp(26);
        lp.bottomMargin = dp(8);
        list.addView(t, lp);
    }

    private LinearLayout row(String title, String sub) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setBackground(Ui.pill(this, pal.card, 16));
        r.setPadding(dp(16), dp(14), dp(16), dp(14));
        TextView t = Ui.text(this, title, 17, pal.text);
        r.addView(t);
        if (sub != null && sub.length() > 0) {
            TextView s = Ui.text(this, sub, 13, pal.sub);
            r.addView(s);
        }
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(6);
        list.addView(r, lp);
        return r;
    }

    private void action(String title, String sub, final Runnable run) {
        LinearLayout r = row(title, sub);
        if (run != null) {
            r.setClickable(true);
            r.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    run.run();
                }
            });
        }
    }

    private void toggle(String title, String sub, final String key, boolean def) {
        LinearLayout r = row(title, sub);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        // move text children into a vertical holder so the switch sits on the right
        LinearLayout holder = new LinearLayout(this);
        holder.setOrientation(LinearLayout.VERTICAL);
        while (r.getChildCount() > 0) {
            View c = r.getChildAt(0);
            r.removeViewAt(0);
            holder.addView(c);
        }
        r.addView(holder, new LinearLayout.LayoutParams(0, -2, 1f));
        final Switch sw = new Switch(this);
        sw.setChecked(Prefs.b(this, key, def));
        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean on) {
                Prefs.putB(SettingsActivity.this, key, on);
            }
        });
        r.addView(sw);
        r.setClickable(true);
        r.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sw.toggle();
            }
        });
    }

    /**
     * Choice row. For int prefs pass values[]; for boolean prefs pass values == null and a Boolean default
     * (option index 0 = false, 1 = true).
     */
    private void choice(final String title, final String[] opts, final String key, Object def, final int[] values) {
        int current = 0;
        if (values == null) {
            current = Prefs.b(this, key, (Boolean) def) ? 1 : 0;
        } else {
            int cur = Prefs.i(this, key, (Integer) def);
            for (int i = 0; i < values.length; i++) if (values[i] == cur) current = i;
        }
        final int sel = current;
        LinearLayout r = row(title, opts[current]);
        r.setClickable(true);
        r.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(SettingsActivity.this).setTitle(title)
                        .setSingleChoiceItems(opts, sel, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int which) {
                                if (values == null) Prefs.putB(SettingsActivity.this, key, which == 1);
                                else Prefs.putI(SettingsActivity.this, key, values[which]);
                                if (key.equals("wxF")) Prefs.cache(SettingsActivity.this).edit().clear().apply();
                                d.dismiss();
                                build();
                            }
                        }).show();
            }
        });
    }

    private void timeDialog(final String key, String title, int def) {
        int cur = Prefs.i(this, key, def);
        android.app.TimePickerDialog d = new android.app.TimePickerDialog(this, new android.app.TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(android.widget.TimePicker v, int h, int m) {
                Prefs.putI(SettingsActivity.this, key, h * 60 + m);
                build();
            }
        }, cur / 60, cur % 60, Prefs.b(this, "h24", true));
        d.setTitle(title);
        d.show();
    }

    // ---------------------------------------------------------------- themes
    private void themeDialog(final String key, String title) {
        final AlertDialog.Builder b = new AlertDialog.Builder(this).setTitle(title);
        ScrollView scroll = new ScrollView(this);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(10), dp(6), dp(10), dp(6));
        scroll.addView(col);
        b.setView(scroll);
        final AlertDialog dlg = b.create();
        int cur = key.equals("themeId") && !Prefs.p(this).contains(key) ? Pal.DEFAULT : Prefs.i(this, key, 0);
        LinearLayout row = null;
        for (int i = 0; i < Pal.THEMES.length; i++) {
            if (i % 2 == 0) {
                row = new LinearLayout(this);
                col.addView(row, new LinearLayout.LayoutParams(-1, -2));
            }
            final int idx = i;
            Pal.T t = Pal.THEMES[i];
            LinearLayout tile = new LinearLayout(this);
            tile.setOrientation(LinearLayout.VERTICAL);
            tile.setGravity(Gravity.CENTER);
            android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable(
                    android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                    new int[]{t.top, t.bottom});
            g.setCornerRadius(dp(14));
            if (i == cur) g.setStroke(dp(3), t.accent);
            else g.setStroke(dp(1), 0x33888888);
            tile.setBackground(g);
            tile.setPadding(dp(8), dp(14), dp(8), dp(12));
            View dot = new View(this);
            dot.setBackground(Ui.pill(this, t.accent, 20));
            tile.addView(dot, new LinearLayout.LayoutParams(dp(26), dp(26)));
            TextView n = Ui.text(this, t.name, 14, t.text);
            n.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams nl = new LinearLayout.LayoutParams(-2, -2);
            nl.topMargin = dp(8);
            tile.addView(n, nl);
            tile.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Prefs.putI(SettingsActivity.this, key, idx);
                    dlg.dismiss();
                    build();
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
            lp.setMargins(dp(5), dp(5), dp(5), dp(5));
            row.addView(tile, lp);
        }
        dlg.show();
    }

    // -------------------------------------------------------------- wallpaper
    private void wallpaperMenu() {
        String[] items = {"Choose from gallery", "Remove wallpaper"};
        new AlertDialog.Builder(this).setTitle("Wallpaper")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        if (which == 0) {
                            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                            i.setType("image/*");
                            startActivityForResult(Intent.createChooser(i, "Choose wallpaper"), REQ_WALLPAPER);
                        } else {
                            Prefs.wallpaperFile(SettingsActivity.this).delete();
                            Prefs.putI(SettingsActivity.this, "wp", 0);
                            build();
                        }
                    }
                }).show();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_ADHAN && res == RESULT_OK && data != null && data.getData() != null) {
            Uri u = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {
            }
            String nm = u.getLastPathSegment();
            try {
                android.database.Cursor cur = getContentResolver().query(u, new String[]{android.provider.OpenableColumns.DISPLAY_NAME}, null, null, null);
                if (cur != null) {
                    try {
                        if (cur.moveToFirst()) nm = cur.getString(0);
                    } finally {
                        cur.close();
                    }
                }
            } catch (Exception ignored) {
            }
            Prefs.putS(this, "adhanUri", u.toString());
            Prefs.putS(this, "adhanName", nm == null ? "Audio file" : nm);
            if (Prefs.i(this, "prayerAlert", 1) == 1) Prefs.putI(this, "prayerAlert", 2);
            build();
            return;
        }
        if (req != REQ_WALLPAPER || res != RESULT_OK || data == null || data.getData() == null) return;
        try {
            Uri uri = data.getData();
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            InputStream in = getContentResolver().openInputStream(uri);
            BitmapFactory.decodeStream(in, null, o);
            in.close();
            int sample = 1;
            while (o.outWidth / sample > 2400 || o.outHeight / sample > 2400) sample *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            in = getContentResolver().openInputStream(uri);
            Bitmap bmp = BitmapFactory.decodeStream(in, null, o2);
            in.close();
            if (bmp == null) throw new Exception("decode failed");
            FileOutputStream out = new FileOutputStream(Prefs.wallpaperFile(this));
            bmp.compress(Bitmap.CompressFormat.JPEG, 90, out);
            out.close();
            Prefs.putI(this, "wp", (int) (System.currentTimeMillis() / 1000));
            Toast.makeText(this, "Wallpaper set", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Couldn't use that image", Toast.LENGTH_SHORT).show();
        }
        build();
    }

    // ---------------------------------------------------------------- car Bluetooth
    private void pickBtDevices() {
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission("android.permission.BLUETOOTH_CONNECT") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.BLUETOOTH_CONNECT"}, REQ_BT);
            return;
        }
        final android.bluetooth.BluetoothAdapter ad = android.bluetooth.BluetoothAdapter.getDefaultAdapter();
        if (ad == null || !ad.isEnabled()) {
            Toast.makeText(this, "Turn Bluetooth on first", Toast.LENGTH_SHORT).show();
            return;
        }
        final List<String> addrs = new ArrayList<String>();
        List<String> names = new ArrayList<String>();
        final List<String> chosen = Prefs.list(this, "btDevices");
        try {
            for (android.bluetooth.BluetoothDevice d : ad.getBondedDevices()) {
                addrs.add(d.getAddress());
                String n = d.getName();
                names.add((n == null || n.length() == 0 ? "Unnamed" : n) + "  (" + d.getAddress() + ")");
            }
        } catch (SecurityException e) {
            Toast.makeText(this, "Bluetooth permission needed", Toast.LENGTH_SHORT).show();
            return;
        }
        if (addrs.isEmpty()) {
            Toast.makeText(this, "No paired devices: pair the car in Android's Bluetooth settings first", Toast.LENGTH_LONG).show();
            return;
        }
        final boolean[] on = new boolean[addrs.size()];
        for (int i = 0; i < on.length; i++) on[i] = chosen.contains(addrs.get(i));
        new AlertDialog.Builder(this).setTitle("Car Bluetooth devices")
                .setMultiChoiceItems(names.toArray(new String[0]), on, new DialogInterface.OnMultiChoiceClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which, boolean checked) {
                        on[which] = checked;
                    }
                })
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        StringBuilder sb = new StringBuilder();
                        for (int i = 0; i < on.length; i++) if (on[i]) sb.append(sb.length() > 0 ? "," : "").append(addrs.get(i));
                        Prefs.putS(SettingsActivity.this, "btDevices", sb.toString());
                        if (sb.length() > 0) Prefs.putB(SettingsActivity.this, "btAuto", true);
                        build();
                    }
                }).setNegativeButton("Cancel", null).show();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == REQ_BT && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) pickBtDevices();
    }

    // ---------------------------------------------------------------- weather
    private void requestLocation() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Location permission already granted", Toast.LENGTH_SHORT).show();
            } else {
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOC);
            }
        }
    }

    private void citySearchDialog() {
        final EditText et = new EditText(this);
        et.setHint("City name");
        et.setSingleLine(true);
        et.setInputType(InputType.TYPE_CLASS_TEXT);
        new AlertDialog.Builder(this).setTitle("Weather city").setView(et)
                .setPositiveButton("Search", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        searchCity(et.getText().toString().trim());
                    }
                }).setNegativeButton("Cancel", null).show();
    }

    private void searchCity(final String q) {
        if (q.length() == 0) return;
        Toast.makeText(this, "Searching\u2026", Toast.LENGTH_SHORT).show();
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    final List<WeatherClient.Place> res = WeatherClient.search(q);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            showCityResults(res);
                        }
                    });
                } catch (Exception e) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(SettingsActivity.this, "Search failed. Check your connection.",
                                    Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
        }).start();
    }

    private void showCityResults(final List<WeatherClient.Place> res) {
        if (res.isEmpty()) {
            Toast.makeText(this, "No cities found", Toast.LENGTH_SHORT).show();
            return;
        }
        String[] labels = new String[res.size()];
        for (int i = 0; i < labels.length; i++) labels[i] = res.get(i).label();
        new AlertDialog.Builder(this).setTitle("Choose city")
                .setItems(labels, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        WeatherClient.Place p = res.get(which);
                        Prefs.putS(SettingsActivity.this, "wxLat", String.valueOf(p.lat));
                        Prefs.putS(SettingsActivity.this, "wxLon", String.valueOf(p.lon));
                        Prefs.putS(SettingsActivity.this, "wxName", p.name);
                        Prefs.putB(SettingsActivity.this, "wxManual", true);
                        Prefs.cache(SettingsActivity.this).edit().clear().apply();
                        build();
                    }
                }).show();
    }

    // ------------------------------------------------------------ hidden apps
    private void hiddenAppsDialog() {
        final PackageManager pm = getPackageManager();
        Intent main = new Intent(Intent.ACTION_MAIN, null);
        main.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> ris = pm.queryIntentActivities(main, 0);
        final List<String[]> apps = new ArrayList<String[]>(); // {label, key}
        for (ResolveInfo ri : ris) {
            if (ri.activityInfo.packageName.equals(getPackageName())) continue;
            apps.add(new String[]{String.valueOf(ri.loadLabel(pm)),
                    ri.activityInfo.packageName + "/" + ri.activityInfo.name});
        }
        Collections.sort(apps, new Comparator<String[]>() {
            @Override
            public int compare(String[] a, String[] b) {
                return a[0].compareToIgnoreCase(b[0]);
            }
        });
        final List<String> hidden = Prefs.list(this, "hidden");
        String[] labels = new String[apps.size()];
        final boolean[] checked = new boolean[apps.size()];
        for (int i = 0; i < labels.length; i++) {
            labels[i] = apps.get(i)[0];
            checked[i] = hidden.contains(apps.get(i)[1]);
        }
        new AlertDialog.Builder(this).setTitle("Hide apps from the drawer")
                .setMultiChoiceItems(labels, checked, new DialogInterface.OnMultiChoiceClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which, boolean isChecked) {
                        checked[which] = isChecked;
                    }
                })
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        List<String> out = new ArrayList<String>();
                        for (int i = 0; i < checked.length; i++) if (checked[i]) out.add(apps.get(i)[1]);
                        Prefs.saveList(SettingsActivity.this, "hidden", out);
                        build();
                    }
                }).setNegativeButton("Cancel", null).show();
    }
}
