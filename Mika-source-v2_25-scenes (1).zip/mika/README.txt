Mika launcher 2.24 - source
Build: needs aapt (v1), JDK 17+, dalvik-exchange (dx), zipalign, apksigner and an android.jar (API 33).
  ANDROID_JAR=/path/to/android.jar ./build.sh
Output: build/Mika-Launcher.apk (debug-signed; create ~/.android/debug.keystore first, or edit build.sh).
Source layout: src/com/mika/launcher/*.java, res/, AndroidManifest.xml

v2.5 changes
- Map: vector 3D map (MapLibre GL JS bundled in assets/, tiles from OpenFreeMap / CARTO, no API key), pan/zoom/rotate/tilt,
  3D buildings, satellite layer, tap places of interest, search anywhere, in-app routing (OSRM demo server) with
  turn-by-turn banner and re-routing. Falls back to the classic raster map when WebGL/WebView isn't available.
  Settings > Map to pick the engine or use the Google Maps app.
- Mirroring: window now draws behind the notch/rounded corners (Settings > Screen & mirroring), optional edge padding.
- Player: works with any media app, always shows a cover (embedded, MediaStore thumbnail, folder.jpg, URI art,
  or a generated one) over a blurred full-screen background. Home widget uses the blurred cover as its background.

v2.6: drive-to-destination now also shows on the home-screen map card (route line, next turn, distance, ETA, end button).
  Shared route state in NavState.java; "Where to?" and Home/Work shortcuts search, pick the best match and start driving.

v2.7
- Fixed: Settings crashed on open (Map engine option used the wrong preference type).
- Home-screen map is now the same vector map as the Map screen (VectorMapView), with the drive-to route on it.
- Optional Mapbox: Settings > Map > Mapbox access token. With a token the map uses Mapbox GL JS (mapbox-gl 2.15, bundled),
  Mapbox navigation day/night styles with traffic, Mapbox Directions (driving-traffic) and Mapbox search.
  Without a token it uses MapLibre + OpenFreeMap / CARTO + OSRM.

v2.8 (routing)
- Free routing now uses Valhalla (valhalla1.openstreetmap.de) instead of the OSRM demo server; OSRM stays as an automatic fallback
  if the Valhalla server is unreachable. A Mapbox token still takes priority when set.

v2.9
- Icons: whole set redrawn in a modern rounded style (soft corners, thicker round pause bars, rounded play/prev/next,
  proper gear, outline home, etc). New icons: volume up/down, car, back, shuffle, repeat(1), replay/forward 10, star, compass, layers, slideshow.
  The emoji/text glyphs in Player, Media library, Video player, Photo viewer, Map and Settings were replaced with these vector icons.
- Volume card: new volume-down / volume-up buttons around the slider; the mute icon follows the volume.
- Home screen: new second slide with your 3D car (assets/car.glb = BAIC U5 Plus). Swipe left/right (or use the car button in the dock;
  swipes starting on the map keep panning the map, edge swipes always switch). The wheels spin, the road scrolls and the body settles with the
  GPS speed, and everything eases to a stop when the car stops. Settings > "Car page" turns the slide off.

v2.9.1 (car page: sky + soft edges + new car)
- Car widget edges are feathered into the home background (theme gradient or wallpaper): EdgeBlend.java. Car and road are untouched.
- Day / night sky in the 3D scene: blue sky with sun and clouds by day; stars and moon by night; orange dawn / dusk blend, road and car lighting follow.
- Settings > Day & night: Car page sky (Automatic / Always day / Always night), "Day starts at" and "Night starts at" (manual times).
  The "Switch theme automatically at night" option now uses the same times (SkyClock.java).
- assets/car.glb replaced with the low-poly "Hyper GT" (single mesh + colour-strip atlas). Glb.java has a new atlas path: bakes the texture to
  vertex colours, converts Y-up/Z-front to the app's model space, and splits the four wheels by geometry so they still spin.

v2.9.2
- Camera lowered / pulled back: the horizon sits about two thirds up, so the sky is a real part of the scene (it was a thin strip before and the road hid the sun and moon).
- Sky: horizon haze shared with the road, two layers of distant hills (town lights at night), sun / moon sit above the horizon, clouds by day, stars by night.
- Lights: head and tail lamps glow, soft light sprites, head-light beams and red tail glow on the road. Settings > Day & night > Car lights (Automatic / Always on / Off).
- Quick switch pill on the Car page (bottom right): tap to cycle Auto / Day / Night.

v2.10 (full-screen car page + weather)
- Car page is now full screen (no frame, no rounded rim). Its own HUD: speed, clock, Wi-Fi / battery and the page buttons (car, music, layouts, settings)
  at the top left; weather, Auto/Day/Night and Driving/Parked pills at the top right; one glass pill at the bottom with the apps button,
  your pinned dock apps and, when something is playing, cover + title + artist + progress + prev / play-pause / next (hidden when nothing plays).
- Weather in the sky (live Open-Meteo data, also when the home screen has no weather card): clouds that thicken with the cloud cover and grey out the sky,
  rain (light to heavy, slanted by the wind) with a wet darker road, snow flakes, fog / mist, thunderstorms with lightning flashes, strong wind
  (fast clouds, wind streaks, slanted rain and snow, the car body rocks a little). Head lights switch on by themselves in rain, storms and fog (Car lights = Automatic).
- Tap the weather pill on the Car page to preview Clear / Cloudy / Rain / Storm / Snow / Fog / Windy, and once more to go back to the live weather.
  Settings > Day & night > "Weather in the car page sky" turns the effects off.
- build.sh now signs with ./debug.keystore when it is next to it (so every build is signed with the same key and installs as an update).

v2.10.1: bottom pill sits lower (smaller margin / padding) and the whole 3D scene is lifted a little (CAR_LIFT in Car3DView) so the car clears the dock.

v2.11 (shared locations)
- Receive a location from Google Maps (Share > Mika Maps), WhatsApp / Telegram location messages (geo: links), tapped Google Maps links and
  google.navigation: intents: the map opens on the place with a pin and the usual Directions / Save / Clear card. Short links (maps.app.goo.gl,
  goo.gl/maps) are followed to find the coordinates; if that fails it falls back to a search by the place name.
- Paste anything into the map search box: a Maps link, "30.0444, 31.2357", degrees-minutes-seconds, Arabic digits - it goes straight to the map.
  "Where to?" on the home screen accepts the same and starts driving right away.
- New: MapLink.java (parser, pure Java). MapActivity is now exported + singleTop with intent filters in AndroidManifest.xml.

v2.12 (share-location fix)
- Short Google Maps links (maps.app.goo.gl/..., with or without ?g_st=...) now resolve reliably: LinkResolver.java tries several browser identities,
  follows HTTP redirects and redirects hidden inside the page, skips the cookie-consent wall and reads coordinates from the URL or the page.
- If a link only gives a place name, search uses name + address, with Nominatim then Photon as fallback.

v2.13
- Fixed: the pin landed next to the user instead of at the shared place. Page scans no longer use the map viewport centre
  (which Google centres on the viewer). Short links are read first as a link-preview page (map centred on the place itself).

v2.14 (car page: roadside scenery)
- New: Scenery.java builds low-poly trees (pines and round trees, a few autumn ones), bushes, guard rail with reflectors and street lamps on a 320 m ring
  that scrolls with the road speed (the vertex shader wraps every object by its own centre, so nothing tears). Trees sway in the wind and take snow;
  heights are capped so the sky, sun and moon stay open above the tree line. Anything that comes close to the camera dissolves instead of blocking the view.
- Ground: real grass beside the road (day / night / dusk / cloud / rain / snow colours, soft patchy noise that repeats seamlessly), a gravel shoulder and
  a little grain on the asphalt.
- Street lamps (far side, every 40 m): lit lens, halo sprites and warm light pools on the road and on nearby trees at night, in rain and in fog.
- Car shadow: soft rounded-box shadow pushed away from the sun, fainter in cloud and at night (the old dark blob under the car is lighter now).
- Smooth edges: 4x (then 2x) multisampled surface, automatic fallback to the plain one.
- Settings > Day & night: "Roadside scenery" (Full / Light / Off = the old plain road) and "Smooth edges (anti-aliasing)" (restart the app after changing).

v2.14.1: car page left / right edges fade smoothly to black (transparent on an AMOLED screen). Settings > Day & night > "Car page side fade (AMOLED)": Off / Soft / Wide.

v2.14.3: the first slide is back to normal (no side fade). The Now Playing page (PlayerActivity) gets the same smooth left / right fade to black as the car page (SideFade.java, same setting).

v2.14.4: on the Now Playing page the cover, texts and buttons are kept inside the un-faded middle (side padding = fade width, cover size follows the narrower area).

v2.15
- Car page: choose the car colour (black / grey / white / red) with the four swatches under the top-right pills. Saved in the "carPaint" setting.
- New third slide: rear view of the car with its tail lights, the road running away ahead of it, and the same sky, weather, scenery, speed, clock and music pill as the second slide.
  Brake lights come on when the car slows down. Both car slides share weather, sky mode and colour.
v2.15.1: smoother car slides - the neighbouring car slide keeps rendering while you swipe, so it no longer freezes or jumps as it slides in.
v2.15.2: less lag while driving - GL uniform/attribute lookups are cached (about 70 per frame before) and motion uses a smoothed frame step.
v2.15.3: wheels no longer drag fender paint / side markers along (only tyre, rim and brake spin); swipe between slides is lighter (only one 3D view renders at a time).
v2.15.4: wheel fix - wheels now spin around their real axle centre (the old pivot was ~13 cm too high, so the tyre wobbled through the body), correct spin speed, and only tyre, rim and hub cap rotate; arch liner / fender pieces stay with the body.

v2.16 (navigation on the car pages)
- While you drive to a destination, both car slides show a glass guidance card (top centre, under the pills): turn arrow, distance to the turn, street name,
  time + distance left and a thin trip-progress line. It swells once at 500 m and again at 200 m (the border and arrow take the accent colour), shows
  "You have arrived" for a few seconds at the end, and fades in / out by itself.
- The road gets a soft route ribbon in your lane ahead of the car with chevrons that scroll with the road (a few lines in the ground shader of Car3DView);
  asphalt, lane marks, scenery and the car are untouched, and the ribbon fades with the fog.
- Settings > Day & night > "Navigation on the car page": Full / Compact (arrow and distance only) / Off. Very narrow screens switch to compact on their own.
- NavState now also keeps the next maneuver type / modifier, street name and trip progress; MainActivity pushes them to CarPage (the rear slide follows the first one).

v2.17 (road sign + voice guidance)
- Car pages (both slides): when the next turn is close, a low-poly green direction sign (white border, white arrow on both faces, two posts) slides along the road side
  towards the car and passes it as you reach the turn. Right turns put it on the right-hand side, everything else on the far side. Arrows: right, left, straight (ramps / merges),
  slight right / left, roundabout, U-turn. The sign appears out of the haze about 100 scene metres ahead and is timed from the real distance and speed, so it passes the car
  roughly when the real turn arrives. It glows a little more when the car lights are on, takes fog, and does not appear for start / arrival / "continue".
  Mesh: Scenery.sign(kind); drawing and timing: Car3DView.updateSign / drawSign (uses the scenery shader with a new uGlow uniform). Settings > Day & night > "Road sign before turns".
- Voice guidance (NavVoice.java, Android TextToSpeech, English): "In 500 meters, turn right onto ...", again at about 200 m, then the plain instruction just before the turn;
  "Navigation started", "Recalculating" and "You have arrived". Works from the Map screen and the home / car pages (hooked into NavState). Plays on the navigation stream and
  ducks the music instead of stopping it. Settings > Day & night > "Voice guidance". AndroidManifest has a <queries> entry so the TTS engine is found on Android 11+.


v2.18 (side road at the turn)
- Car pages: for right / left turns and slight right / left, a side road now leaves the main road where the turn is (flared mouth, asphalt, thin white edge lines). It is drawn in the
  ground shader (uJ = junction x / side / fade, uJd = direction in GND_FS) and slides along with the sign; the sign stands 12 m before the junction. Slight turns lean forward.
- Trees, bushes, guard rail and lamps in its way shrink into the ground (scenery vertex shader, per-object centre z = new aCz attribute, Scenery.STRIDE is now 12);
  lamp halos of cleared lamps are skipped. Roundabouts, U-turns and straight / ramp signs get no side road.
- Settings > Day & night > "Side road at the turn" (on by default) turns it off if it looks wrong or lags; the sign and voice are independent of it.

v2.19 (speed limit)
- SpeedLimit.java: on every GPS fix (MainActivity.onSpeed) the road you are on is looked up in OpenStreetMap through the Overpass API (nearest drivable way within 25 m,
  its maxspeed tag; two public servers as fallback; at most one request per 120 m or 40 s while moving; last answer kept for 2 minutes). No API key.
  When the map has no limit, an estimate by road type can be shown instead, marked "~" (motorway/trunk, primary/secondary, everything else; defaults 100 / 70 / 50 km/h).
- Car page: round European-style sign next to the speed (mph when the unit is mph). While over the limit (tolerance 0 / 5 / 10 km/h) the speed and the sign turn red and a
  short voice alert "Speed limit 60" is spoken once (not again for 45 s, and never over a turn instruction; NavVoice.announce / busy).
- Settings > Speed limit: sign Off / map only / map + estimate, tolerance, voice alert, and the three estimate values.

v2.20 (prayer times + car Bluetooth)
- Prayer times (PrayerTimes.java): computed on the phone from the sun position, no internet. Position = last GPS fix / manual weather location (remembered in Prefs pLat / pLon).
  Methods: Egyptian General Authority (default), Muslim World League, Umm al-Qura, Karachi, ISNA; Asr standard or Hanafi. The Car pages show a pill under the status line:
  "Asr  14:47  ·  1h 05m" (Arabic or English names), lit in the accent colour during the last 15 minutes.
- Alerts (PrayerReceiver + AdhanService): one exact alarm for the next reminder / prayer (rescheduled after boot, time zone or clock change, app update and on every app start).
  Notification, or an adhan audio file chosen in Settings (played by a foreground service, pauses the music, stops by itself or from the notification, max 6 minutes);
  optional reminder 10 / 15 minutes before. No adhan recording is bundled: pick your own file. Exact-alarm permission row appears when Android 12+ has not granted it.
- Car Bluetooth (BtReceiver + CarLaunch): when a chosen paired device connects (ACL_CONNECTED), Mika opens on the first car page and the music carries on.
  Opening from the background needs "Display over other apps"; without it a full-screen / heads-up notification "Car connected - tap to open Mika" is posted instead.
  Music: another app's active media session if there is one, else Mika's player (PlayerService now remembers the last track and position: lastUri / lastPos), else a media-play key.
  MainActivity resumes the music itself 2.5 s after it is on screen (a service may only be started from the foreground); if the activity did not open, CarLaunch does it after 6 s.
- Settings > Prayer times and Settings > Car Bluetooth (choose devices, open on car page, resume music, display-over-apps shortcut).

v2.21 (graphics quality, no extra lag)
- New Settings > "Graphics quality": Auto (default) / High / Standard. High adds, on the car slides: a 24-bit depth buffer and a nearer clip plane at 1 m (far things and the sign / rail bases no longer flicker),
  sky / road reflections in the paint, a tight highlight and darker rocker panels and arches (CAR_FS), asphalt speckle close to the camera and patchy wear plus a sky sheen on wet road (GND_FS),
  tree volume (sky light from above, darker trunks / foliage near the ground, SCN_FS) and a third cloud layer with dithering that removes the banding in the sky gradient (SKY_FS).
  Standard keeps the v2.20 look. Changing it needs an app restart (the depth buffer is picked when the view is created).
- Auto watches the real frame interval while a car slide is on screen. If frames come late for a few seconds (more than 1.6 x the screen's normal interval, weighted over ~3 s, after the first 6 s),
  it drops to Standard on the spot (no flicker, just the extras switch off) for the rest of the session; if that happens in two sessions Auto starts at Standard from then on.
  Choosing any quality in Settings forgets that. High / Standard never change by themselves.
- Savings that pay for the extras (all tiers): the sky is only shaded above the horizon (the road covers the rest anyway; the cleared colour equals the haze colour, so the picture is identical),
  and the road shader skips its fine grain beyond ~38 m and the medium noise beyond ~90 m.
- Less shimmer while driving (all tiers): lane dashes and their edges soften with distance and the road grain fades out before it gets smaller than a pixel.


v2.22 (smooth High quality: no look changes, no features removed)
- GL context kept alive when the launcher is paused (setPreserveEGLContextOnPause): coming back to the home screen no longer recompiles every shader and rebuilds all meshes.
- All meshes (car, wheels, trees / rail / lamps, signs, road / sky / shadow quads) are uploaded once as vertex buffer objects. Before, the driver copied about 1 MB of scenery plus the
  whole car from client memory on every frame.
- Roadside scenery and all sign meshes are built once on a low-priority background thread (shared by both car slides) instead of on the GL thread; no per-frame allocations left in the glow code.
- Cheaper sine-free hash in the sky / rain / snow / wind shaders (same statistics, same look; star, cloud and snow patterns are just a different random layout).
- Frame pacing: the view asks the system for one steady frame rate (Surface.setFrameRate on Android 11+, plus its own wait when the rate divides the panel rate, e.g. 45 on 90 Hz).
  Auto starts at the best rate, steps down (90 -> 60 -> 45 -> 30) only when frames come late (about 15% late over ~3 s, after 4 s), and remembers where it settled (carFps).
  Auto now lowers the FRAME RATE first; it only drops the graphics tier to Standard when it is already at the lowest rate. High never loses quality.
  Settings > Day & night > "Car frame rate": Auto / 30 / 45 / 60 / Display maximum (a pinned rate is never changed by the governor). Choosing a graphics quality forgets the learned rate.

v2.23 (themes)
- New theme "AMOLED Cockpit" (21st, added at the end so saved theme numbers do not move): pure black background with the Cockpit magenta accent. ("AMOLED Black", pure black with a blue accent, was already there.)
- Light (day) themes: widgets are now white (Pal.surface): widget cards, the map card, the docks and the search / media bars. Buttons and small pills inside them keep the soft tint so they still show.

v2.24 (realistic trees + Now playing motion)
- Trees (Scenery.java): three species instead of two - pines with 5-7 drooping, scalloped tiers; round broadleaf trees with a flared trunk, tapering stem, two branches and a crown of 4-8
  overlapping foliage clumps; tall narrow poplars / cypresses. Foliage uses smooth per-vertex normals and per-vertex colour (lighter and yellower on top, darker underneath, speckle) so it reads as leaves
  and not as facets. Bushes are clusters of the same clumps. "Light" scenery keeps fewer clumps / tiers. About 2x the scenery triangles on Full (about 14k per side, was 6.6k); the meshes are still built once on a background thread.
- Trees (Car3DView shaders): leaves flutter on their own on top of the crown sway (more in wind), sunlight glows through the leaves from behind, and on High graphics quality a fine leaf speckle that stays on the tree.
- Now playing background (ArtBg.java, PlayerActivity.java): same blurred cover and scrim, now with very slow motion: Ken Burns zoom / drift, two soft glows in the cover's own colour on looping paths,
  a faint light sweep every ~16 s, and a cross-fade when the cover changes. Runs at ~30 fps and stops while the screen is not visible. The home music card stays static.
  Settings > Home dashboard > "Player background motion" turns it off.
  Smoothness: the Now playing background allocates nothing per frame (shaders built once per size, motion is canvas translate / scale only), uses no offscreen layers, runs ~30 fps,
  stops when hidden and stays still in battery-saver mode. The existing Car frame-rate / graphics governor still applies to the denser trees.

v2.25 (scenes)
- Settings > Day & night > "Scene": Countryside (as before), Desert (cacti, rocks, mesas, dry shrubs, sand), Town (shop fronts with awnings and lit windows at night, taller blocks behind, street trees),
  Seaside road (sea on the far side with foam line, sparkles and sky reflection, beach, palms, umbrellas, boats, lighthouse whose lamp glows at night), Forest (dense pines), Tropical (palms and bushes).
  Each scene also sets the ground colour and how high the distant hills are. Works with Roadside scenery Full / Light / Off.
- Light on purpose: scene meshes are built once on a background thread and uploaded once (the old scene stays until the new one is ready, so switching never freezes a frame);
  triangles per side on Full: desert ~4k, seaside ~4k, town ~6k, tropical ~8k, forest ~11k, countryside ~13k. Same shaders, no extra draw calls; the sea is a few lines in the ground shader and only runs in that scene.
  Windows use a new vertex kind (2) that lights up at night; Light level plants fewer objects in every scene.
