package com.mika.launcher;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import java.util.Calendar;
import java.util.Locale;
import java.util.TimeZone;

/**
 * Prayer times computed on the phone (no internet): sun position + the usual twilight angles of the chosen method.
 * Index order everywhere: 0 Fajr, 1 Sunrise, 2 Dhuhr, 3 Asr, 4 Maghrib, 5 Isha.
 * The position comes from the last GPS fix / manual weather location (remembered in Prefs so alarms work without a fix).
 */
final class PrayerTimes {
    private PrayerTimes() {
    }

    static final String[] AR = {"\u0627\u0644\u0641\u062C\u0631", "\u0627\u0644\u0634\u0631\u0648\u0642", "\u0627\u0644\u0638\u0647\u0631",
            "\u0627\u0644\u0639\u0635\u0631", "\u0627\u0644\u0645\u063A\u0631\u0628", "\u0627\u0644\u0639\u0634\u0627\u0621"};
    static final String[] EN = {"Fajr", "Sunrise", "Dhuhr", "Asr", "Maghrib", "Isha"};
    static final String[] METHODS = {"Egyptian General Authority of Survey", "Muslim World League", "Umm al-Qura (Makkah)",
            "University of Islamic Sciences, Karachi", "ISNA (North America)"};
    // Fajr angle, Isha angle (Isha 0 = fixed 90 minutes after Maghrib)
    private static final double[][] ANGLES = {{19.5, 17.5}, {18, 17}, {18.5, 0}, {18, 18}, {15, 15}};

    static final int ALARM_CODE = 7001;
    static final String ACTION_ALARM = "com.mika.launcher.PRAYER_ALARM";

    // ------------------------------------------------------------------ position
    static void remember(Context c, double lat, double lon) {
        if (Math.abs(lat - Double.parseDouble(Prefs.s(c, "pLat", "0"))) > 0.05 || Math.abs(lon - Double.parseDouble(Prefs.s(c, "pLon", "0"))) > 0.05) {
            Prefs.putS(c, "pLat", String.valueOf(lat));
            Prefs.putS(c, "pLon", String.valueOf(lon));
        }
    }

    /** {lat, lon} or null when no position has ever been seen. */
    static double[] coords(Context c) {
        try {
            if (Prefs.b(c, "wxManual", false)) {
                return new double[]{Double.parseDouble(Prefs.s(c, "wxLat", "0")), Double.parseDouble(Prefs.s(c, "wxLon", "0"))};
            }
            double la = Double.parseDouble(Prefs.s(c, "pLat", "0")), lo = Double.parseDouble(Prefs.s(c, "pLon", "0"));
            if (la == 0 && lo == 0) return null;
            return new double[]{la, lo};
        } catch (Exception e) {
            return null;
        }
    }

    // ------------------------------------------------------------------ astronomy
    private static double rad(double d) {
        return Math.toRadians(d);
    }

    private static double deg(double r) {
        return Math.toDegrees(r);
    }

    private static double fix(double a, double b) {
        a = a - b * Math.floor(a / b);
        return a < 0 ? a + b : a;
    }

    /** Times of the given calendar day in epoch milliseconds (index order above), or null near the poles. */
    static long[] compute(Context c, double lat, double lon, Calendar day) {
        return compute(Math.max(0, Math.min(4, Prefs.i(c, "prayerMethod", 0))), Prefs.i(c, "prayerAsr", 0) == 1 ? 2 : 1, lat, lon, day);
    }

    static long[] compute(int method, int asrFactor, double lat, double lon, Calendar day) {
        Calendar d = (Calendar) day.clone();
        d.set(Calendar.HOUR_OF_DAY, 12);
        d.set(Calendar.MINUTE, 0);
        d.set(Calendar.SECOND, 0);
        d.set(Calendar.MILLISECOND, 0);
        double tz = d.getTimeZone().getOffset(d.getTimeInMillis()) / 3600000.0;
        int y = d.get(Calendar.YEAR), m = d.get(Calendar.MONTH) + 1, dd = d.get(Calendar.DAY_OF_MONTH);
        if (m <= 2) {
            y--;
            m += 12;
        }
        double a = Math.floor(y / 100.0), b = 2 - a + Math.floor(a / 4);
        double jd = Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + dd + b - 1524.5 - lon / (15 * 24.0);
        double n = jd - 2451545.0;
        double g = fix(357.529 + 0.98560028 * n, 360), q = fix(280.459 + 0.98564736 * n, 360);
        double L = fix(q + 1.915 * Math.sin(rad(g)) + 0.020 * Math.sin(rad(2 * g)), 360);
        double e = 23.439 - 0.00000036 * n;
        double ra = fix(deg(Math.atan2(Math.cos(rad(e)) * Math.sin(rad(L)), Math.cos(rad(L)))) / 15, 24);
        double decl = deg(Math.asin(Math.sin(rad(e)) * Math.sin(rad(L))));
        double eqt = q / 15 - ra;
        if (eqt > 12) eqt -= 24;
        if (eqt < -12) eqt += 24;
        double noon = 12 + tz - lon / 15 - eqt;

        double sr = angleTime(lat, decl, 0.833);
        double fajr = angleTime(lat, decl, ANGLES[method][0]);
        double ishaT = ANGLES[method][1] == 0 ? 0 : angleTime(lat, decl, ANGLES[method][1]);
        double asrAng = -deg(Math.atan(1.0 / (asrFactor + Math.tan(rad(Math.abs(lat - decl))))));
        double asr = angleTime(lat, decl, asrAng);
        if (Double.isNaN(sr) || Double.isNaN(fajr) || Double.isNaN(asr) || (ANGLES[method][1] != 0 && Double.isNaN(ishaT))) return null;
        double sunrise = noon - sr, maghrib = noon + sr;
        double[] h = {noon - fajr, sunrise, noon, noon + asr, maghrib, ANGLES[method][1] == 0 ? maghrib + 1.5 : noon + ishaT};
        // the angle for Asr is a (negative) sun altitude: angleTime gives the hours between noon and that altitude
        long[] out = new long[6];
        Calendar base = (Calendar) day.clone();
        base.set(Calendar.HOUR_OF_DAY, 0);
        base.set(Calendar.MINUTE, 0);
        base.set(Calendar.SECOND, 0);
        base.set(Calendar.MILLISECOND, 0);
        for (int i = 0; i < 6; i++) {
            long mins = Math.round(h[i] * 60.0); // nearest minute
            Calendar t = (Calendar) base.clone();
            t.add(Calendar.MINUTE, (int) mins);
            out[i] = t.getTimeInMillis();
        }
        return out;
    }

    /** Hours between solar noon and the moment the sun is `angle` degrees below the horizon (negative angle = above it). */
    private static double angleTime(double lat, double decl, double angle) {
        double v = (-Math.sin(rad(angle)) - Math.sin(rad(decl)) * Math.sin(rad(lat))) / (Math.cos(rad(decl)) * Math.cos(rad(lat)));
        if (v < -1 || v > 1) return Double.NaN;
        return deg(Math.acos(v)) / 15.0;
    }

    // ------------------------------------------------------------------ next prayer
    /** The next of the five prayers (sunrise is skipped) after `now`: {index, time}. Null without a position. */
    static long[] next(Context c, long now) {
        double[] p = coords(c);
        if (p == null) return null;
        for (int add = 0; add < 3; add++) {
            Calendar day = Calendar.getInstance();
            day.setTimeInMillis(now);
            day.add(Calendar.DAY_OF_MONTH, add);
            long[] t = compute(c, p[0], p[1], day);
            if (t == null) return null;
            for (int i = 0; i < 6; i++) {
                if (i == 1) continue;
                if (t[i] > now) return new long[]{i, t[i]};
            }
        }
        return null;
    }

    static String name(Context c, int idx) {
        return Prefs.i(c, "prayerLang", 0) == 0 ? AR[idx] : EN[idx];
    }

    static String fmtTime(Context c, long t) {
        Calendar k = Calendar.getInstance();
        k.setTimeInMillis(t);
        int h = k.get(Calendar.HOUR_OF_DAY), mi = k.get(Calendar.MINUTE);
        if (Prefs.b(c, "h24", true)) return String.format(Locale.US, "%02d:%02d", h, mi);
        return String.format(Locale.US, "%d:%02d %s", h % 12 == 0 ? 12 : h % 12, mi, h < 12 ? "AM" : "PM");
    }

    static String fmtRemain(Context c, long ms) {
        long mins = Math.max(0, (ms + 59999) / 60000);
        boolean ar = Prefs.i(c, "prayerLang", 0) == 0;
        long h = mins / 60, m = mins % 60;
        if (ar) return h > 0 ? h + "\u0633 " + String.format(Locale.US, "%02d", m) + "\u062F" : m + "\u062F";
        return h > 0 ? h + "h " + String.format(Locale.US, "%02d", m) + "m" : m + "m";
    }

    // ------------------------------------------------------------------ alarms
    /** Sets one alarm for the next reminder / prayer. Safe to call as often as you like. */
    static void schedule(Context c) {
        try {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            PendingIntent pi = alarmIntent(c, -1, 0, 0);
            am.cancel(pi);
            if (Prefs.i(c, "prayerAlert", 1) == 0) return;
            long now = System.currentTimeMillis();
            long before = Prefs.i(c, "prayerBefore", 0) * 60000L;
            long best = Long.MAX_VALUE;
            int bi = -1, kind = 1;
            double[] p = coords(c);
            if (p == null) return;
            for (int add = 0; add < 2; add++) {
                Calendar day = Calendar.getInstance();
                day.add(Calendar.DAY_OF_MONTH, add);
                long[] t = compute(c, p[0], p[1], day);
                if (t == null) return;
                for (int i = 0; i < 6; i++) {
                    if (i == 1) continue;
                    if (before > 0 && t[i] - before > now + 1000 && t[i] - before < best) {
                        best = t[i] - before;
                        bi = i;
                        kind = 0;
                    }
                    if (t[i] > now + 1000 && t[i] < best) {
                        best = t[i];
                        bi = i;
                        kind = 1;
                    }
                }
            }
            if (bi < 0) return;
            PendingIntent fire = alarmIntent(c, bi, kind, best);
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, best, fire);
            } else if (Build.VERSION.SDK_INT >= 23) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, best, fire);
            } else {
                am.setExact(AlarmManager.RTC_WAKEUP, best, fire);
            }
        } catch (Exception ignored) {
        }
    }

    private static PendingIntent alarmIntent(Context c, int idx, int kind, long at) {
        Intent i = new Intent(c, PrayerReceiver.class).setAction(ACTION_ALARM);
        i.putExtra("idx", idx);
        i.putExtra("kind", kind);
        i.putExtra("at", at);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        return PendingIntent.getBroadcast(c, ALARM_CODE, i, flags);
    }
}
