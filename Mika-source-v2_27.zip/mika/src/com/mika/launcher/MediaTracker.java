package com.mika.launcher;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.graphics.Bitmap;
import android.media.AudioManager;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.KeyEvent;

import java.util.List;

/** Follows the currently active media session (any music/podcast/video app). */
class MediaTracker {
    interface Listener {
        void onMediaChanged();
    }

    private final Context ctx;
    private final Listener listener;
    private MediaSessionManager msm;
    private ComponentName cn;
    MediaController controller;
    String title = "";
    String artist = "";
    Bitmap art;
    boolean playing = false;
    long duration = 0;
    private long basePos = 0, baseTime = 0;
    private float speed = 1f;
    private boolean started = false;
    private String artUri = null;
    private final Handler main = new Handler(Looper.getMainLooper());

    private final MediaController.Callback cb = new MediaController.Callback() {
        @Override
        public void onPlaybackStateChanged(PlaybackState s) {
            readState(s);
            listener.onMediaChanged();
        }

        @Override
        public void onMetadataChanged(MediaMetadata m) {
            readMeta(m);
            listener.onMediaChanged();
        }

        @Override
        public void onSessionDestroyed() {
            refresh();
        }
    };

    private final MediaSessionManager.OnActiveSessionsChangedListener sessionsListener =
            new MediaSessionManager.OnActiveSessionsChangedListener() {
                @Override
                public void onActiveSessionsChanged(List<MediaController> list) {
                    pick(list);
                }
            };

    MediaTracker(Context c, Listener l) {
        ctx = c;
        listener = l;
    }

    static boolean hasAccess(Context c) {
        String flat = Settings.Secure.getString(c.getContentResolver(), "enabled_notification_listeners");
        return flat != null && flat.contains(c.getPackageName());
    }

    void start() {
        if (started) return;
        if (!hasAccess(ctx)) {
            listener.onMediaChanged();
            return;
        }
        try {
            msm = (MediaSessionManager) ctx.getSystemService(Context.MEDIA_SESSION_SERVICE);
            cn = new ComponentName(ctx, MediaListenerService.class);
            msm.addOnActiveSessionsChangedListener(sessionsListener, cn);
            started = true;
            refresh();
        } catch (SecurityException e) {
            started = false;
            listener.onMediaChanged();
        }
    }

    void stop() {
        if (started && msm != null) {
            try {
                msm.removeOnActiveSessionsChangedListener(sessionsListener);
            } catch (Exception ignored) {
            }
        }
        started = false;
        detach();
    }

    private void refresh() {
        try {
            pick(msm == null ? null : msm.getActiveSessions(cn));
        } catch (SecurityException e) {
            pick(null);
        }
    }

    private void detach() {
        if (controller != null) {
            try {
                controller.unregisterCallback(cb);
            } catch (Exception ignored) {
            }
        }
        controller = null;
    }

    private void pick(List<MediaController> list) {
        MediaController best = null;
        if (list != null) {
            for (MediaController mc : list) {
                PlaybackState s = mc.getPlaybackState();
                if (s != null && s.getState() == PlaybackState.STATE_PLAYING) {
                    best = mc;
                    break;
                }
            }
            if (best == null && !list.isEmpty()) best = list.get(0);
        }
        if (best != controller) {
            detach();
            controller = best;
            if (controller != null) controller.registerCallback(cb);
        }
        if (controller != null) {
            readMeta(controller.getMetadata());
            readState(controller.getPlaybackState());
        } else {
            title = "";
            artist = "";
            art = null;
            playing = false;
            duration = 0;
        }
        listener.onMediaChanged();
    }

    private void readMeta(MediaMetadata m) {
        if (m == null) {
            title = "";
            artist = "";
            art = null;
            duration = 0;
            return;
        }
        String t = m.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE);
        if (t == null) t = m.getString(MediaMetadata.METADATA_KEY_TITLE);
        title = t == null ? "" : t;
        String a = m.getString(MediaMetadata.METADATA_KEY_ARTIST);
        if (a == null) a = m.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST);
        if (a == null) a = m.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE);
        artist = a == null ? "" : a;
        Bitmap b = m.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART);
        if (b == null) b = m.getBitmap(MediaMetadata.METADATA_KEY_ART);
        if (b == null) b = m.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON);
        if (b != null) {
            art = b;
            artUri = null;
        } else {
            // Spotify, YouTube Music, etc. publish artwork as a URI instead of a bitmap
            String u = m.getString(MediaMetadata.METADATA_KEY_ALBUM_ART_URI);
            if (u == null) u = m.getString(MediaMetadata.METADATA_KEY_ART_URI);
            if (u == null) u = m.getString(MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI);
            if (u == null || u.length() == 0) {
                art = null;
                artUri = null;
            } else if (!u.equals(artUri)) {
                artUri = u;
                art = null;
                loadArtAsync(u);
            }
        }
        duration = m.getLong(MediaMetadata.METADATA_KEY_DURATION);
        if (duration < 0) duration = 0;
    }

    private void loadArtAsync(final String uri) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                final Bitmap bmp = Thumbs.decodeAny(ctx, uri, 900);
                if (bmp == null) return;
                main.post(new Runnable() {
                    @Override
                    public void run() {
                        if (uri.equals(artUri) && started) {
                            art = bmp;
                            listener.onMediaChanged();
                        }
                    }
                });
            }
        }).start();
    }

    private void readState(PlaybackState s) {
        if (s == null) {
            playing = false;
            return;
        }
        playing = s.getState() == PlaybackState.STATE_PLAYING;
        basePos = s.getPosition();
        baseTime = s.getLastPositionUpdateTime();
        speed = s.getPlaybackSpeed();
    }

    long position() {
        long p = basePos;
        if (playing) p += (long) ((SystemClock.elapsedRealtime() - baseTime) * speed);
        if (duration > 0 && p > duration) p = duration;
        return p < 0 ? 0 : p;
    }

    private void key(int code) {
        AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
        am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, code));
        am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, code));
    }

    void playPause() {
        if (controller != null) {
            if (playing) controller.getTransportControls().pause();
            else controller.getTransportControls().play();
        } else {
            key(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE);
        }
    }

    void next() {
        if (controller != null) controller.getTransportControls().skipToNext();
        else key(KeyEvent.KEYCODE_MEDIA_NEXT);
    }

    void prev() {
        if (controller != null) controller.getTransportControls().skipToPrevious();
        else key(KeyEvent.KEYCODE_MEDIA_PREVIOUS);
    }

    void seekTo(long ms) {
        if (controller != null) controller.getTransportControls().seekTo(ms);
    }

    /** Opens the app that owns the current media session. */
    boolean openApp(Activity a) {
        if (controller == null) return false;
        PendingIntent pi = controller.getSessionActivity();
        if (pi == null) return false;
        try {
            pi.send();
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
