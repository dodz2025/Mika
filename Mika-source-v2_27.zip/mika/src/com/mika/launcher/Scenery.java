package com.mika.launcher;

import java.util.Arrays;
import java.util.Random;

/**
 * Procedural low-poly roadside scenery for the car page: trees, bushes, guard rail and street lamps.
 * Everything lives on a ring of RING metres along the road; the vertex shader scrolls it with the
 * road speed and wraps each object by its own centre (aCx), so nothing tears at the seam.
 * Vertex layout (STRIDE floats): pos(3) normal(3) colour(4: rgb + kind) centreX(1) centreZ(1).
 * kind: 0 = solid, 0.5 = foliage (sways in the wind, takes snow), 1 = emissive lamp head.
 */
final class Scenery {
    static final int STRIDE = 12;
    static final float RING = 320f;
    static final float LAMP_STEP = 40f;
    static final float LAMP_Y = 5.0f, LAMP_Z = 4.9f; // lamp head height and distance from the road centre line (far side)

    float[] far = new float[0];   // z < 0: the side the camera looks across
    float[] near = new float[0];  // z > 0: only visible when the camera is far back (narrow screens)
    int farCount, nearCount;

    /** Scenes: 0 countryside, 1 desert, 2 town, 3 seaside, 4 forest, 5 tropical. */
    static final int SCENES = 6;

    /** level 0 = full, 1 = light. */
    static Scenery build(int level, int scene) {
        Scenery s = new Scenery();
        s.make(-1, level, 7771L + scene * 101L, scene);
        s.make(1, level, 3331L + scene * 101L, scene);
        return s;
    }

    // ------------------------------------------------------------------ builder
    private float[] a = new float[1 << 16];
    private int n = 0;
    private float cx, cz;             // centre x / z of the object being built (shader wraps by x; a side road clears objects by x and z)
    private float pcx, pcy, pcz;      // centre of the primitive: used to point flat normals outwards
    private boolean detail = true;    // full level: more crown blobs / pine tiers
    private float dens = 1f;          // spacing multiplier: Light level plants fewer objects

    private void make(int side, int level, long seed, int scene) {
        n = 0;
        Random r = new Random(seed);
        boolean full = level == 0;
        detail = full;
        dens = full ? 1f : 1.6f;
        // street lamps (far side only: they are the ones in view)
        if (side < 0) {
            for (int k = -4; k < 4; k++) lamp(k * LAMP_STEP);
        }
        // guard rail (towns have kerbs and shop fronts instead)
        if (scene != 2) {
            for (float x = -RING / 2; x < RING / 2; x += 8f) rail(x + 4f, side * 6.3f);
        }
        switch (scene) {
            case 1: desert(r, side); break;
            case 2: town(r, side); break;
            case 3: seaside(r, side); break;
            case 4: forest(r, side); break;
            case 5: tropical(r, side); break;
            default: countryside(r, side, full); break;
        }
        float[] out = Arrays.copyOf(a, n);
        if (side < 0) {
            far = out;
            farCount = n / STRIDE;
        } else {
            near = out;
            nearCount = n / STRIDE;
        }
    }

    /** Highest a tree may stand at this distance from the road so the sky band above the horizon stays open. */
    private static float cap(float az) {
        return 2.13f + 0.105f * (az + 4.9f) / 0.62f;
    }

    private static final int[] MIX_COUNTRY = {0, 0, 0, 1, 1, 1, 1, 1, 2, 2};

    private void countryside(Random r, int side, boolean full) {
        band(r, side, 9.5f, 15f, full ? 7f : 13f, full ? 11f : 19f, MIX_COUNTRY, 1f);
        if (full) {
            band(r, side, 17f, 34f, 9f, 14f, MIX_COUNTRY, 1f);
            bushes(r, side);
        }
    }

    /** Scatters objects along the road between two distances; types index into plant(). */
    private void band(Random r, int side, float z0, float z1, float step0, float step1, int[] types, float hMul) {
        float x = -RING / 2 + r.nextFloat() * step0;
        while (x < RING / 2 - 4f) {
            float m = ((x % LAMP_STEP) + LAMP_STEP) % LAMP_STEP;
            boolean nearLamp = m < 2.4f || m > LAMP_STEP - 2.4f;
            if (!(nearLamp && z0 < 12f)) {
                float az = z0 + r.nextFloat() * (z1 - z0);
                float h = cap(az) * hMul * (0.55f + 0.45f * r.nextFloat());
                cx = x;
                cz = side * az;
                plant(types[r.nextInt(types.length)], x, side * az, h, r);
            }
            x += step0 + r.nextFloat() * (step1 - step0);
        }
    }

    /** 0 pine, 1 round tree, 2 poplar, 3 palm, 4 cactus, 5 rock, 6 dry shrub, 7 mesa. */
    private void plant(int type, float x, float z, float h, Random r) {
        switch (type) {
            case 0: pine(x, z, h, r); break;
            case 1: round(x, z, h, r); break;
            case 2: poplar(x, z, h, r); break;
            case 3: palm(x, z, h, r); break;
            case 4: cactus(x, z, h, r); break;
            case 5: rock(x, z, h, r); break;
            case 6: dryShrub(x, z, h, r); break;
            default: mesa(x, z, h, r); break;
        }
    }

    private void bushes(Random r, int side) {
        for (float x = -RING / 2; x < RING / 2; x += 9f + r.nextFloat() * 9f) {
            float az = 7.4f + r.nextFloat() * 1.6f;
            float rad = 0.45f + r.nextFloat() * 0.45f;
            cx = x;
            cz = side * az;
            float[] c = pick(r, BUSH);
            int k = 2 + r.nextInt(2);
            for (int i = 0; i < k; i++) {
                float ox = (i - (k - 1) / 2f) * rad * 0.95f + (r.nextFloat() - 0.5f) * 0.2f * rad;
                float oz = (r.nextFloat() - 0.5f) * 0.7f * rad;
                float rr = rad * (0.75f + 0.35f * r.nextFloat());
                blob(x + ox, rr * 0.62f, side * az + oz, rr * 1.2f, rr * 0.85f, rr * 1.0f, 7, 3, shade(c, 0.9f + 0.2f * r.nextFloat()), 0.5f, r, 0.10f);
            }
        }
    }

    // ------------------------------------------------------------------ scenes
    private static final int[] MIX_DESERT_NEAR = {4, 4, 5, 6, 6, 5};
    private static final int[] MIX_DESERT_FAR = {5, 7, 4, 6};
    private static final int[] MIX_PALM = {3};
    private static final int[] MIX_FOREST_NEAR = {0, 0, 0, 1};
    private static final int[] MIX_FOREST_FAR = {0, 0, 0, 0, 1, 2};
    private static final int[] MIX_TROPIC_NEAR = {3, 3, 3, 6};
    private static final int[] MIX_TROPIC_FAR = {3, 3, 1, 1};
    private static final int[] MIX_COAST_LAND = {3, 3, 1};

    private void desert(Random r, int side) {
        band(r, side, 8.5f, 16f, 8f * dens, 16f * dens, MIX_DESERT_NEAR, 0.62f);
        band(r, side, 18f, 42f, 12f * dens, 24f * dens, MIX_DESERT_FAR, 0.9f);
    }

    private void forest(Random r, int side) {
        band(r, side, 8.6f, 15f, 8f * dens, 12.5f * dens, MIX_FOREST_NEAR, 1f);
        if (detail) {
            band(r, side, 16f, 36f, 11f, 17f, MIX_FOREST_FAR, 1f);
            bushes(r, side);
        }
    }

    private void tropical(Random r, int side) {
        band(r, side, 8.8f, 15f, 9f * dens, 15f * dens, MIX_TROPIC_NEAR, 1.5f);
        if (detail) {
            band(r, side, 17f, 34f, 12f, 20f, MIX_TROPIC_FAR, 1.3f);
            bushes(r, side);
        }
    }

    /** Sea on the far side (drawn by the ground shader from 15 m out): beach, palms, umbrellas, boats and a lighthouse. */
    private void seaside(Random r, int side) {
        if (side < 0) {
            band(r, side, 8.6f, 13.5f, 14f * dens, 26f * dens, MIX_PALM, 1.45f);
            for (float x = -RING / 2 + r.nextFloat() * 10f; x < RING / 2 - 6f; x += (18f + r.nextFloat() * 30f) * dens) {
                float az = 9f + r.nextFloat() * 4f;
                cx = x;
                cz = -az;
                umbrella(x, -az, r);
            }
            for (float x = -RING / 2 + r.nextFloat() * 10f; x < RING / 2 - 6f; x += (14f + r.nextFloat() * 24f) * dens) {
                float az = 13.2f + r.nextFloat() * 1.0f;
                cx = x;
                cz = -az;
                rock(x, -az, 0.7f + 0.7f * r.nextFloat(), r);
            }
            for (float x = -RING / 2 + r.nextFloat() * 40f; x < RING / 2 - 20f; x += (70f + r.nextFloat() * 70f) * dens) {
                float az = 24f + r.nextFloat() * 20f;
                cx = x;
                cz = -az;
                boat(x, -az, r);
            }
            cx = 50f;
            cz = -44f;
            lighthouse(50f, -44f, r);
        } else {
            band(r, side, 10f, 18f, 10f * dens, 20f * dens, MIX_COAST_LAND, 1.3f);
            if (detail) street(r, side, 24f, 8f, 4f, 7f, false);
        }
    }

    private static final float[][] WALL = {{0.80f, 0.74f, 0.64f}, {0.72f, 0.56f, 0.50f}, {0.62f, 0.67f, 0.72f}, {0.84f, 0.82f, 0.76f},
            {0.56f, 0.62f, 0.57f}, {0.86f, 0.78f, 0.58f}, {0.70f, 0.70f, 0.74f}};
    private static final float[][] AWN = {{0.78f, 0.20f, 0.18f}, {0.20f, 0.40f, 0.70f}, {0.88f, 0.62f, 0.16f}, {0.22f, 0.55f, 0.35f}};
    private static final float[][] ROCK = {{0.52f, 0.44f, 0.34f}, {0.46f, 0.43f, 0.40f}, {0.60f, 0.50f, 0.38f}};
    private static final float[][] MESA = {{0.66f, 0.40f, 0.26f}, {0.72f, 0.48f, 0.30f}, {0.58f, 0.36f, 0.25f}};
    private static final float[][] PALM = {{0.16f, 0.42f, 0.14f}, {0.22f, 0.50f, 0.16f}, {0.12f, 0.36f, 0.14f}};
    private static final float[][] SHRUB = {{0.46f, 0.42f, 0.22f}, {0.40f, 0.38f, 0.20f}, {0.52f, 0.44f, 0.24f}};

    /** Town: a row of shops (2-3 floors) 11 m from the road centre, taller blocks behind, small street trees between. */
    private void town(Random r, int side) {
        street(r, side, 11f, 8f, 4.5f, 8f, true);
        if (detail) street(r, side, 27f, 12f, 8f, 15f, false);
        boolean d = detail;
        detail = false;                                           // street trees stay cheap
        for (float x = -RING / 2 + r.nextFloat() * 8f; x < RING / 2 - 4f; x += (15f + r.nextFloat() * 8f) * dens) {
            float m = ((x % LAMP_STEP) + LAMP_STEP) % LAMP_STEP;
            if (m < 2.6f || m > LAMP_STEP - 2.6f) continue;
            cx = x;
            cz = side * 8.8f;
            round(x, side * 8.8f, 2.8f + 0.8f * r.nextFloat(), r);
        }
        detail = d;
    }

    private void street(Random r, int side, float face, float dep, float hMin, float hMax, boolean shops) {
        float x = -RING / 2 + r.nextFloat() * 3f;
        while (x < RING / 2 - 12f) {
            if (r.nextFloat() < 0.14f) {                          // gap: alley / empty lot
                x += 4f + r.nextFloat() * 5f;
                continue;
            }
            float w = 5.5f + r.nextFloat() * 5f;
            float hgt = hMin + r.nextFloat() * (hMax - hMin);
            float xc = x + w / 2f, zc = side * (face + dep / 2f);
            cx = xc;
            cz = zc;
            building(xc, zc, w, dep, hgt, side, r, shops);
            x += w + (r.nextFloat() < 0.35f ? 0.4f + r.nextFloat() * 1.2f : 0f);
        }
    }

    private void building(float xc, float zc, float w, float d, float hgt, int side, Random r, boolean shops) {
        float[] wall = pick(r, WALL);
        float x0 = xc - w / 2, x1 = xc + w / 2, z0 = zc - d / 2, z1 = zc + d / 2;
        box(x0, 0f, z0, x1, hgt, z1, wall, 0f);
        box(x0 - 0.15f, hgt, z0 - 0.15f, x1 + 0.15f, hgt + 0.35f, z1 + 0.15f, shade(wall, 0.62f), 0f);   // roof ledge
        float fz = side < 0 ? z1 : z0;                                                                  // facade facing the road
        float dirOut = side < 0 ? 1f : -1f;
        float y0 = shops ? 3.5f : 1.3f;
        int cols = Math.max(2, (int) (w / 1.9f));
        int floors = Math.max(1, (int) ((hgt - y0 + 0.4f) / 3.0f));
        float cw = w / cols;
        for (int f = 0; f < floors; f++) {
            for (int c = 0; c < cols; c++) {
                boolean lit = r.nextFloat() < 0.5f;
                float wx = x0 + cw * (c + 0.5f), wy = y0 + f * 3.0f;
                quadZ(wx - 0.45f, wy, wx + 0.45f, wy + 1.4f, fz + dirOut * 0.03f, dirOut, lit ? new float[]{0.22f, 0.30f, 0.40f} : new float[]{0.14f, 0.19f, 0.27f}, lit ? 2f : 0f);
            }
        }
        if (shops) {
            quadZ(x0 + 0.6f, 0.3f, x1 - 0.6f, 2.5f, fz + dirOut * 0.03f, dirOut, new float[]{0.20f, 0.28f, 0.38f}, r.nextFloat() < 0.75f ? 2f : 0f);
            float az0 = side < 0 ? fz : fz - 0.9f, az1 = side < 0 ? fz + 0.9f : fz;
            box(x0 + 0.4f, 2.7f, az0, x1 - 0.4f, 2.9f, az1, pick(r, AWN), 0f);                          // awning
        }
    }

    /** Flat quad in an xy plane at depth z, facing dir (+1 / -1 along z). */
    private void quadZ(float xa, float ya, float xb, float yb, float z, float dir, float[] c, float kind) {
        pcx = (xa + xb) / 2; pcy = (ya + yb) / 2; pcz = z - dir * 5f;
        tri(xa, ya, z, xb, ya, z, xb, yb, z, c, kind);
        tri(xa, ya, z, xb, yb, z, xa, yb, z, c, kind);
    }

    private void umbrella(float x, float z, Random r) {
        cyl(x, 0f, z, 0.04f, 0.04f, 2.3f, 5, new float[]{0.85f, 0.85f, 0.85f}, 0f);
        float[] c1 = pick(r, AWN), c2 = {0.95f, 0.95f, 0.92f};
        pcx = x; pcy = 2.0f; pcz = z;
        float rad = 1.05f;
        for (int i = 0; i < 8; i++) {
            double a0 = Math.PI * 2 * i / 8, a1 = Math.PI * 2 * (i + 1) / 8;
            tri(x, 2.55f, z, x + rad * (float) Math.cos(a1), 2.1f, z + rad * (float) Math.sin(a1),
                    x + rad * (float) Math.cos(a0), 2.1f, z + rad * (float) Math.sin(a0), i % 2 == 0 ? c1 : c2, 0f);
        }
    }

    private void boat(float x, float z, Random r) {
        float len = 2.6f + 2.2f * r.nextFloat();
        float[] hull = r.nextFloat() < 0.5f ? new float[]{0.92f, 0.92f, 0.94f} : new float[]{0.20f, 0.32f, 0.55f}, white = {0.95f, 0.95f, 0.95f};
        box(x - len / 2, -0.1f, z - 0.55f, x + len / 2, 0.55f, z + 0.55f, hull, 0f);
        box(x - len * 0.1f, 0.55f, z - 0.38f, x + len * 0.3f, 1.2f, z + 0.38f, white, 0f);
        cyl(x - len * 0.15f, 0.55f, z, 0.04f, 0.03f, 3.3f, 5, new float[]{0.7f, 0.7f, 0.7f}, 0f);
        pcx = x; pcy = 2f; pcz = z - 3f;
        tri(x - len * 0.15f - 0.05f, 0.9f, z, x - len * 0.15f - 0.05f, 3.7f, z, x - len * 0.15f - len * 0.5f, 0.9f, z, white, 0f);
    }

    private void lighthouse(float x, float z, Random r) {
        float[] white = {0.93f, 0.93f, 0.92f}, red = {0.78f, 0.16f, 0.14f};
        ball(x, -0.2f, z, 6f, 2.4f, 5f, 7, 3, ROCK[1], 0f, r, 0.2f);
        cyl(x, 1.4f, z, 1.15f, 0.85f, 4f, 8, white, 0f);
        cyl(x, 5.4f, z, 0.85f, 0.80f, 2.2f, 8, red, 0f);
        cyl(x, 7.6f, z, 0.80f, 0.68f, 3.6f, 8, white, 0f);
        box(x - 0.95f, 11.2f, z - 0.95f, x + 0.95f, 11.6f, z + 0.95f, new float[]{0.25f, 0.27f, 0.30f}, 0f);
        box(x - 0.5f, 11.6f, z - 0.5f, x + 0.5f, 12.8f, z + 0.5f, new float[]{1f, 0.9f, 0.6f}, 1f);      // lamp: glows at night
        cone(x, 12.8f, z, 0.85f, 1.3f, 8, red, 0f, 0f);
    }

    private void cactus(float x, float z, float h, Random r) {
        float s = h / 3f;
        float[] c = {0.16f + 0.08f * r.nextFloat(), 0.40f + 0.06f * r.nextFloat(), 0.22f};
        cyl(x, 0f, z, 0.26f * s, 0.22f * s, h * 0.92f, 6, c, 0f);
        cone(x, h * 0.90f, z, 0.22f * s, 0.35f * s, 6, c, 0f, 0f);
        int arms = 1 + r.nextInt(2);
        for (int k = 0; k < arms; k++) {
            float ang = r.nextFloat() * 6.28f, ax = (float) Math.cos(ang), az = (float) Math.sin(ang);
            float y1 = h * (0.30f + 0.25f * r.nextFloat()), reach = 0.75f * s, up = h * (0.20f + 0.20f * r.nextFloat());
            tube(x, y1, z, x + ax * reach, y1, z + az * reach, 0.15f * s, 0.14f * s, 5, c, 0f);
            tube(x + ax * reach, y1, z + az * reach, x + ax * reach, y1 + up, z + az * reach, 0.14f * s, 0.12f * s, 5, c, 0f);
            cone(x + ax * reach, y1 + up, z + az * reach, 0.12f * s, 0.22f * s, 5, c, 0f, 0f);
        }
    }

    private void rock(float x, float z, float h, Random r) {
        float rad = h * 0.6f;
        float[] c = pick(r, ROCK);
        ball(x, rad * 0.5f, z, rad * 1.2f, rad * 0.8f, rad, 6, 3, c, 0f, r, 0.22f);
        if (r.nextFloat() < 0.5f) ball(x + rad * 0.9f, rad * 0.28f, z + rad * 0.2f, rad * 0.6f, rad * 0.4f, rad * 0.5f, 6, 3, shade(c, 0.9f), 0f, r, 0.2f);
    }

    private void dryShrub(float x, float z, float h, Random r) {
        float s = Math.min(h, 2.2f) * 0.35f + 0.25f;
        float[] c = pick(r, SHRUB);
        blob(x, 0.35f * s, z, 0.75f * s, 0.48f * s, 0.75f * s, 6, 3, c, 0.5f, r, 0.15f);
        if (r.nextFloat() < 0.6f) blob(x + 0.6f * s, 0.25f * s, z + 0.2f * s, 0.5f * s, 0.34f * s, 0.5f * s, 6, 3, shade(c, 0.9f), 0.5f, r, 0.15f);
    }

    private void mesa(float x, float z, float h, Random r) {
        float[] c = pick(r, MESA);
        float w = h * (0.9f + 0.6f * r.nextFloat());
        cyl(x, 0f, z, w * 1.15f, w * 0.95f, h * 0.6f, 7, shade(c, 0.85f), 0f);
        cyl(x, h * 0.6f, z, w * 0.85f, w * 0.78f, h * 0.4f, 7, c, 0f);
    }

    /** Palm: a gently curved trunk and a crown of arching fronds that sway in the wind. */
    private void palm(float x, float z, float h, Random r) {
        float s = h / 6f;
        float lean = (r.nextFloat() - 0.5f) * 1.6f * s, la = r.nextFloat() * 6.28f;
        float lx = (float) Math.cos(la) * lean, lz = (float) Math.sin(la) * lean;
        float[] tr = {0.46f, 0.37f, 0.27f};
        float px = x, py = 0f, pz = z;
        for (int i = 0; i < 3; i++) {
            float t = (i + 1) / 3f;
            float nx = x + lx * t * t, ny = h * 0.88f * t, nz = z + lz * t * t;
            tube(px, py, pz, nx, ny, nz, (0.22f - 0.06f * i) * s, (0.22f - 0.06f * (i + 1)) * s, 6, shade(tr, 0.92f + 0.08f * i), 0f);
            px = nx; py = ny; pz = nz;
        }
        int fr = detail ? 9 : 6;
        float a0 = r.nextFloat() * 6.28f;
        for (int k = 0; k < fr; k++) {
            float ang = a0 + (float) (Math.PI * 2 * k / fr) + (r.nextFloat() - 0.5f) * 0.3f;
            float len = (1.7f + 0.6f * r.nextFloat()) * s * 1.2f, dx = (float) Math.cos(ang), dz = (float) Math.sin(ang);
            float[] c = shade(pick(r, PALM), 0.85f + 0.3f * r.nextFloat());
            float m1x = px + dx * len * 0.40f, m1y = py + 0.50f * s, m1z = pz + dz * len * 0.40f;
            float m2x = px + dx * len * 0.75f, m2y = py + 0.42f * s, m2z = pz + dz * len * 0.75f;
            float tx = px + dx * len, ty = py - 0.45f * s, tz = pz + dz * len;
            float w1x = -dz * 0.32f * s, w1z = dx * 0.32f * s, w2x = -dz * 0.24f * s, w2z = dx * 0.24f * s;
            pcx = px; pcy = py - 3f; pcz = pz;
            tri(px, py, pz, m1x + w1x, m1y, m1z + w1z, m1x - w1x, m1y, m1z - w1z, c, 0.5f);
            tri(m1x + w1x, m1y, m1z + w1z, m2x + w2x, m2y, m2z + w2z, m2x - w2x, m2y, m2z - w2z, c, 0.5f);
            tri(m1x + w1x, m1y, m1z + w1z, m2x - w2x, m2y, m2z - w2z, m1x - w1x, m1y, m1z - w1z, c, 0.5f);
            tri(m2x + w2x, m2y, m2z + w2z, tx, ty, tz, m2x - w2x, m2y, m2z - w2z, shade(c, 0.9f), 0.5f);
        }
    }

    // ------------------------------------------------------------------ objects
    private static final float[][] PINE = {{0.09f, 0.28f, 0.15f}, {0.11f, 0.33f, 0.17f}, {0.07f, 0.24f, 0.17f}};
    private static final float[][] ROUND = {{0.22f, 0.46f, 0.14f}, {0.30f, 0.52f, 0.16f}, {0.36f, 0.50f, 0.18f}, {0.18f, 0.40f, 0.16f}};
    private static final float[][] AUTUMN = {{0.66f, 0.38f, 0.10f}, {0.72f, 0.52f, 0.12f}, {0.58f, 0.24f, 0.10f}};
    private static final float[][] BUSH = {{0.16f, 0.38f, 0.14f}, {0.26f, 0.44f, 0.15f}, {0.20f, 0.34f, 0.18f}};
    private static final float[] TRUNK = {0.30f, 0.20f, 0.12f};

    private static float[] pick(Random r, float[][] set) {
        return set[r.nextInt(set.length)];
    }

    private void pine(float x, float z, float h, Random r) {
        float s = h / 5.3f;
        float[] c = pick(r, PINE);
        float lean = (r.nextFloat() - 0.5f) * 0.10f * s;
        cyl(x, 0f, z, 0.24f * s, 0.10f * s, 4.5f * s, 6, shade(TRUNK, 0.85f), 0f);
        int tiers = detail ? 6 : 4;
        for (int t = 0; t < tiers; t++) {
            float f = t / (float) (tiers - 1);                 // 0 bottom .. 1 top
            float y = (0.85f + f * 3.5f) * s;
            float rad = (1.80f - 1.42f * f) * s * (0.92f + 0.16f * r.nextFloat());
            float hh = (1.45f - 0.50f * f) * s;
            float k = 0.68f + 0.36f * f + (r.nextFloat() - 0.5f) * 0.06f;
            tier(x + lean * f * 4f, y, z, rad, hh, shade(c, k), r);
        }
    }

    /** One drooping tier of pine branches: a cone whose rim alternates in and out, with a dark underside. */
    private void tier(float x, float y, float z, float rad, float h, float[] c, Random r) {
        int sides = detail ? 8 : 6;
        pcx = x; pcy = y + h * 0.3f; pcz = z;
        float rot = r.nextFloat() * 6.2832f;
        float[] rx = new float[sides], ry = new float[sides], rz = new float[sides];
        for (int i = 0; i < sides; i++) {
            double a = Math.PI * 2 * i / sides + rot;
            float rr = rad * (0.74f + 0.26f * (i % 2) + (r.nextFloat() - 0.5f) * 0.16f);
            rx[i] = x + rr * (float) Math.cos(a);
            rz[i] = z + rr * (float) Math.sin(a);
            ry[i] = y - h * 0.07f * (i % 2);
        }
        float[] under = shade(c, 0.48f);
        for (int i = 0; i < sides; i++) {
            int j = (i + 1) % sides;
            tri(x, y + h, z, rx[j], ry[j], rz[j], rx[i], ry[i], rz[i], shade(c, 0.86f + 0.26f * ((i % 3) / 2f)), 0.5f);
            pcy = y - h;                                        // underside faces down
            tri(x, y + h * 0.05f, z, rx[i], ry[i], rz[i], rx[j], ry[j], rz[j], under, 0.5f);
            pcy = y + h * 0.3f;
        }
    }

    private void round(float x, float z, float h, Random r) {
        float s = h / 4.05f;
        float[] c = r.nextFloat() < 0.09f ? pick(r, AUTUMN) : pick(r, ROUND);
        float w = 0.85f + r.nextFloat() * 0.40f;               // crown width
        float lx = (r.nextFloat() - 0.5f) * 0.3f * s, lz = (r.nextFloat() - 0.5f) * 0.3f * s;
        // trunk: flared base, tapering stem, two branches reaching into the crown
        cyl(x, 0f, z, 0.30f * s, 0.19f * s, 0.45f * s, 7, TRUNK, 0f);
        tube(x, 0.40f * s, z, x + lx, 2.0f * s, z + lz, 0.19f * s, 0.11f * s, 6, TRUNK, 0f);
        float b1 = r.nextFloat() * 6.28f;
        tube(x + lx * 0.7f, 1.5f * s, z + lz * 0.7f, x + (float) Math.cos(b1) * 0.8f * s * w, 2.5f * s, z + (float) Math.sin(b1) * 0.8f * s * w, 0.08f * s, 0.04f * s, 5, shade(TRUNK, 1.1f), 0f);
        tube(x + lx * 0.8f, 1.7f * s, z + lz * 0.8f, x - (float) Math.cos(b1) * 0.7f * s * w, 2.7f * s, z - (float) Math.sin(b1) * 0.7f * s * w, 0.07f * s, 0.035f * s, 5, shade(TRUNK, 1.1f), 0f);
        // crown: dark inner mass, a big centre blob and a ring of smaller clumps with smooth shading
        blob(x + lx, 2.25f * s, z + lz, 0.95f * s * w, 0.75f * s, 0.95f * s * w, 6, 3, shade(c, 0.55f), 0.5f, r, 0.08f);
        blob(x + lx, 2.80f * s, z + lz, 1.15f * s * w, 1.05f * s, 1.15f * s * w, 7, 4, c, 0.5f, r, 0.14f);
        int n = detail ? 4 : 3;
        float a0 = r.nextFloat() * 6.28f;
        for (int k = 0; k < n; k++) {
            float ang = a0 + (float) (Math.PI * 2 * k / n) + (r.nextFloat() - 0.5f) * 0.7f;
            float rad = (0.52f + 0.30f * r.nextFloat()) * s * w;
            float by = (2.20f + 1.05f * r.nextFloat()) * s;
            float sz = (0.62f + 0.28f * r.nextFloat()) * s;
            blob(x + lx + (float) Math.cos(ang) * rad, by, z + lz + (float) Math.sin(ang) * rad,
                    sz * (0.9f + 0.2f * w), sz * 0.95f, sz * (0.9f + 0.2f * w), 7, 3, shade(c, 0.86f + 0.24f * r.nextFloat()), 0.5f, r, 0.16f);
        }
        if (detail) {   // a crown clump on top, so the outline is rounded instead of flat
            blob(x + lx + (r.nextFloat() - 0.5f) * 0.4f * s, 3.45f * s, z + lz + (r.nextFloat() - 0.5f) * 0.4f * s,
                    0.62f * s * w, 0.55f * s, 0.62f * s * w, 6, 3, shade(c, 1.05f), 0.5f, r, 0.14f);
        }
    }

    /** Tall narrow tree (poplar / cypress): a column of stacked blobs. */
    private void poplar(float x, float z, float h, Random r) {
        float s = h / 6.05f;
        float[] c = shade(pick(r, ROUND), 0.88f);
        cyl(x, 0f, z, 0.20f * s, 0.10f * s, 1.8f * s, 6, TRUNK, 0f);
        int n = detail ? 4 : 3;
        float step = detail ? 1.2f : 1.6f;
        for (int k = 0; k < n; k++) {
            float rad = (0.98f - 0.13f * k) * s;
            float ry = (detail ? 1.05f : 1.35f) * s;
            blob(x + (r.nextFloat() - 0.5f) * 0.12f * s, (1.5f + k * step) * s, z, rad, ry, rad, 7, 3, shade(c, 0.92f + 0.14f * r.nextFloat()), 0.5f, r, 0.13f);
        }
    }

    private void lamp(float x) {
        cx = x;
        float z = -(LAMP_Z + 2.4f);
        cz = z;
        float[] pole = {0.36f, 0.38f, 0.42f};
        cyl(x, 0f, z, 0.11f, 0.07f, LAMP_Y + 0.15f, 6, pole, 0f);
        box(x - 0.05f, LAMP_Y + 0.02f, z, x + 0.05f, LAMP_Y + 0.14f, -LAMP_Z + 0.2f, pole, 0f);   // arm
        box(x - 0.55f, LAMP_Y - 0.10f, -LAMP_Z - 0.18f, x + 0.55f, LAMP_Y + 0.05f, -LAMP_Z + 0.18f, new float[]{0.30f, 0.32f, 0.36f}, 0f); // housing
        box(x - 0.46f, LAMP_Y - 0.115f, -LAMP_Z - 0.13f, x + 0.46f, LAMP_Y - 0.095f, -LAMP_Z + 0.13f, new float[]{1f, 0.85f, 0.6f}, 1f);  // lit lens
    }

    private void rail(float x, float z) {
        cx = x;
        cz = z;
        float[] beam = {0.70f, 0.73f, 0.76f}, post = {0.40f, 0.42f, 0.46f};
        box(x - 4f, 0.46f, z - 0.03f, x + 4f, 0.84f, z + 0.03f, beam, 0f);
        for (int i = 0; i < 2; i++) {
            float px = x - 2f + i * 4f;
            box(px - 0.05f, 0f, z - 0.05f, px + 0.05f, 0.62f, z + 0.05f, post, 0f);
        }
        // little reflector on each post
        box(x - 2.04f, 0.50f, z + (z < 0 ? 0.04f : -0.04f), x - 1.96f, 0.58f, z + (z < 0 ? 0.05f : -0.05f), new float[]{0.95f, 0.55f, 0.10f}, 0f);
    }

    // ------------------------------------------------------------------ primitives
    private static float[] shade(float[] c, float k) {
        return new float[]{c[0] * k, c[1] * k, c[2] * k};
    }

    private void vert(float x, float y, float z, float nx, float ny, float nz, float[] c, float kind) {
        if (n + STRIDE > a.length) a = Arrays.copyOf(a, a.length * 2);
        a[n++] = x; a[n++] = y; a[n++] = z;
        a[n++] = nx; a[n++] = ny; a[n++] = nz;
        a[n++] = c[0]; a[n++] = c[1]; a[n++] = c[2]; a[n++] = kind;
        a[n++] = cx; a[n++] = cz;
    }

    private void tri(float ax, float ay, float az, float bx, float by, float bz, float qx, float qy, float qz, float[] c, float kind) {
        float ux = bx - ax, uy = by - ay, uz = bz - az, vx = qx - ax, vy = qy - ay, vz = qz - az;
        float nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
        float l = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
        if (l < 1e-9f) return;
        nx /= l; ny /= l; nz /= l;
        float mx = (ax + bx + qx) / 3f - pcx, my = (ay + by + qy) / 3f - pcy, mz = (az + bz + qz) / 3f - pcz;
        if (nx * mx + ny * my + nz * mz < 0) { nx = -nx; ny = -ny; nz = -nz; }
        vert(ax, ay, az, nx, ny, nz, c, kind);
        vert(bx, by, bz, nx, ny, nz, c, kind);
        vert(qx, qy, qz, nx, ny, nz, c, kind);
    }

    private void cone(float x, float y, float z, float rad, float h, int sides, float[] c, float kind, float rot) {
        pcx = x; pcy = y + h * 0.3f; pcz = z;
        for (int i = 0; i < sides; i++) {
            double a0 = Math.PI * 2 * i / sides + rot, a1 = Math.PI * 2 * (i + 1) / sides + rot;
            tri(x, y + h, z,
                    x + rad * (float) Math.cos(a1), y, z + rad * (float) Math.sin(a1),
                    x + rad * (float) Math.cos(a0), y, z + rad * (float) Math.sin(a0), c, kind);
        }
    }

    private void cyl(float x, float y, float z, float r0, float r1, float h, int sides, float[] c, float kind) {
        pcx = x; pcy = y + h / 2; pcz = z;
        for (int i = 0; i < sides; i++) {
            double a0 = Math.PI * 2 * i / sides, a1 = Math.PI * 2 * (i + 1) / sides;
            float x0b = x + r0 * (float) Math.cos(a0), z0b = z + r0 * (float) Math.sin(a0);
            float x1b = x + r0 * (float) Math.cos(a1), z1b = z + r0 * (float) Math.sin(a1);
            float x0t = x + r1 * (float) Math.cos(a0), z0t = z + r1 * (float) Math.sin(a0);
            float x1t = x + r1 * (float) Math.cos(a1), z1t = z + r1 * (float) Math.sin(a1);
            tri(x0b, y, z0b, x1b, y, z1b, x1t, y + h, z1t, c, kind);
            tri(x0b, y, z0b, x1t, y + h, z1t, x0t, y + h, z0t, c, kind);
        }
    }

    private void box(float x0, float y0, float z0, float x1, float y1, float z1, float[] c, float kind) {
        pcx = (x0 + x1) / 2; pcy = (y0 + y1) / 2; pcz = (z0 + z1) / 2;
        float[][] p = {{x0, y0, z0}, {x1, y0, z0}, {x1, y1, z0}, {x0, y1, z0}, {x0, y0, z1}, {x1, y0, z1}, {x1, y1, z1}, {x0, y1, z1}};
        int[][] f = {{0, 1, 2, 3}, {5, 4, 7, 6}, {4, 0, 3, 7}, {1, 5, 6, 2}, {3, 2, 6, 7}, {4, 5, 1, 0}};
        for (int[] q : f) {
            tri(p[q[0]][0], p[q[0]][1], p[q[0]][2], p[q[1]][0], p[q[1]][1], p[q[1]][2], p[q[2]][0], p[q[2]][1], p[q[2]][2], c, kind);
            tri(p[q[0]][0], p[q[0]][1], p[q[0]][2], p[q[2]][0], p[q[2]][1], p[q[2]][2], p[q[3]][0], p[q[3]][1], p[q[3]][2], c, kind);
        }
    }

    /** Tapered tube between two points (branches). */
    private void tube(float x0, float y0, float z0, float x1, float y1, float z1, float r0, float r1, int sides, float[] c, float kind) {
        float dx = x1 - x0, dy = y1 - y0, dz = z1 - z0;
        float l = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (l < 1e-6f) return;
        dx /= l; dy /= l; dz /= l;
        float ux = -dz, uy = 0f, uz = dx;                        // d x up
        float ul = (float) Math.sqrt(ux * ux + uz * uz);
        if (ul < 1e-4f) { ux = 1f; uz = 0f; ul = 1f; }
        ux /= ul; uz /= ul;
        float vx = dy * uz - dz * uy, vy = dz * ux - dx * uz, vz = dx * uy - dy * ux;
        pcx = (x0 + x1) / 2; pcy = (y0 + y1) / 2; pcz = (z0 + z1) / 2;
        for (int i = 0; i < sides; i++) {
            double a0 = Math.PI * 2 * i / sides, a1 = Math.PI * 2 * (i + 1) / sides;
            float c0 = (float) Math.cos(a0), s0 = (float) Math.sin(a0), c1 = (float) Math.cos(a1), s1 = (float) Math.sin(a1);
            float ax = x0 + (ux * c0 + vx * s0) * r0, ay = y0 + (uy * c0 + vy * s0) * r0, az = z0 + (uz * c0 + vz * s0) * r0;
            float bx = x0 + (ux * c1 + vx * s1) * r0, by = y0 + (uy * c1 + vy * s1) * r0, bz = z0 + (uz * c1 + vz * s1) * r0;
            float tx = x1 + (ux * c1 + vx * s1) * r1, ty = y1 + (uy * c1 + vy * s1) * r1, tz = z1 + (uz * c1 + vz * s1) * r1;
            float qx = x1 + (ux * c0 + vx * s0) * r1, qy = y1 + (uy * c0 + vy * s0) * r1, qz = z1 + (uz * c0 + vz * s0) * r1;
            tri(ax, ay, az, bx, by, bz, tx, ty, tz, c, kind);
            tri(ax, ay, az, tx, ty, tz, qx, qy, qz, c, kind);
        }
    }

    /**
     * Foliage clump: a lumpy ellipsoid with smooth (per-vertex) normals and per-vertex colour: lighter and a bit
     * yellower on top, darker underneath, with a little random speckle, so it reads as leaves, not as facets.
     */
    private void blob(float x, float y, float z, float rx, float ry, float rz, int sides, int rings, float[] c, float kind, Random r, float wob) {
        int rows = rings + 1;
        float[][] P = new float[rows * sides][], N = new float[rows * sides][], C = new float[rows * sides][];
        for (int j = 0; j <= rings; j++) {
            double phi = Math.PI * j / rings;
            float sp = (float) Math.sin(phi), cp = (float) Math.cos(phi);
            for (int i = 0; i < sides; i++) {
                double th = Math.PI * 2 * i / sides;
                float w = (j == 0 || j == rings) ? 1f : 1f + (r.nextFloat() - 0.5f) * 2f * wob;
                float ex = sp * (float) Math.cos(th), ez = sp * (float) Math.sin(th);
                int k = j * sides + i;
                P[k] = new float[]{x + rx * w * ex, y + ry * cp * (0.94f + 0.10f * (w - 1f)), z + rz * w * ez};
                float nx = ex / rx, ny = cp / ry + 0.18f / ry, nz = ez / rz;
                float nl = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
                N[k] = new float[]{nx / nl, ny / nl, nz / nl};
                float up = 0.5f + 0.5f * cp;
                float sh = 0.64f + 0.48f * up + (r.nextFloat() - 0.5f) * 0.12f;
                C[k] = new float[]{c[0] * sh + 0.05f * up, c[1] * sh + 0.035f * up, c[2] * sh};
            }
        }
        for (int j = 0; j < rings; j++) {
            for (int i = 0; i < sides; i++) {
                int i2 = (i + 1) % sides;
                int A = j * sides + i, B = j * sides + i2, Cc = (j + 1) * sides + i2, D = (j + 1) * sides + i;
                if (j == 0) {
                    sv(P, N, C, A, Cc, D, kind);
                } else if (j == rings - 1) {
                    sv(P, N, C, A, B, D, kind);
                } else {
                    sv(P, N, C, A, B, Cc, kind);
                    sv(P, N, C, A, Cc, D, kind);
                }
            }
        }
    }

    private void sv(float[][] P, float[][] N, float[][] C, int a, int b, int c, float kind) {
        int[] q = {a, b, c};
        for (int i : q) vert(P[i][0], P[i][1], P[i][2], N[i][0], N[i][1], N[i][2], C[i], kind);
    }

    /** Low-poly blob: a squashed sphere with a bit of random wobble and a darker underside. */
    private void ball(float x, float y, float z, float rx, float ry, float rz, int sides, int rings, float[] c, float kind, Random r, float wob) {
        pcx = x; pcy = y; pcz = z;
        float[][][] p = new float[rings + 1][sides][3];
        for (int j = 0; j <= rings; j++) {
            double phi = Math.PI * j / rings;
            for (int i = 0; i < sides; i++) {
                double th = Math.PI * 2 * i / sides;
                float w = (j == 0 || j == rings) ? 1f : 1f + (r.nextFloat() - 0.5f) * 2f * wob;
                p[j][i][0] = x + rx * w * (float) (Math.sin(phi) * Math.cos(th));
                p[j][i][1] = y + ry * (float) Math.cos(phi) * (0.92f + 0.16f * w * 0.5f);
                p[j][i][2] = z + rz * w * (float) (Math.sin(phi) * Math.sin(th));
            }
        }
        for (int j = 0; j < rings; j++) {
            float up = 1f - (j + 0.5f) / rings;            // 1 at the top, 0 at the bottom
            float[] col = shade(c, 0.74f + 0.30f * up);
            for (int i = 0; i < sides; i++) {
                int i2 = (i + 1) % sides;
                float[] A = p[j][i], B = p[j][i2], C = p[j + 1][i2], D = p[j + 1][i];
                if (j == 0) {
                    tri(A[0], A[1], A[2], C[0], C[1], C[2], D[0], D[1], D[2], col, kind);
                } else if (j == rings - 1) {
                    tri(A[0], A[1], A[2], B[0], B[1], B[2], D[0], D[1], D[2], col, kind);
                } else {
                    tri(A[0], A[1], A[2], B[0], B[1], B[2], C[0], C[1], C[2], col, kind);
                    tri(A[0], A[1], A[2], C[0], C[1], C[2], D[0], D[1], D[2], col, kind);
                }
            }
        }
    }

    // ------------------------------------------------------------------ guidance road sign
    /** Sign kinds: 0 right, 1 left, 2 straight, 3 slight right, 4 slight left, 5 roundabout, 6 U-turn. */
    static final int SIGN_KINDS = 7;
    private static final float SIGN_Z = 7.5f;   // distance of the sign centre from the road centre line (outside the guard rail)
    private static final float SIGN_CY = 3.45f; // height of the board centre

    /** +1 = right-hand side of the road (the camera side), -1 = far side. */
    static int signSide(int kind) {
        return kind == 0 || kind == 3 ? 1 : -1;
    }

    /**
     * Low-poly green direction sign on two posts, with a white border and a white arrow on both faces.
     * Built around x = 0 (aCx = 0), so the shader can slide it along the road with a single uniform.
     */
    static float[] sign(int kind) {
        Scenery s = new Scenery();
        s.cx = 0f;
        s.cz = signSide(kind) * SIGN_Z;
        float zc = signSide(kind) * SIGN_Z;
        float[] post = {0.52f, 0.54f, 0.58f}, white = {0.96f, 0.97f, 0.98f}, green = {0.05f, 0.44f, 0.25f};
        float hw = 1.75f, hh = 1.05f; // half width / half height of the board
        s.cyl(-0.0f, 0f, zc - 1.15f, 0.07f, 0.07f, SIGN_CY - hh + 0.25f, 6, post, 0f);
        s.cyl(-0.0f, 0f, zc + 1.15f, 0.07f, 0.07f, SIGN_CY - hh + 0.25f, 6, post, 0f);
        s.box(-0.06f, SIGN_CY - hh, zc - hw, 0.06f, SIGN_CY + hh, zc + hw, white, 0f);                  // white rim
        s.box(-0.09f, SIGN_CY - hh + 0.09f, zc - hw + 0.09f, 0.09f, SIGN_CY + hh - 0.09f, zc + hw - 0.09f, green, 0f); // green face
        s.arrow(kind, zc, -0.10f, -1, white);
        s.arrow(kind, zc, 0.10f, 1, white);
        return Arrays.copyOf(s.a, s.n);
    }

    private void arrow(int kind, float zc, float x, int dir, float[] c) {
        switch (kind) {
            case 0: bent(zc, x, dir, c, false); break;
            case 1: bent(zc, x, dir, c, true); break;
            case 2: straight(zc, x, dir, c, 0f); break;
            case 3: straight(zc, x, dir, c, 38f); break;
            case 4: straight(zc, x, dir, c, -38f); break;
            case 5: round(zc, x, dir, c); break;
            default: uturn(zc, x, dir, c); break;
        }
    }

    /** One flat polygon quad / triangle on the sign plane; (u, v) are right / up on the board. */
    private void flat(float x, int dir, float zc, float[] c, float... uv) {
        float mu = 0, mv = 0;
        int k = uv.length / 2;
        for (int i = 0; i < k; i++) {
            mu += uv[2 * i];
            mv += uv[2 * i + 1];
        }
        pcx = x - dir;
        pcy = SIGN_CY + mv / k;
        pcz = zc + mu / k;
        for (int i = 1; i + 1 < k; i++) {
            tri(x, SIGN_CY + uv[1], zc + uv[0], x, SIGN_CY + uv[2 * i + 1], zc + uv[2 * i],
                    x, SIGN_CY + uv[2 * i + 3], zc + uv[2 * i + 2], c, 0f);
        }
    }

    private static float[] rot(float u, float v, double deg) {
        double a = Math.toRadians(deg), co = Math.cos(a), si = Math.sin(a);
        return new float[]{(float) (u * co + v * si), (float) (-u * si + v * co)};
    }

    private void rect(float x, int dir, float zc, float[] c, float u0, float v0, float u1, float v1, double deg) {
        float[] a = rot(u0, v0, deg), b = rot(u1, v0, deg), d = rot(u1, v1, deg), e = rot(u0, v1, deg);
        flat(x, dir, zc, c, a[0], a[1], b[0], b[1], d[0], d[1], e[0], e[1]);
    }

    private void head(float x, int dir, float zc, float[] c, float u0, float v0, float u1, float v1, float u2, float v2, double deg) {
        float[] a = rot(u0, v0, deg), b = rot(u1, v1, deg), d = rot(u2, v2, deg);
        flat(x, dir, zc, c, a[0], a[1], b[0], b[1], d[0], d[1]);
    }

    private void straight(float zc, float x, int dir, float[] c, double deg) {
        rect(x, dir, zc, c, -0.15f, -0.72f, 0.15f, 0.22f, deg);
        head(x, dir, zc, c, -0.50f, 0.16f, 0.50f, 0.16f, 0f, 0.80f, deg);
    }

    /** Turn arrow: up the stem, then across to the right (or left when mirrored). */
    private void bent(float zc, float x, int dir, float[] c, boolean left) {
        float m = left ? -1f : 1f;
        float[][] r = {{-0.47f, -0.72f, -0.19f, 0.15f}, {-0.47f, -0.15f, 0.26f, 0.15f}};
        for (float[] q : r) {
            float u0 = q[0] * m, u1 = q[2] * m;
            flat(x, dir, zc, c, Math.min(u0, u1), q[1], Math.max(u0, u1), q[1], Math.max(u0, u1), q[3], Math.min(u0, u1), q[3]);
        }
        flat(x, dir, zc, c, 0.20f * m, 0.50f, 0.20f * m, -0.50f, 0.80f * m, 0f);
    }

    private void round(float zc, float x, int dir, float[] c) {
        int n = 14;
        float ro = 0.52f, ri = 0.30f, cy = -0.16f;
        for (int i = 0; i < n; i++) {
            double a0 = Math.PI * 2 * i / n, a1 = Math.PI * 2 * (i + 1) / n;
            flat(x, dir, zc, c,
                    (float) (ri * Math.cos(a0)), cy + (float) (ri * Math.sin(a0)),
                    (float) (ro * Math.cos(a0)), cy + (float) (ro * Math.sin(a0)),
                    (float) (ro * Math.cos(a1)), cy + (float) (ro * Math.sin(a1)),
                    (float) (ri * Math.cos(a1)), cy + (float) (ri * Math.sin(a1)));
        }
        flat(x, dir, zc, c, -0.10f, 0.30f, 0.10f, 0.30f, 0.10f, 0.50f, -0.10f, 0.50f);
        flat(x, dir, zc, c, -0.32f, 0.46f, 0.32f, 0.46f, 0f, 0.88f);
    }

    /** U-turn (to the left): up the right stem, over the top, down the left stem with the head pointing down. */
    private void uturn(float zc, float x, int dir, float[] c) {
        flat(x, dir, zc, c, 0.19f, -0.72f, 0.47f, -0.72f, 0.47f, 0.50f, 0.19f, 0.50f);
        flat(x, dir, zc, c, 0.19f, 0.22f, -0.43f, 0.22f, -0.43f, 0.50f, 0.19f, 0.50f);
        flat(x, dir, zc, c, -0.43f, 0.50f, -0.15f, 0.50f, -0.15f, -0.22f, -0.43f, -0.22f);
        flat(x, dir, zc, c, -0.60f, -0.18f, 0.02f, -0.18f, -0.29f, -0.62f);
    }
}
