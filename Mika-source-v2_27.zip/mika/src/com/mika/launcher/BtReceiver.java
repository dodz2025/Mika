package com.mika.launcher;

import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Bluetooth device connected: if it is one of the chosen car devices, open Mika on the car page and resume the music. */
public class BtReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        if (i == null || !BluetoothDevice.ACTION_ACL_CONNECTED.equals(i.getAction())) return;
        if (!Prefs.b(c, "btAuto", false)) return;
        BluetoothDevice d = i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
        if (d == null) return;
        String addr = d.getAddress();
        if (addr == null || !Prefs.list(c, "btDevices").contains(addr)) return;
        CarLaunch.onConnected(c.getApplicationContext(), goAsync());
    }
}
