package com.mika.launcher;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.view.View;

/**
 * Soft, feathered rim for the Car widget: paints the home screen's own background (theme gradient, or the
 * wallpaper + dimming) over the outer edge of the 3D view and fades it out towards the centre, so the sides of
 * the widget melt into the app background instead of ending in a hard line. The car and the road are untouched.
 */
final class EdgeBlend extends View {
    private static final int SCALE = 3; // mask is built at 1/3 resolution and scaled up with filtering (= soft blur)

    private final View rootRef;
    private final Bitmap wall;
    private final GradientDrawable grad;
    private final Paint wallPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Paint dimPaint = new Paint();
    private final Paint maskPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Matrix m = new Matrix();
    private final Rect dst = new Rect();
    private final int[] a = new int[2], r = new int[2];
    private final float fadeX, fadeY;
    private Bitmap mask;

    EdgeBlend(Context c, View root, Bitmap wallpaper, int dimAlpha, int bgTop, int bgBottom) {
        super(c);
        rootRef = root;
        wall = wallpaper;
        grad = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{bgTop, bgBottom});
        dimPaint.setColor(Color.argb(dimAlpha, 0, 0, 0));
        maskPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
        fadeX = Ui.dp(c, 44);
        fadeY = Ui.dp(c, 20);
        setClickable(false);
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (w <= 0 || h <= 0) {
            mask = null;
            return;
        }
        int sw = Math.max(2, w / SCALE), sh = Math.max(2, h / SCALE);
        float ex = Math.max(1f, fadeX / SCALE), ey = Math.max(1f, fadeY / SCALE);
        int[] px = new int[sw * sh];
        for (int y = 0; y < sh; y++) {
            float dy = Math.min(y + 0.5f, sh - y - 0.5f) / ey;
            float sy = smooth(dy);
            for (int x = 0; x < sw; x++) {
                float dx = Math.min(x + 0.5f, sw - x - 0.5f) / ex;
                float inside = smooth(dx) * sy;
                float al = 1f - inside;
                al = al * al * (3f - 2f * al); // extra-soft shoulder
                px[y * sw + x] = ((int) (al * 255f + 0.5f)) << 24;
            }
        }
        mask = Bitmap.createBitmap(px, sw, sh, Bitmap.Config.ARGB_8888);
    }

    private static float smooth(float t) {
        t = t < 0f ? 0f : (t > 1f ? 1f : t);
        return t * t * (3f - 2f * t);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (mask == null || rootRef == null) return;
        int w = getWidth(), h = getHeight();
        int rw = rootRef.getWidth(), rh = rootRef.getHeight();
        if (rw <= 0 || rh <= 0) return;
        getLocationOnScreen(a);
        rootRef.getLocationOnScreen(r);
        int layer = canvas.saveLayer(0, 0, w, h, null);
        canvas.save();
        canvas.translate(r[0] - a[0], r[1] - a[1]);
        grad.setBounds(0, 0, rw, rh);
        grad.draw(canvas);
        if (wall != null && wall.getWidth() > 0 && wall.getHeight() > 0) {
            float s = Math.max((float) rw / wall.getWidth(), (float) rh / wall.getHeight());
            m.reset();
            m.postScale(s, s);
            m.postTranslate((rw - wall.getWidth() * s) / 2f, (rh - wall.getHeight() * s) / 2f);
            canvas.drawBitmap(wall, m, wallPaint);
            canvas.drawRect(0, 0, rw, rh, dimPaint);
        }
        canvas.restore();
        dst.set(0, 0, w, h);
        canvas.drawBitmap(mask, null, dst, maskPaint);
        canvas.restoreToCount(layer);
    }
}
