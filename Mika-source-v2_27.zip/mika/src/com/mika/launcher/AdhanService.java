package com.mika.launcher;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;

/** Plays the adhan audio file chosen in Settings. Pauses the music while it plays; stops by itself or from the notification. */
public class AdhanService extends Service {
    private static final String CHANNEL = "mika_adhan";
    private static final String ACTION_STOP = "mika.ADHAN_STOP";
    private MediaPlayer mp;
    private AudioManager am;
    private AudioFocusRequest focusReq;
    private final Handler h = new Handler();
    private final Runnable cap = new Runnable() {
        @Override
        public void run() {
            stopSelf();
        }
    };

    @Override
    public int onStartCommand(Intent i, int flags, int startId) {
        if (i != null && ACTION_STOP.equals(i.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        String title = i != null && i.getStringExtra("title") != null ? i.getStringExtra("title") : "Prayer time";
        String text = i != null && i.getStringExtra("text") != null ? i.getStringExtra("text") : "";
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Adhan", NotificationManager.IMPORTANCE_LOW));
            b = new Notification.Builder(this, CHANNEL);
        } else {
            b = new Notification.Builder(this);
        }
        int pf = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        PendingIntent stop = PendingIntent.getService(this, 1, new Intent(this, AdhanService.class).setAction(ACTION_STOP), pf);
        b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(title).setContentText(text).setOngoing(true)
                .addAction(new Notification.Action.Builder(null, "Stop", stop).build());
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(7200, b.build(), android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
            else startForeground(7200, b.build());
        } catch (Exception e) {
            stopSelf();
            return START_NOT_STICKY;
        }
        play();
        return START_NOT_STICKY;
    }

    private void play() {
        try {
            am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            AudioAttributes attrs = new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build();
            if (Build.VERSION.SDK_INT >= 26) {
                focusReq = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT).setAudioAttributes(attrs).build();
                am.requestAudioFocus(focusReq);
            } else {
                am.requestAudioFocus(null, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT);
            }
            mp = new MediaPlayer();
            mp.setAudioAttributes(attrs);
            mp.setDataSource(this, Uri.parse(Prefs.s(this, "adhanUri", "")));
            mp.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer p) {
                    p.start();
                }
            });
            mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer p) {
                    stopSelf();
                }
            });
            mp.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                @Override
                public boolean onError(MediaPlayer p, int what, int extra) {
                    stopSelf();
                    return true;
                }
            });
            mp.prepareAsync();
            h.postDelayed(cap, 6 * 60000L); // safety: never play longer than 6 minutes
        } catch (Exception e) {
            stopSelf();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        h.removeCallbacks(cap);
        try {
            if (mp != null) mp.release();
        } catch (Exception ignored) {
        }
        try {
            if (am != null) {
                if (Build.VERSION.SDK_INT >= 26 && focusReq != null) am.abandonAudioFocusRequest(focusReq);
                else am.abandonAudioFocus(null);
            }
        } catch (Exception ignored) {
        }
        stopForeground(true);
    }

    @Override
    public IBinder onBind(Intent i) {
        return null;
    }
}
