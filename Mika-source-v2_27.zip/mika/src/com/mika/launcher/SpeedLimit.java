package com.mika.launcher;

import android.content.Context;
import android.location.Location;
import android.os.SystemClock;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Speed limit of the road you are on. Looked up from OpenStreetMap (Overpass API, free, no key): the nearest drivable way
 * within 25 m of the GPS fix and its maxspeed tag. When the map has no limit, an estimate by road type can be used instead
 * (marked with "~"; the three values are set in Settings > Speed limit). Shown as a round sign next to the speed on the Car page;
 * the speed turns red and a short voice alert is spoken when you go over it.
 */
final class SpeedLimit {
    private SpeedLimit() {
    }

    /** km/h, 0 = unknown. */
    static volatile int kmh = 0;
    static volatile boolean estimated = false;
    static volatile boolean over = false;

    private static volatile long stamp = 0;     // elapsedRealtime of the last answer
    private static double qLat, qLon;
    private static long qAt = 0;
    private static boolean busy = false;
    private static boolean alerted = false;
    private static long lastSpoken = 0;

    private static final String[] SERVERS = {
            "https://overpass-api.de/api/interpreter",
            "https://overpass.kumi.systems/api/interpreter"
    };

    static int mode(Context c) {
        return Prefs.i(c, "limitMode", 2); // 0 off, 1 map only, 2 map + estimate by road type
    }

    /** Call on every GPS fix: refreshes the lookup when needed and checks the speed against the limit. */
    static void update(final Context c, Location l) {
        if (l == null) return;
        if (mode(c) == 0) {
            kmh = 0;
            over = false;
            return;
        }
        long now = SystemClock.elapsedRealtime();
        if (kmh > 0 && now - stamp > 120000) kmh = 0; // no fresh answer for two minutes: don't show an old limit
        final double lat = l.getLatitude(), lon = l.getLongitude();
        double moved = qAt == 0 ? 1e9 : NavState.meters(qLat, qLon, lat, lon);
        boolean moving = l.hasSpeed() && l.getSpeed() > 2.5f;
        if (!busy && (qAt == 0 || (moving && (moved > 120 || now - qAt > 40000)))) {
            busy = true;
            qLat = lat;
            qLon = lon;
            qAt = now;
            final boolean est = mode(c) == 2;
            final int hw = Prefs.i(c, "limHw", 100), main = Prefs.i(c, "limMain", 70), city = Prefs.i(c, "limCity", 50);
            new Thread(new Runnable() {
                @Override
                public void run() {
                    int v = 0;
                    boolean e = false;
                    try {
                        String[] r = lookup(lat, lon);
                        if (r != null) {
                            v = parse(r[0]);
                            if (v == 0 && est) {
                                v = guess(r[1], hw, main, city);
                                e = v > 0;
                            }
                        } else if (kmh > 0 && SystemClock.elapsedRealtime() - stamp < 60000) {
                            busy = false;
                            return; // nothing drivable right here: keep the last limit for a minute
                        }
                        kmh = v;
                        estimated = e;
                        stamp = SystemClock.elapsedRealtime();
                    } catch (Exception ignored) {
                        // network trouble: try again later, keep what we have
                    }
                    busy = false;
                }
            }).start();
        }
        check(c, l);
    }

    private static void check(Context c, Location l) {
        int lim = kmh;
        float v = l.hasSpeed() ? l.getSpeed() * 3.6f : 0f;
        int tol = new int[]{0, 5, 10}[Math.max(0, Math.min(2, Prefs.i(c, "limitTol", 1)))];
        boolean o = lim > 0 && v > lim + tol;
        over = o;
        long now = SystemClock.elapsedRealtime();
        if (o && !alerted && now - lastSpoken > 45000 && Prefs.b(c, "limitVoice", true) && !NavVoice.busy()) {
            alerted = true;
            lastSpoken = now;
            boolean mph = Prefs.b(c, "speedMph", false);
            NavVoice.announce(c, "Speed limit " + (mph ? Math.round(lim / 1.609) : lim));
        } else if (!o && lim > 0 && v < lim - 1) {
            alerted = false;
        }
    }

    // ------------------------------------------------------------------ lookup
    /** {maxspeed tag or "", highway tag} of the nearest drivable way, or null. */
    private static String[] lookup(double lat, double lon) throws Exception {
        String q = String.format(Locale.US, "[out:json][timeout:8];way(around:25,%f,%f)[highway];out tags geom;", lat, lon);
        Exception last = null;
        for (String server : SERVERS) {
            try {
                return pick(post(server, q), lat, lon);
            } catch (Exception e) {
                last = e;
            }
        }
        throw last;
    }

    private static String post(String server, String q) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(server).openConnection();
        c.setConnectTimeout(6000);
        c.setReadTimeout(9000);
        c.setRequestMethod("POST");
        c.setDoOutput(true);
        c.setRequestProperty("User-Agent", "MikaLauncher/2.19");
        c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
        OutputStream os = c.getOutputStream();
        os.write(("data=" + URLEncoder.encode(q, "UTF-8")).getBytes("UTF-8"));
        os.close();
        if (c.getResponseCode() != 200) throw new Exception("HTTP " + c.getResponseCode());
        BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close();
        return sb.toString();
    }

    private static boolean drivable(String hw) {
        return !(hw.equals("footway") || hw.equals("path") || hw.equals("cycleway") || hw.equals("steps") || hw.equals("pedestrian")
                || hw.equals("bridleway") || hw.equals("track") || hw.equals("corridor") || hw.equals("service")
                || hw.equals("construction") || hw.equals("proposed") || hw.equals("platform") || hw.equals("busway"));
    }

    private static String[] pick(String json, double lat, double lon) throws Exception {
        JSONArray els = new JSONObject(json).getJSONArray("elements");
        double best = 1e9;
        String[] out = null;
        double kx = 111320.0 * Math.cos(Math.toRadians(lat)), ky = 110540.0;
        for (int i = 0; i < els.length(); i++) {
            JSONObject w = els.getJSONObject(i);
            JSONObject tags = w.optJSONObject("tags");
            JSONArray g = w.optJSONArray("geometry");
            if (tags == null || g == null || g.length() < 2) continue;
            String hw = tags.optString("highway", "");
            if (!drivable(hw)) continue;
            double d = 1e9;
            for (int k = 0; k + 1 < g.length(); k++) {
                JSONObject a = g.getJSONObject(k), b = g.getJSONObject(k + 1);
                d = Math.min(d, segDist((a.getDouble("lon") - lon) * kx, (a.getDouble("lat") - lat) * ky,
                        (b.getDouble("lon") - lon) * kx, (b.getDouble("lat") - lat) * ky));
            }
            if (d < best) {
                best = d;
                String ms = tags.optString("maxspeed", "");
                if (ms.length() == 0) ms = tags.optString("maxspeed:forward", "");
                out = new String[]{ms, hw};
            }
        }
        return out;
    }

    /** Distance from the origin to the segment (ax, ay)-(bx, by), metres. */
    private static double segDist(double ax, double ay, double bx, double by) {
        double dx = bx - ax, dy = by - ay, l2 = dx * dx + dy * dy;
        double t = l2 == 0 ? 0 : Math.max(0, Math.min(1, -(ax * dx + ay * dy) / l2));
        double px = ax + t * dx, py = ay + t * dy;
        return Math.sqrt(px * px + py * py);
    }

    /** "60", "50 mph", "60;80" -> km/h; 0 when there is no usable number ("none", "walk", "EG:urban"...). */
    static int parse(String s) {
        if (s == null) return 0;
        s = s.trim().toLowerCase(Locale.US);
        Matcher m = Pattern.compile("(\\d+)").matcher(s);
        if (!m.find()) return 0;
        int v = Integer.parseInt(m.group(1));
        if (s.contains("mph")) v = (int) Math.round(v * 1.609);
        return v < 5 || v > 200 ? 0 : v;
    }

    private static int guess(String hw, int motorway, int main, int city) {
        if (hw.startsWith("motorway") || hw.startsWith("trunk")) return motorway;
        if (hw.startsWith("primary") || hw.startsWith("secondary")) return main;
        return city;
    }
}
