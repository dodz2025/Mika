package com.mika.launcher;

import android.content.Context;
import android.location.Location;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.os.Build;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

/**
 * Spoken turn-by-turn guidance (Android TextToSpeech). Announces each maneuver three times as it gets close
 * (about 500 m, 200 m, then right before it), plus "Navigation started", "Recalculating" and arrival.
 * Plays on the navigation-guidance stream and briefly lowers the music instead of stopping it.
 * Settings > Day & night > "Voice guidance" turns it off.
 */
final class NavVoice {
    private NavVoice() {
    }

    private static TextToSpeech tts;
    private static boolean ready = false, failed = false;
    private static final List<String> pending = new ArrayList<String>();
    private static AudioManager am;
    private static AudioFocusRequest focusReq;
    private static int stepKey = -1, level = 0;
    private static int speaking = 0;

    // ---------------------------------------------------------------- public
    static boolean enabled(Context c) {
        return Prefs.b(c, "navVoice", true);
    }

    /** Called after every NavState.update(): speaks the next maneuver at 500 m, 200 m and just before it. */
    static void tick(Context c, Location l) {
        if (c == null || !enabled(c) || !NavState.active || NavState.nextText.length() == 0) return;
        if (!isManeuver(NavState.nextType)) return;
        int key = NavState.idx;
        if (key != stepKey) {
            stepKey = key;
            level = 0;
        }
        double speed = l != null && l.hasSpeed() ? l.getSpeed() : 0; // m/s
        double d = NavState.nextDist;
        double near = Math.max(60.0, Math.min(140.0, speed * 4.5)); // about 4 s ahead at the current speed
        int want = d <= near ? 3 : d <= 220 ? 2 : d <= 520 ? 1 : 0;
        if (want <= level) return;
        level = want;
        String t = NavState.nextText;
        if (t.length() > 0) t = Character.toLowerCase(t.charAt(0)) + t.substring(1);
        if (want == 3) say(c, cap(t));
        else say(c, "In " + spokenDist(c, d) + ", " + t);
    }

    /** Any short spoken message (speed-limit alert). */
    static void announce(Context c, String text) {
        say(c, text);
    }

    /** True while a message is being spoken, so other alerts don't cut a turn instruction short. */
    static boolean busy() {
        return speaking > 0;
    }

    static void started(Context c) {
        stepKey = -1;
        level = 0;
        if (enabled(c)) say(c, "Navigation started");
    }

    static void rerouting(Context c) {
        if (enabled(c)) say(c, "Recalculating");
    }

    static void arrived(Context c) {
        stepKey = -1;
        level = 0;
        if (enabled(c)) say(c, "You have arrived");
    }

    static void stop() {
        stepKey = -1;
        level = 0;
    }

    // ---------------------------------------------------------------- helpers
    static boolean isManeuver(String type) {
        if (type == null) return false;
        return "turn".equals(type) || "end of road".equals(type) || "fork".equals(type) || "on ramp".equals(type)
                || "off ramp".equals(type) || "ramp".equals(type) || "merge".equals(type) || "arrive".equals(type)
                || type.startsWith("roundabout") || "rotary".equals(type);
    }

    private static String cap(String s) {
        return s.length() == 0 ? s : Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    static String spokenDist(Context c, double m) {
        if (Prefs.b(c, "speedMph", false)) {
            double ft = m * 3.28084;
            if (ft < 800) return (Math.max(1, Math.round(ft / 50.0)) * 50) + " feet";
            double mi = m / 1609.344;
            return String.format(Locale.US, "%.1f miles", mi);
        }
        if (m < 950) return (Math.max(1, Math.round(m / 50.0)) * 50) + " meters";
        return String.format(Locale.US, "%.1f kilometers", m / 1000.0);
    }

    private static void say(Context c, final String text) {
        Context app = c.getApplicationContext();
        if (failed) return;
        if (tts == null) {
            pending.add(text);
            init(app);
            return;
        }
        if (!ready) {
            pending.add(text);
            return;
        }
        speak(app, text);
    }

    private static void init(final Context app) {
        am = (AudioManager) app.getSystemService(Context.AUDIO_SERVICE);
        tts = new TextToSpeech(app, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status != TextToSpeech.SUCCESS) {
                    failed = true;
                    pending.clear();
                    return;
                }
                try {
                    int r = tts.setLanguage(Locale.US);
                    if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) tts.setLanguage(Locale.getDefault());
                    if (Build.VERSION.SDK_INT >= 21) {
                        tts.setAudioAttributes(new AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());
                    }
                    tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                        @Override
                        public void onStart(String id) {
                        }

                        @Override
                        public void onDone(String id) {
                            finished();
                        }

                        @Override
                        public void onError(String id) {
                            finished();
                        }
                    });
                    ready = true;
                    List<String> q = new ArrayList<String>(pending);
                    pending.clear();
                    // only the newest message matters once the engine is up
                    if (!q.isEmpty()) speak(app, q.get(q.size() - 1));
                } catch (Exception e) {
                    failed = true;
                }
            }
        });
    }

    private static void speak(Context app, String text) {
        try {
            focus();
            speaking++;
            HashMap<String, String> p = new HashMap<String, String>();
            p.put(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "nav" + System.nanoTime());
            if (Build.VERSION.SDK_INT >= 21) {
                android.os.Bundle b = new android.os.Bundle();
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, b, "nav" + System.nanoTime());
            } else {
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, p);
            }
        } catch (Exception e) {
            finished();
        }
    }

    private static void finished() {
        speaking = Math.max(0, speaking - 1);
        if (speaking == 0) abandon();
    }

    private static void focus() {
        if (am == null) return;
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                if (focusReq == null) {
                    focusReq = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                            .setAudioAttributes(new AudioAttributes.Builder()
                                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                            .setOnAudioFocusChangeListener(new AudioManager.OnAudioFocusChangeListener() {
                                @Override
                                public void onAudioFocusChange(int change) {
                                }
                            }).build();
                }
                am.requestAudioFocus(focusReq);
            } else {
                am.requestAudioFocus(null, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK);
            }
        } catch (Exception ignored) {
        }
    }

    private static void abandon() {
        if (am == null) return;
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                if (focusReq != null) am.abandonAudioFocusRequest(focusReq);
            } else {
                am.abandonAudioFocus(null);
            }
        } catch (Exception ignored) {
        }
    }
}
