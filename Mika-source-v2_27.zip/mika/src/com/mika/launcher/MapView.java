package com.mika.launcher;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.location.Location;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * A small, dependency-free slippy map that draws OpenStreetMap raster tiles.
 * Tiles are cached in memory and on disk. Please keep the attribution visible (it is drawn by this view).
 */
public class MapView extends View implements MapSurface {

    interface Listener {
        void onLongPress(double lat, double lon);

        void onUserMoved();

        void onTap();
    }

    private static final int MIN_Z = 2, MAX_Z = 19;
    private static final String UA = "MikaLauncher/2.1 (Android launcher; contact: none)";

    // view state: centre in normalised world units [0,1), zoom is continuous
    private double cx = 0.5, cy = 0.4;
    private float zoom = 3f;
    private boolean interactive = true;
    private boolean night = false;
    private Listener listener;

    // overlays
    private Location me;
    private boolean hasPin = false;
    private double pinLat, pinLon;
    private List<double[]> saved;
    private int accent = 0xFF2979FF;
    private List<double[]> route;

    // tiles
    private static final LruCache<String, Bitmap> MEM = new LruCache<String, Bitmap>(160);
    private static final ExecutorService POOL = Executors.newFixedThreadPool(3);
    private static final Map<String, Long> FAILED = new HashMap<String, Long>();
    private final Map<String, Boolean> loading = new HashMap<String, Boolean>();
    private final File cacheDir;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private volatile int visZ, visX0, visX1, visY0, visY1;

    // paints
    private final Paint tilePaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint placeholder = new Paint();
    private final Path path = new Path();
    private final float dens;

    private final ScaleGestureDetector scaler;
    private final GestureDetector gestures;

    public MapView(Context c) {
        super(c);
        dens = c.getResources().getDisplayMetrics().density;
        cacheDir = new File(c.getCacheDir(), "tiles");
        cacheDir.mkdirs();
        placeholder.setColor(0xFF2A2F3A);
        stroke.setStyle(Paint.Style.STROKE);
        textPaint.setTextSize(11 * dens);
        setClickable(true);

        scaler = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector d) {
                float dz = (float) (Math.log(d.getScaleFactor()) / Math.log(2));
                zoomAround(zoom + dz, d.getFocusX(), d.getFocusY());
                if (listener != null) listener.onUserMoved();
                return true;
            }
        });
        gestures = new GestureDetector(c, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onScroll(MotionEvent e1, MotionEvent e2, float dx, float dy) {
                if (scaler.isInProgress()) return true;
                double wp = worldPx();
                cx += dx / wp;
                cy += dy / wp;
                normalise();
                if (listener != null) listener.onUserMoved();
                invalidate();
                return true;
            }

            @Override
            public boolean onDoubleTap(MotionEvent e) {
                zoomAround(Math.min(MAX_Z, zoom + 1f), e.getX(), e.getY());
                if (listener != null) listener.onUserMoved();
                return true;
            }

            @Override
            public void onLongPress(MotionEvent e) {
                if (listener == null) return;
                double[] ll = screenToLatLon(e.getX(), e.getY());
                listener.onLongPress(ll[0], ll[1]);
            }

            @Override
            public boolean onSingleTapConfirmed(MotionEvent e) {
                if (listener != null) listener.onTap();
                return true;
            }
        });
    }

    // ------------------------------------------------------------- public API
    @Override
    public void setListener(Listener l) {
        listener = l;
    }

    @Override
    public void setInteractive(boolean b) {
        interactive = b;
    }

    @Override
    public void setNight(boolean b) {
        night = b;
        invalidate();
    }

    @Override
    public void setAccent(int c) {
        accent = c;
    }

    @Override
    public void setMe(Location l) {
        me = l;
        invalidate();
    }

    @Override
    public void setPin(double lat, double lon) {
        hasPin = true;
        pinLat = lat;
        pinLon = lon;
        invalidate();
    }

    @Override
    public void clearPin() {
        hasPin = false;
        invalidate();
    }

    @Override
    public boolean hasPin() {
        return hasPin;
    }

    @Override
    public void setSaved(List<double[]> s) {
        saved = s;
        invalidate();
    }

    @Override
    public void setCenter(double lat, double lon) {
        cx = lonToX(lon);
        cy = latToY(lat);
        normalise();
        invalidate();
    }

    @Override
    public void setZoom(float z) {
        zoom = Math.max(MIN_Z, Math.min(MAX_Z, z));
        invalidate();
    }

    @Override
    public float getZoom() {
        return zoom;
    }

    @Override
    public void zoomBy(float dz) {
        setZoom(zoom + dz);
    }

    @Override
    public double centerLat() {
        return yToLat(cy);
    }

    @Override
    public double centerLon() {
        return xToLon(cx);
    }

    // ---------------------------------------------------------------- maths
    static double lonToX(double lon) {
        return (lon + 180.0) / 360.0;
    }

    static double latToY(double lat) {
        double s = Math.sin(Math.toRadians(Math.max(-85.0511, Math.min(85.0511, lat))));
        return 0.5 - Math.log((1 + s) / (1 - s)) / (4 * Math.PI);
    }

    static double xToLon(double x) {
        return x * 360.0 - 180.0;
    }

    static double yToLat(double y) {
        double n = Math.PI * (1 - 2 * y);
        return Math.toDegrees(Math.atan(Math.sinh(n)));
    }

    private double worldPx() {
        return 256.0 * Math.pow(2, zoom);
    }

    private void normalise() {
        cx = cx - Math.floor(cx);
        if (cy < 0.001) cy = 0.001;
        if (cy > 0.999) cy = 0.999;
    }

    private void zoomAround(float newZoom, float fx, float fy) {
        newZoom = Math.max(MIN_Z, Math.min(MAX_Z, newZoom));
        double wpOld = worldPx();
        double wx = cx + (fx - getWidth() / 2.0) / wpOld;
        double wy = cy + (fy - getHeight() / 2.0) / wpOld;
        zoom = newZoom;
        double wpNew = worldPx();
        cx = wx - (fx - getWidth() / 2.0) / wpNew;
        cy = wy - (fy - getHeight() / 2.0) / wpNew;
        normalise();
        invalidate();
    }

    private double[] screenToLatLon(float x, float y) {
        double wp = worldPx();
        double wx = cx + (x - getWidth() / 2.0) / wp;
        double wy = cy + (y - getHeight() / 2.0) / wp;
        return new double[]{yToLat(wy), xToLon(wx)};
    }

    private float sx(double wx) {
        double d = wx - cx;
        if (d > 0.5) d -= 1;
        if (d < -0.5) d += 1;
        return (float) (getWidth() / 2.0 + d * worldPx());
    }

    private float sy(double wy) {
        return (float) (getHeight() / 2.0 + (wy - cy) * worldPx());
    }

    // ---------------------------------------------------------------- touch
    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (!interactive) return super.onTouchEvent(e);
        getParent().requestDisallowInterceptTouchEvent(true);
        scaler.onTouchEvent(e);
        gestures.onTouchEvent(e);
        return true;
    }

    // ----------------------------------------------------------------- tiles
    private File tileFile(int z, int x, int y) {
        return new File(cacheDir, z + "_" + x + "_" + y + ".png");
    }

    private Bitmap getTile(final int z, final int x, final int y) {
        final String key = z + "/" + x + "/" + y;
        Bitmap b = MEM.get(key);
        if (b != null) return b;
        synchronized (loading) {
            if (loading.containsKey(key)) return null;
            Long f = FAILED.get(key);
            if (f != null && System.currentTimeMillis() - f < 20000) return null;
            loading.put(key, true);
        }
        final Context ctx = getContext();
        POOL.execute(new Runnable() {
            @Override
            public void run() {
                Bitmap bmp = null;
                try {
                    // skip work if the tile is no longer on screen
                    boolean still = z == visZ && x >= ((visX0 % (1 << z)) + (1 << z)) % (1 << z) - 1
                            || true;
                    File f = tileFile(z, x, y);
                    if (f.exists()) {
                        bmp = BitmapFactory.decodeFile(f.getAbsolutePath());
                        if (bmp == null) f.delete();
                    }
                    if (bmp == null && still && z == visZ) {
                        bmp = download(z, x, y, f);
                    }
                } catch (Throwable t) {
                    bmp = null;
                }
                final Bitmap result = bmp;
                if (result != null) MEM.put(key, result);
                else synchronized (FAILED) {
                    FAILED.put(key, System.currentTimeMillis());
                }
                synchronized (loading) {
                    loading.remove(key);
                }
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        invalidate();
                    }
                });
            }
        });
        return null;
    }

    private Bitmap download(int z, int x, int y, File out) throws Exception {
        URL url = new URL("https://tile.openstreetmap.org/" + z + "/" + x + "/" + y + ".png");
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setRequestProperty("User-Agent", UA);
        c.setConnectTimeout(8000);
        c.setReadTimeout(8000);
        try {
            if (c.getResponseCode() != 200) return null;
            InputStream in = c.getInputStream();
            FileOutputStream fo = new FileOutputStream(out);
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) fo.write(buf, 0, n);
            fo.close();
            in.close();
            return BitmapFactory.decodeFile(out.getAbsolutePath());
        } finally {
            c.disconnect();
        }
    }

    /** Deletes old cached tiles when the cache grows beyond ~150 MB. */
    static void trimCache(Context c) {
        final File dir = new File(c.getCacheDir(), "tiles");
        POOL.execute(new Runnable() {
            @Override
            public void run() {
                File[] files = dir.listFiles();
                if (files == null) return;
                long total = 0;
                for (File f : files) total += f.length();
                if (total < 150L * 1024 * 1024) return;
                java.util.Arrays.sort(files, new java.util.Comparator<File>() {
                    @Override
                    public int compare(File a, File b) {
                        return a.lastModified() < b.lastModified() ? -1 : 1;
                    }
                });
                for (File f : files) {
                    total -= f.length();
                    f.delete();
                    if (total < 100L * 1024 * 1024) break;
                }
            }
        });
    }

    // ----------------------------------------------------------------- draw
    @Override
    protected void onDraw(Canvas canvas) {
        int w = getWidth(), h = getHeight();
        canvas.drawColor(night ? 0xFF14171D : 0xFFE8E4DC);
        if (night) {
            // invert + slight hue shift so OSM tiles look like a dark map
            ColorMatrix cm = new ColorMatrix(new float[]{
                    -0.62f, 0, 0, 0, 255 * 0.86f,
                    0, -0.62f, 0, 0, 255 * 0.88f,
                    0, 0, -0.62f, 0, 255 * 0.92f,
                    0, 0, 0, 1, 0});
            ColorMatrix sat = new ColorMatrix();
            sat.setSaturation(0.55f);
            cm.postConcat(sat);
            tilePaint.setColorFilter(new ColorMatrixColorFilter(cm));
        } else {
            tilePaint.setColorFilter(null);
        }

        int z = Math.max(MIN_Z, Math.min(MAX_Z, (int) Math.floor(zoom)));
        double wp = worldPx();
        double tilePx = 256.0 * Math.pow(2, zoom - z);
        int n = 1 << z;
        double left = cx - (w / 2.0) / wp, top = cy - (h / 2.0) / wp;
        double right = cx + (w / 2.0) / wp, bottom = cy + (h / 2.0) / wp;
        int x0 = (int) Math.floor(left * n), x1 = (int) Math.floor(right * n);
        int y0 = (int) Math.floor(top * n), y1 = (int) Math.floor(bottom * n);
        visZ = z;
        visX0 = x0;
        visX1 = x1;
        visY0 = y0;
        visY1 = y1;

        RectF dst = new RectF();
        Rect src = new Rect();
        for (int tx = x0; tx <= x1; tx++) {
            for (int ty = y0; ty <= y1; ty++) {
                if (ty < 0 || ty >= n) continue;
                int wx = ((tx % n) + n) % n;
                float px = (float) ((tx / (double) n - left) * wp);
                float py = (float) ((ty / (double) n - top) * wp);
                dst.set(px, py, px + (float) tilePx + 1, py + (float) tilePx + 1);
                Bitmap b = getTile(z, wx, ty);
                if (b != null) {
                    canvas.drawBitmap(b, null, dst, tilePaint);
                } else {
                    Bitmap parent = z > MIN_Z ? MEM.get((z - 1) + "/" + (wx / 2) + "/" + (ty / 2)) : null;
                    if (parent != null) {
                        int hw = parent.getWidth() / 2, hh = parent.getHeight() / 2;
                        src.set((wx % 2) * hw, (ty % 2) * hh, (wx % 2) * hw + hw, (ty % 2) * hh + hh);
                        canvas.drawBitmap(parent, src, dst, tilePaint);
                    } else {
                        canvas.drawRect(dst, placeholder);
                    }
                }
            }
        }

        // route line
        if (route != null && route.size() > 1) {
            path.reset();
            boolean first = true;
            for (double[] p : route) {
                float x = sx(lonToX(p[1])), y = sy(latToY(p[0]));
                if (first) {
                    path.moveTo(x, y);
                    first = false;
                } else path.lineTo(x, y);
            }
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeCap(Paint.Cap.ROUND);
            stroke.setStrokeJoin(Paint.Join.ROUND);
            stroke.setColor(0xFFFFFFFF);
            stroke.setStrokeWidth(9 * dens);
            canvas.drawPath(path, stroke);
            stroke.setColor(accent);
            stroke.setStrokeWidth(5.5f * dens);
            canvas.drawPath(path, stroke);
        }

        // saved places
        if (saved != null) {
            for (double[] p : saved) {
                float x = sx(lonToX(p[1])), y = sy(latToY(p[0]));
                if (x < -40 || y < -40 || x > w + 40 || y > h + 40) continue;
                fill.setColor(0xFFFFB300);
                canvas.drawCircle(x, y, 7 * dens, fill);
                stroke.setColor(Color.WHITE);
                stroke.setStrokeWidth(2 * dens);
                canvas.drawCircle(x, y, 7 * dens, stroke);
            }
        }

        // dropped pin
        if (hasPin) drawPin(canvas, sx(lonToX(pinLon)), sy(latToY(pinLat)));

        // my location
        if (me != null) drawMe(canvas);

        // attribution (required by the OSM tile usage policy)
        String attr = "\u00A9 OpenStreetMap contributors";
        float tw = textPaint.measureText(attr);
        fill.setColor(0xB0FFFFFF);
        canvas.drawRect(w - tw - 12 * dens, h - 18 * dens, w, h, fill);
        textPaint.setColor(0xFF333333);
        canvas.drawText(attr, w - tw - 6 * dens, h - 5 * dens, textPaint);
    }

    private void drawPin(Canvas c, float x, float y) {
        float r = 11 * dens;
        path.reset();
        path.moveTo(x, y);
        path.lineTo(x - r * 0.75f, y - r * 1.6f);
        path.lineTo(x + r * 0.75f, y - r * 1.6f);
        path.close();
        fill.setColor(0xFFE53935);
        c.drawPath(path, fill);
        c.drawCircle(x, y - r * 1.9f, r, fill);
        fill.setColor(Color.WHITE);
        c.drawCircle(x, y - r * 1.9f, r * 0.38f, fill);
    }

    private void drawMe(Canvas c) {
        float x = sx(lonToX(me.getLongitude())), y = sy(latToY(me.getLatitude()));
        if (me.hasAccuracy()) {
            double mpp = 156543.03392 * Math.cos(Math.toRadians(me.getLatitude())) / Math.pow(2, zoom);
            float r = (float) Math.min(400 * dens, me.getAccuracy() / mpp);
            if (r > 10 * dens) {
                fill.setColor(0x222979FF);
                c.drawCircle(x, y, r, fill);
            }
        }
        boolean moving = me.hasBearing() && me.hasSpeed() && me.getSpeed() > 1f;
        if (moving) {
            c.save();
            c.rotate(me.getBearing(), x, y);
            path.reset();
            path.moveTo(x, y - 20 * dens);
            path.lineTo(x - 9 * dens, y + 3 * dens);
            path.lineTo(x + 9 * dens, y + 3 * dens);
            path.close();
            fill.setColor(accent);
            c.drawPath(path, fill);
            c.restore();
        }
        fill.setColor(Color.WHITE);
        c.drawCircle(x, y, 10 * dens, fill);
        fill.setColor(accent);
        c.drawCircle(x, y, 7.5f * dens, fill);
    }

    // ------------------------------------------------- MapSurface extras
    @Override
    public void flyTo(double lat, double lon, float z) {
        setCenter(lat, lon);
        setZoom(z);
    }

    @Override
    public boolean isVector() {
        return false;
    }

    @Override
    public void followTo(double lat, double lon, float bearing, boolean moving) {
        setCenter(lat, lon);
    }

    @Override
    public void setTilt(boolean on) {
    }

    @Override
    public boolean isTilted() {
        return false;
    }

    @Override
    public void setHeadingUp(boolean on) {
    }

    @Override
    public void resetNorth() {
    }

    @Override
    public void setSatellite(boolean on) {
    }

    @Override
    public boolean isSatellite() {
        return false;
    }

    @Override
    public void setRoute(List<double[]> latLon) {
        route = latLon;
        invalidate();
    }

    @Override
    public void clearRoute() {
        route = null;
        invalidate();
    }

    @Override
    public void fitRoute() {
        if (route == null || route.size() < 2 || getWidth() == 0) return;
        double minX = 9, maxX = -9, minY = 9, maxY = -9;
        for (double[] p : route) {
            double x = lonToX(p[1]), y = latToY(p[0]);
            minX = Math.min(minX, x);
            maxX = Math.max(maxX, x);
            minY = Math.min(minY, y);
            maxY = Math.max(maxY, y);
        }
        cx = (minX + maxX) / 2;
        cy = (minY + maxY) / 2;
        float z = MAX_Z;
        while (z > MIN_Z) {
            double wp = 256.0 * Math.pow(2, z);
            if ((maxX - minX) * wp < getWidth() * 0.6 && (maxY - minY) * wp < getHeight() * 0.5) break;
            z -= 0.5f;
        }
        zoom = z;
        normalise();
        invalidate();
    }
}
