package com.mika.launcher;

import android.content.ContentUris;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.os.Build;
import android.util.Size;
import java.io.File;
import java.net.HttpURLConnection;
import java.net.URL;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.util.LruCache;
import android.widget.ImageView;

import java.io.InputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Asynchronous, cached thumbnail loading for lists. */
final class Thumbs {
    private Thumbs() {
    }

    interface Loader {
        Bitmap load() throws Exception;
    }

    private static final LruCache<String, Bitmap> CACHE = new LruCache<String, Bitmap>(24 * 1024 * 1024) {
        @Override
        protected int sizeOf(String k, Bitmap b) {
            return b.getByteCount();
        }
    };
    private static final ExecutorService POOL = Executors.newFixedThreadPool(3);

    static void load(final ImageView iv, final String key, final Loader l) {
        iv.setTag(key);
        Bitmap b = CACHE.get(key);
        if (b != null) {
            iv.setImageBitmap(b);
            return;
        }
        iv.setImageDrawable(null);
        POOL.execute(new Runnable() {
            @Override
            public void run() {
                Bitmap bmp = null;
                try {
                    bmp = l.load();
                } catch (Throwable ignored) {
                }
                if (bmp == null) return;
                CACHE.put(key, bmp);
                final Bitmap fb = bmp;
                iv.post(new Runnable() {
                    @Override
                    public void run() {
                        if (key.equals(iv.getTag())) iv.setImageBitmap(fb);
                    }
                });
            }
        });
    }

    static Bitmap decodeUri(Context c, Uri uri, int maxDim) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            InputStream in = c.getContentResolver().openInputStream(uri);
            BitmapFactory.decodeStream(in, null, o);
            if (in != null) in.close();
            int sample = 1;
            while (o.outWidth / (sample * 2) >= maxDim && o.outHeight / (sample * 2) >= maxDim) sample *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            in = c.getContentResolver().openInputStream(uri);
            Bitmap b = BitmapFactory.decodeStream(in, null, o2);
            if (in != null) in.close();
            return b;
        } catch (Throwable t) {
            return null;
        }
    }

    /** Album art: tries the MediaStore album-art URI first, then the picture embedded in the file. */
    static Bitmap audioArt(Context c, Track t, int size) {
        Bitmap b = null;
        if (t.albumId > 0) {
            b = decodeUri(c, ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), t.albumId), size);
        }
        if (b == null && t.uri != null) {
            MediaMetadataRetriever r = new MediaMetadataRetriever();
            try {
                r.setDataSource(c, t.uri);
                byte[] pic = r.getEmbeddedPicture();
                if (pic != null) {
                    BitmapFactory.Options o = new BitmapFactory.Options();
                    o.inJustDecodeBounds = true;
                    BitmapFactory.decodeByteArray(pic, 0, pic.length, o);
                    int sample = 1;
                    while (o.outWidth / (sample * 2) >= size) sample *= 2;
                    BitmapFactory.Options o2 = new BitmapFactory.Options();
                    o2.inSampleSize = sample;
                    b = BitmapFactory.decodeByteArray(pic, 0, pic.length, o2);
                }
            } catch (Throwable ignored) {
            } finally {
                try {
                    r.release();
                } catch (Throwable ignored) {
                }
            }
        }
        if (b == null && t.uri != null && Build.VERSION.SDK_INT >= 29) {
            try {
                b = c.getContentResolver().loadThumbnail(t.uri, new Size(size, size), null);
            } catch (Throwable ignored) {
            }
        }
        if (b == null && t.uri != null) b = folderArt(c, t.uri, size);
        return b;
    }

    /** cover.jpg / folder.jpg / albumart.jpg next to the audio file. */
    private static Bitmap folderArt(Context c, Uri uri, int size) {
        android.database.Cursor cur = null;
        try {
            cur = c.getContentResolver().query(uri, new String[]{android.provider.MediaStore.MediaColumns.DATA},
                    null, null, null);
            if (cur == null || !cur.moveToFirst()) return null;
            String path = cur.getString(0);
            if (path == null) return null;
            File dir = new File(path).getParentFile();
            if (dir == null) return null;
            String[] names = {"cover", "folder", "albumart", "front", "album", "artwork"};
            String[] exts = {".jpg", ".jpeg", ".png"};
            for (String n : names) {
                for (String e : exts) {
                    File f = new File(dir, n + e);
                    if (f.exists()) {
                        Bitmap b = decodeUri(c, Uri.fromFile(f), size);
                        if (b != null) return b;
                    }
                }
            }
        } catch (Throwable ignored) {
        } finally {
            if (cur != null) cur.close();
        }
        return null;
    }

    /** Loads artwork from a content://, file:// or http(s):// URI string (used for other apps' media sessions). */
    static Bitmap decodeAny(Context c, String uriStr, int maxDim) {
        try {
            Uri u = Uri.parse(uriStr);
            String sch = u.getScheme();
            if (sch == null) return null;
            if (sch.startsWith("http")) {
                HttpURLConnection h = (HttpURLConnection) new URL(uriStr).openConnection();
                h.setConnectTimeout(6000);
                h.setReadTimeout(8000);
                InputStream in = h.getInputStream();
                java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0 && bo.size() < 6 * 1024 * 1024) bo.write(buf, 0, n);
                in.close();
                byte[] d = bo.toByteArray();
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inJustDecodeBounds = true;
                BitmapFactory.decodeByteArray(d, 0, d.length, o);
                int sample = 1;
                while (o.outWidth / (sample * 2) >= maxDim && o.outHeight / (sample * 2) >= maxDim) sample *= 2;
                BitmapFactory.Options o2 = new BitmapFactory.Options();
                o2.inSampleSize = sample;
                return BitmapFactory.decodeByteArray(d, 0, d.length, o2);
            }
            return decodeUri(c, u, maxDim);
        } catch (Throwable t) {
            return null;
        }
    }

    /** Cheap blur: shrink, box-blur twice, return the small bitmap (scale it up when drawing). */
    static Bitmap blur(Bitmap src, int radius) {
        if (src == null) return null;
        try {
            int w = 64, h = Math.max(1, Math.round(64f * src.getHeight() / src.getWidth()));
            Bitmap b = Bitmap.createScaledBitmap(src, w, h, true).copy(Bitmap.Config.ARGB_8888, true);
            int[] px = new int[w * h], out = new int[w * h];
            b.getPixels(px, 0, w, 0, 0, w, h);
            for (int pass = 0; pass < 2; pass++) {
                for (int y = 0; y < h; y++) {
                    for (int x = 0; x < w; x++) {
                        int a = 0, r = 0, g = 0, bl = 0, n = 0;
                        for (int dy = -radius; dy <= radius; dy++) {
                            int yy = y + dy;
                            if (yy < 0 || yy >= h) continue;
                            for (int dx = -radius; dx <= radius; dx++) {
                                int xx = x + dx;
                                if (xx < 0 || xx >= w) continue;
                                int p = px[yy * w + xx];
                                a += p >>> 24;
                                r += (p >> 16) & 255;
                                g += (p >> 8) & 255;
                                bl += p & 255;
                                n++;
                            }
                        }
                        out[y * w + x] = ((a / n) << 24) | ((r / n) << 16) | ((g / n) << 8) | (bl / n);
                    }
                }
                int[] t = px;
                px = out;
                out = t;
            }
            b.setPixels(px, 0, w, 0, 0, w, h);
            return b;
        } catch (Throwable t) {
            return null;
        }
    }

    /** Generated cover for tracks without any artwork: accent gradient with the title's first letter. */
    static Bitmap placeholder(String title, int accent, int size) {
        Bitmap b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        int dark = android.graphics.Color.rgb((int) (android.graphics.Color.red(accent) * 0.35f),
                (int) (android.graphics.Color.green(accent) * 0.35f), (int) (android.graphics.Color.blue(accent) * 0.35f));
        p.setShader(new LinearGradient(0, 0, size, size, accent, dark, Shader.TileMode.CLAMP));
        cv.drawRect(0, 0, size, size, p);
        p.setShader(null);
        p.setColor(0x33FFFFFF);
        cv.drawCircle(size * 0.8f, size * 0.2f, size * 0.35f, p);
        p.setColor(0xFFFFFFFF);
        p.setTextAlign(Paint.Align.CENTER);
        p.setTextSize(size * 0.5f);
        p.setFakeBoldText(true);
        String ch = "\u266B";
        if (title != null) {
            String tt = title.trim();
            if (tt.length() > 0 && Character.isLetterOrDigit(tt.codePointAt(0))) {
                ch = new String(Character.toChars(tt.codePointAt(0))).toUpperCase();
            }
        }
        cv.drawText(ch, size / 2f, size / 2f + size * 0.18f, p);
        return b;
    }

    static Bitmap videoFrame(Context c, Uri uri, int size) {
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        try {
            r.setDataSource(c, uri);
            Bitmap f = r.getFrameAtTime(1000000);
            if (f == null) return null;
            float s = (float) size / Math.max(f.getWidth(), f.getHeight());
            if (s < 1f) f = Bitmap.createScaledBitmap(f, Math.round(f.getWidth() * s), Math.round(f.getHeight() * s), true);
            return f;
        } catch (Throwable t) {
            return null;
        } finally {
            try {
                r.release();
            } catch (Throwable ignored) {
            }
        }
    }
}
