package com.mika.launcher;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.KeyEvent;

import java.util.List;

/**
 * What happens when the car's Bluetooth connects: open Mika on the car page (needs "display over other apps",
 * otherwise Android only allows a notification that opens it) and carry on with the music that was playing.
 */
final class CarLaunch {
    private CarLaunch() {
    }

    static final int NOTIF_ID = 7300;
    private static final String CHANNEL = "mika_car";
    private static long lastAt = 0;
    static volatile long musicHandledAt = 0;

    static void onConnected(final Context c, final BroadcastReceiver.PendingResult pr) {
        long now = System.currentTimeMillis();
        if (now - lastAt < 20000) { // A2DP / HFP / ACL of the same device arrive together
            pr.finish();
            return;
        }
        lastAt = now;
        final boolean music = Prefs.b(c, "btMusic", true);
        if (Prefs.b(c, "btOpen", true)) openCarPage(c, music);
        if (!music) {
            pr.finish();
            return;
        }
        // MainActivity resumes the music itself once it is on screen (a service may only be started then).
        // If it did not open (Android refused), do it from here after a few seconds.
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                try {
                    if (System.currentTimeMillis() - musicHandledAt > 8000) resumeMusic(c);
                } finally {
                    pr.finish();
                }
            }
        }, 6000);
    }

    private static void openCarPage(Context c, boolean music) {
        Intent open = new Intent(c, MainActivity.class).setAction(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                .putExtra("gotoCar", true).putExtra("resumeMusic", music);
        boolean canOverlay = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(c);
        try {
            if (canOverlay) c.startActivity(open);
        } catch (Exception ignored) {
        }
        if (canOverlay) return;
        // no overlay permission: a heads-up / full-screen notification is the only thing Android lets us start from the background
        try {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            Notification.Builder b;
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Car connected", NotificationManager.IMPORTANCE_HIGH));
                b = new Notification.Builder(c, CHANNEL);
            } else {
                b = new Notification.Builder(c);
            }
            PendingIntent pi = PendingIntent.getActivity(c, 3, open,
                    PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
            b.setSmallIcon(android.R.drawable.ic_menu_directions).setContentTitle("Car connected").setContentText("Tap to open Mika")
                    .setContentIntent(pi).setFullScreenIntent(pi, true).setAutoCancel(true).setCategory(Notification.CATEGORY_CALL);
            nm.notify(NOTIF_ID, b.build());
        } catch (Exception ignored) {
        }
    }

    /** Resumes whatever was playing last: another app's media session, Mika's own player, or the last Mika track. */
    static void resumeMusic(Context c) {
        musicHandledAt = System.currentTimeMillis();
        try {
            if (MediaTracker.hasAccess(c)) {
                MediaSessionManager msm = (MediaSessionManager) c.getSystemService(Context.MEDIA_SESSION_SERVICE);
                List<MediaController> list = msm.getActiveSessions(new ComponentName(c, MediaListenerService.class));
                if (list != null && !list.isEmpty()) {
                    MediaController mc = list.get(0); // most recently active first
                    if (!c.getPackageName().equals(mc.getPackageName())) {
                        PlaybackState st = mc.getPlaybackState();
                        if (st == null || st.getState() != PlaybackState.STATE_PLAYING) mc.getTransportControls().play();
                        return;
                    }
                }
            }
        } catch (Exception ignored) {
        }
        try {
            if (PlayerService.active()) {
                if (!PlayerService.isPlaying()) PlayerService.send(c, PlayerService.ACTION_TOGGLE);
                return;
            }
            if (PlayerService.resumeLast(c)) return;
        } catch (Exception ignored) {
        }
        try {
            AudioManager am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
            if (!am.isMusicActive()) {
                am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PLAY));
                am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PLAY));
            }
        } catch (Exception ignored) {
        }
    }
}
