package com.mika.launcher;

/**
 * Camera for the 3D car slides: a list of preset views (front 3/4, side, top down, wheel, orbit, ...) and an eased state
 * that glides from one view to the next. Pure Java (no Android classes) so it can be unit-tested on a desktop JVM.
 *
 * World space: X forward (the car drives towards +X), Y up, Z to the car's right; the road centre line is Z = 0 and the
 * guard rail stands at |Z| = 6.3 m, so every view keeps the camera inside it.
 */
final class CarCam {
    /** Names shown on the view pill and in Settings (the last one steps through the others by itself). */
    static final String[] NAMES = {
            "Front 3/4", "Rear 3/4", "Side", "Front", "Rear", "Low hero",
            "High 3/4", "Top down", "Wheel", "Chase", "Orbit", "Auto tour"
    };
    static final int COUNT = NAMES.length;
    static final int AUTO_TOUR = COUNT - 1;
    /** The view the front slide / rear slide start with (the two original cameras). */
    static final int DEFAULT_FRONT = 0, DEFAULT_REAR = 1;

    // per view: yaw (deg, 0 = camera ahead of the car, 90 = on its right side), elevation (deg), distance multiplier,
    // look-at x / y / z (m), half-width (m) that must fit the screen, sway (deg), kind (0 fixed, 1 orbit, 2 front wheel)
    private static final float[][] V = {
            /* 0 Front 3/4 */ {38f, 6f, 1.00f, 0f, 1.30f, 0f, 0f, 5f, 0},
            /* 1 Rear 3/4  */ {160f, 6f, 0.88f, 0f, 1.30f, 0f, 0f, 6f, 0},
            /* 2 Side      */ {90f, 3.5f, 0.77f, 0f, 1.15f, 0f, 2.75f, 2f, 0},
            /* 3 Front     */ {12f, 4f, 0.95f, 0f, 1.20f, 0f, 1.7f, 3f, 0},
            /* 4 Rear      */ {168f, 4f, 0.90f, 0f, 1.20f, 0f, 1.7f, 3f, 0},
            /* 5 Low hero  */ {28f, 1.5f, 0.62f, 0.35f, 0.55f, 0f, 0f, 3f, 0},
            /* 6 High 3/4  */ {50f, 30f, 1.00f, 0f, 0.90f, 0f, 0f, 3f, 0},
            /* 7 Top down  */ {90f, 78f, 1.00f, 0f, 0.50f, 0f, 2.8f, 1.5f, 0},
            /* 8 Wheel     */ {72f, 8f, 0.36f, 0f, 0f, 0f, 0.95f, 3f, 2},
            /* 9 Chase     */ {180f, 9f, 1.25f, 3.0f, 1.10f, 0f, 1.7f, 1.5f, 0},
            /* 10 Orbit    */ {0f, 10f, 0.77f, 0f, 1.15f, 0f, 2.8f, 0f, 1},
    };
    /** Views the auto tour steps through, and how long it stays on each (seconds). */
    private static final int[] TOUR = {0, 2, 5, 6, 3, 8, 1, 4, 9, 7};
    private static final float TOUR_DWELL = 7f;
    private static final float ORBIT_DEG_PER_S = 18f;
    private static final float EASE_S = 0.50f;      // total time constant of the glide between views (two cascaded filters: it starts and stops softly)
    private static final float CAM_DIST = 1.15f;    // overall framing factor of the original camera

    // eased state: [yaw, elevation, distance, look x, look y, look z, sway]; `mid` is the first filter stage, `cur` the output
    private final float[] mid = new float[7], cur = new float[7];
    private float tourT;
    private boolean init;
    /** Preset currently shown (the tour's current stop when the auto tour is selected). */
    int shown;

    // outputs of update()
    float ex, ey, ez;       // eye
    float lx, ly, lz;       // look-at point
    float lightYawDeg;      // camera yaw incl. sway, for the key light

    static int clamp(int v) {
        return Math.max(0, Math.min(COUNT - 1, v));
    }

    private static float wrap(float a) {
        a %= 360f;
        if (a > 180f) a -= 360f;
        if (a < -180f) a += 360f;
        return a;
    }

    /** Restarts the auto tour from its first stop (call when it is selected). */
    void resetTour() {
        tourT = 0f;
    }

    /**
     * @param sel    selected view (0..COUNT-1)
     * @param dt     smoothed frame step in seconds
     * @param time   running time in seconds (sway, orbit)
     * @param tv     tan(fov / 2)
     * @param aspect screen width / height
     * @param wheel  world position {x, y, z} of the near-side front wheel centre (for the wheel view)
     */
    void update(int sel, float dt, float time, float tv, float aspect, float[] wheel) {
        sel = clamp(sel);
        int idx = sel;
        if (sel == AUTO_TOUR) {
            tourT += dt;
            idx = TOUR[((int) (tourT / TOUR_DWELL)) % TOUR.length];
        }
        shown = idx;
        float[] p = V[idx];
        float tYaw = p[8] == 1f ? wrap(time * ORBIT_DEG_PER_S) : p[0];
        float base = Math.max(2.25f / tv, 3.2f / (tv * aspect)) * CAM_DIST;
        float tDist = base * p[2];
        if (p[6] > 0f) tDist = Math.max(tDist, p[6] / (tv * aspect));
        float tTx = p[3], tTy = p[4], tTz = p[5];
        if (p[8] == 2f && wheel != null && wheel.length >= 3) {
            tTx = wheel[0];
            tTy = wheel[1] + 0.05f;
            tTz = wheel[2];
        }
        float[] t = {tYaw, p[1], tDist, tTx, tTy, tTz, p[7]};
        if (!init) {
            for (int i = 0; i < 7; i++) {
                mid[i] = t[i];
                cur[i] = t[i];
            }
            init = true;
        } else {
            float k = 1f - (float) Math.exp(-Math.max(0f, dt) / (EASE_S * 0.5f));
            for (int i = 0; i < 7; i++) {
                if (i == 0) { // yaw takes the short way round
                    mid[0] = wrap(mid[0] + wrap(t[0] - mid[0]) * k);
                    cur[0] = wrap(cur[0] + wrap(mid[0] - cur[0]) * k);
                } else {
                    mid[i] += (t[i] - mid[i]) * k;
                    cur[i] += (mid[i] - cur[i]) * k;
                }
            }
        }
        float yd = cur[0] + cur[6] * (float) Math.sin(time * 0.35f);
        float yr = (float) Math.toRadians(yd);
        float er = (float) Math.toRadians(cur[1] + 0.8f * (float) Math.sin(time * 0.23f));
        ex = cur[3] + cur[2] * (float) (Math.cos(er) * Math.cos(yr));
        ey = cur[4] + cur[2] * (float) Math.sin(er);
        ez = cur[5] + cur[2] * (float) (Math.cos(er) * Math.sin(yr));
        lx = cur[3]; ly = cur[4]; lz = cur[5];
        lightYawDeg = yd;
    }

    /** Key-light direction (x, y, z) for the car shader: the light comes from the camera's side, so every view is lit from the front. */
    void key(float[] out) {
        float yr = (float) Math.toRadians(lightYawDeg);
        out[0] = 0.45f * Math.max(-1f, Math.min(1f, (float) Math.cos(yr) * 4f));
        out[1] = 0.85f;
        out[2] = 0.35f * Math.max(-1f, Math.min(1f, (float) Math.sin(yr) * 4f));
    }

    /** True when the camera looks (nearly) straight down, where the sky is not visible at all. */
    boolean lookingDown() {
        return cur[1] > 60f;
    }
}
