package com.mika.launcher;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Follows a short maps link (maps.app.goo.gl, goo.gl/maps, g.co ...) until the coordinates show up.
 * Tries several "browser identities" because Google answers each one differently (full page, light page,
 * link-preview page with a static map), follows HTTP redirects AND redirects hidden in the page
 * (meta refresh, canonical link, JavaScript), skips the cookie-consent wall and reads the coordinates
 * from the URL or from the page. Pure Java (no Android classes) so it can be tested anywhere.
 */
final class LinkResolver {
    private static final String PREVIEW_UA = "facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)";
    private static final String[] UAS = {
            PREVIEW_UA,
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
    };
    private static final int MAX_HOPS = 12;
    private static final int MAX_BODY = 1500000;
    /** tests only: allow following links on any host */
    static boolean allowAnyHost = false;

    private static final Pattern META_REFRESH = Pattern.compile("http-equiv=[\"']refresh[\"'][^>]*?url=([^\"'>\\s]+)", Pattern.CASE_INSENSITIVE);
    private static final Pattern CANONICAL = Pattern.compile("<link[^>]+rel=[\"']canonical[\"'][^>]*?href=[\"']([^\"']+)[\"']", Pattern.CASE_INSENSITIVE);
    private static final Pattern OG_URL = Pattern.compile("property=[\"']og:url[\"'][^>]*?content=[\"']([^\"']+)[\"']", Pattern.CASE_INSENSITIVE);
    private static final Pattern JS_LOC = Pattern.compile("(?:window\\.|document\\.|top\\.)?location(?:\\.href|\\.replace)?\\s*(?:=|\\()\\s*[\"']([^\"']+)[\"']");
    private static final Pattern ANY_MAPS_URL = Pattern.compile("https?://(?:www\\.)?(?:google\\.[a-z.]+/maps|maps\\.google\\.[a-z.]+)[^\"'\\s<>\\\\]*");

    private LinkResolver() {
    }

    /** Returns a MapLink with coordinates when found; otherwise a MapLink with only a name/query, or null. */
    static MapLink resolve(String start) {
        MapLink named = null;
        for (String ua : UAS) {
            try {
                MapLink r = follow(start, ua);
                if (r == null) continue;
                if (r.hasPoint()) {
                    if (named != null) {
                        if (r.name == null) r.name = named.name;
                        if (r.query == null) r.query = named.query;
                    }
                    return r;
                }
                if (named == null && (r.name != null || r.query != null)) named = r;
            } catch (Exception ignored) {
            }
        }
        return named;
    }

    private static MapLink follow(String start, String ua) throws Exception {
        String cur = start;
        MapLink named = null;
        Set<String> seen = new HashSet<String>();
        for (int hop = 0; hop < MAX_HOPS; hop++) {
            if (!seen.add(cur)) break;
            HttpURLConnection c = (HttpURLConnection) new URL(cur).openConnection();
            c.setInstanceFollowRedirects(false);
            c.setRequestProperty("User-Agent", ua);
            c.setRequestProperty("Accept", "text/html,application/xhtml+xml,*/*;q=0.8");
            c.setRequestProperty("Accept-Language", "en-US,en;q=0.9");
            // skips Google's cookie-consent wall (EU) that otherwise hides the place
            c.setRequestProperty("Cookie", "CONSENT=YES+cb; SOCS=CAESEwgDEgk0ODE3Nzk3MjQaAmVuIAEaBgiA_LyaBg");
            c.setConnectTimeout(8000);
            c.setReadTimeout(10000);
            try {
                int code = c.getResponseCode();
                String next = null;
                if (code >= 300 && code < 400) {
                    String loc = c.getHeaderField("Location");
                    if (loc == null) break;
                    next = new URL(new URL(cur), loc).toString();
                } else if (code == 200) {
                    String body = read(c);
                    MapLink m = ua.equals(PREVIEW_UA) ? MapLink.scanPreview(body) : MapLink.scanBody(body);
                    if (m.hasPoint()) {
                        if (named != null) {
                            m.name = named.name;
                            m.query = named.query;
                        }
                        return m;
                    }
                    next = nextUrl(body, cur);
                    if (next == null) break;
                } else {
                    break;
                }
                // consent wall in the middle of the chain: go straight to the real link
                if (next.toLowerCase(Locale.US).contains("consent.google.")) {
                    String cont = MapLink.param(next, "continue");
                    if (cont != null && cont.length() > 0) next = cont;
                }
                MapLink m = MapLink.parse(next);
                if (m.hasPoint()) {
                    if (m.name == null && named != null) m.name = named.name;
                    return m;
                }
                if (m.shortUrl == null && (m.name != null || m.query != null)) named = m;
                cur = next;
            } finally {
                c.disconnect();
            }
        }
        return named;
    }

    private static String read(HttpURLConnection c) throws Exception {
        BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
        StringBuilder sb = new StringBuilder();
        char[] buf = new char[8192];
        int n;
        while ((n = r.read(buf)) > 0 && sb.length() < MAX_BODY) sb.append(buf, 0, n);
        r.close();
        return sb.toString();
    }

    /** A link hidden in the page (meta refresh, canonical, JavaScript redirect, any Google Maps URL). */
    private static String nextUrl(String body, String cur) {
        String b = MapLink.unescape(body);
        Pattern[] ps = {META_REFRESH, CANONICAL, OG_URL, JS_LOC, ANY_MAPS_URL};
        for (Pattern p : ps) {
            Matcher m = p.matcher(b);
            while (m.find()) {
                String u = p == ANY_MAPS_URL ? m.group() : m.group(1);
                try {
                    u = new URL(new URL(cur), u.trim()).toString();
                } catch (Exception e) {
                    continue;
                }
                if (u.equals(cur) || !u.startsWith("http")) continue;
                if (!allowAnyHost && !googleHost(u)) continue;
                return u;
            }
        }
        return null;
    }

    private static boolean googleHost(String u) {
        int s = u.indexOf("://");
        if (s < 0) return false;
        String rest = u.substring(s + 3);
        int e = rest.length();
        for (int i = 0; i < rest.length(); i++) {
            char ch = rest.charAt(i);
            if (ch == '/' || ch == '?' || ch == '#' || ch == ':') {
                e = i;
                break;
            }
        }
        String h = rest.substring(0, e).toLowerCase(Locale.US);
        return h.equals("goo.gl") || h.equals("maps.app.goo.gl") || h.equals("g.co") || h.endsWith(".google.com")
                || h.equals("google.com") || h.startsWith("google.") || h.startsWith("www.google.") || h.startsWith("maps.google.")
                || h.startsWith("consent.google.");
    }
}
