package com.mika.launcher;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

/** Full-screen photo viewer: pinch-zoom, swipe, slideshow, share and "use as Mika wallpaper". */
public class PhotoViewerActivity extends Activity {

    static List<Track> items = new ArrayList<Track>();
    static int startIndex = 0;

    private List<Track> list = new ArrayList<Track>();
    private int index = 0;
    private int token = 0;
    private ZoomImageView zv;
    private LinearLayout topBar;
    private TextView tvTitle, tvCount;
    private View btnSlide;
    private boolean overlay = true;
    private boolean slideshow = false;
    private final Handler h = new Handler();
    private Bitmap current;

    private int dp(int v) {
        return Ui.dp(this, v);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.cutout(this);
        Intent in = getIntent();
        if (Intent.ACTION_VIEW.equals(in.getAction()) && in.getData() != null) {
            list.add(Track.fromUri(this, in.getData()));
        } else {
            list.addAll(items);
            index = Math.max(0, Math.min(startIndex, list.size() - 1));
        }
        if (list.isEmpty()) {
            finish();
            return;
        }
        build();
        show(index);
    }

    private void build() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        zv = new ZoomImageView(this);
        zv.setListener(new ZoomImageView.Listener() {
            public void onSwipe(int d) {
                go(d);
            }

            public void onTap() {
                setOverlay(!overlay);
            }
        });
        root.addView(zv, new FrameLayout.LayoutParams(-1, -1));

        topBar = new LinearLayout(this);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setBackgroundColor(0x99000000);
        topBar.setPadding(dp(12), dp(10), dp(12), dp(10));
        topBar.addView(ibtn(Icons.BACK, new View.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        }));
        tvTitle = Ui.text(this, "", 16, Color.WHITE);
        tvTitle.setSingleLine(true);
        tvTitle.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0, -2, 1f);
        tl.leftMargin = dp(12);
        topBar.addView(tvTitle, tl);
        tvCount = Ui.text(this, "", 14, 0xFFCCCCCC);
        topBar.addView(tvCount);
        btnSlide = ibtn(Icons.SLIDESHOW, new View.OnClickListener() {
            public void onClick(View v) {
                toggleSlideshow();
            }
        });
        topBar.addView(sp(btnSlide));
        topBar.addView(sp(btn("Share", new View.OnClickListener() {
            public void onClick(View v) {
                share();
            }
        })));
        topBar.addView(sp(btn("Wallpaper", new View.OnClickListener() {
            public void onClick(View v) {
                useAsWallpaper();
            }
        })));
        root.addView(topBar, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));
        setContentView(root);
    }

    private View ibtn(int icon, View.OnClickListener l) {
        View t = Ui.iconButton(this, icon, 44, 22, 0x33FFFFFF, Color.WHITE);
        t.setOnClickListener(l);
        return t;
    }

    private TextView btn(String s, View.OnClickListener l) {
        TextView t = Ui.button(this, s, 14, 0x33FFFFFF, Color.WHITE);
        t.setOnClickListener(l);
        return t;
    }

    private View sp(View v) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.leftMargin = dp(8);
        v.setLayoutParams(lp);
        return v;
    }

    private void setOverlay(boolean on) {
        overlay = on;
        topBar.setVisibility(on ? View.VISIBLE : View.GONE);
        getWindow().getDecorView().setSystemUiVisibility(on ? View.SYSTEM_UI_FLAG_VISIBLE
                : (View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY));
    }

    private void go(int d) {
        int n = index + d;
        if (n < 0 || n >= list.size()) return;
        show(n);
    }

    private void show(int i) {
        index = i;
        final int my = ++token;
        final Track t = list.get(i);
        tvTitle.setText(t.title);
        tvCount.setText(list.size() > 1 ? (i + 1) + " / " + list.size() : "");
        new Thread(new Runnable() {
            public void run() {
                final Bitmap b = Thumbs.decodeUri(PhotoViewerActivity.this, t.uri, 2048);
                runOnUiThread(new Runnable() {
                    public void run() {
                        if (my != token) return;
                        if (b == null) {
                            Toast.makeText(PhotoViewerActivity.this, "Can't open this image", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        current = b;
                        zv.setBitmapFit(b);
                    }
                });
            }
        }).start();
    }

    private void toggleSlideshow() {
        slideshow = !slideshow;
        Ui.setIcon(btnSlide, slideshow ? Icons.PAUSE : Icons.SLIDESHOW, Color.WHITE);
        h.removeCallbacks(slideRun);
        if (slideshow) {
            setOverlay(false);
            h.postDelayed(slideRun, 4000);
        }
    }

    private final Runnable slideRun = new Runnable() {
        public void run() {
            if (!slideshow) return;
            show((index + 1) % list.size());
            h.postDelayed(this, 4000);
        }
    };

    private void share() {
        try {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("image/*");
            i.putExtra(Intent.EXTRA_STREAM, list.get(index).uri);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(i, "Share photo"));
        } catch (Exception e) {
            Toast.makeText(this, "Can't share this image", Toast.LENGTH_SHORT).show();
        }
    }

    private void useAsWallpaper() {
        if (current == null) return;
        try {
            FileOutputStream out = new FileOutputStream(Prefs.wallpaperFile(this));
            current.compress(Bitmap.CompressFormat.JPEG, 90, out);
            out.close();
            Prefs.putI(this, "wp", (int) (System.currentTimeMillis() / 1000));
            Toast.makeText(this, "Set as Mika wallpaper", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Couldn't set wallpaper", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        h.removeCallbacksAndMessages(null);
    }
}
