package com.mika.launcher;

import java.net.URLDecoder;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Pulls a place out of whatever people share: Google Maps links (long and short), WhatsApp / Telegram locations
 * (geo: and maps links), Waze and OpenStreetMap links, or plain coordinates (decimal or degrees-minutes-seconds).
 * Result: coordinates (hasPoint), or a short link that has to be opened to learn them (shortUrl),
 * or only a name to search for (query). Pure Java - no Android classes - so it can be unit-tested anywhere.
 */
final class MapLink {
    double lat = Double.NaN, lon = Double.NaN;
    /** Place name when known (first line of a Google Maps share, or the /place/NAME/ part of the link). */
    String name;
    /** Address line when the share text has the "Name\nAddress\nlink" layout. */
    String address;
    /** Text to geocode when the link has no coordinates. */
    String query;
    /** Link (maps.app.goo.gl ...) that must be followed to find the coordinates. */
    String shortUrl;

    boolean hasPoint() {
        return !Double.isNaN(lat) && !Double.isNaN(lon);
    }

    private static final String D = "(-?\\d{1,3}\\.\\d+)";
    private static final Pattern URI_RE = Pattern.compile("(?:https?://|geo:|google\\.navigation:)[^\\s<>\"']+", Pattern.CASE_INSENSITIVE);
    private static final Pattern DATA_RE = Pattern.compile("!3d" + D + "!4d" + D);
    private static final Pattern AT_RE = Pattern.compile("@" + D + "," + D);
    private static final Pattern OSM_RE = Pattern.compile("map=\\d+/" + D + "/" + D);
    private static final Pattern PAIR_RE = Pattern.compile("^\\s*\\(?\\s*(?:loc:)?" + "(-?\\d{1,2}\\.\\d+)\\s*[,;/\\s]\\s*(-?\\d{1,3}\\.\\d+)\\s*\\)?\\s*$");
    private static final Pattern PAIR_IN_TEXT_RE = Pattern.compile("(-?\\d{1,2}\\.\\d{3,})\\s*[,;]?\\s*(-?\\d{1,3}\\.\\d{3,})");
    private static final Pattern GEO_Q_LABEL_RE = Pattern.compile("^(.*?)\\((.*)\\)\\s*$");
    private static final Pattern DMS_RE = Pattern.compile(
            "(\\d{1,2})\\s*\u00B0\\s*(\\d{1,2})\\s*['\u2032]\\s*(\\d{1,2}(?:\\.\\d+)?)\\s*[\"\u2033]?\\s*([NSns])[\\s,;]*"
                    + "(\\d{1,3})\\s*\u00B0\\s*(\\d{1,2})\\s*['\u2032]\\s*(\\d{1,2}(?:\\.\\d+)?)\\s*[\"\u2033]?\\s*([EWew])");
    private static final Pattern CENTER_RE = Pattern.compile("center=" + D + "(?:%2C|%2c|,)" + D);

    // ------------------------------------------------------------------------------------------ public API

    /** Parses shared text / a URL / typed coordinates. Never returns null. */
    static MapLink parse(String text) {
        MapLink m = new MapLink();
        if (text == null) return m;
        text = normalize(text).trim();
        if (text.length() == 0) return m;

        Matcher um = URI_RE.matcher(text);
        if (um.find()) {
            String uri = stripTail(um.group());
            fromUri(m, uri);
            // Google Maps shares look like "Name\nAddress\nlink": the first line is the place name
            String pre = text.substring(0, um.start()).trim();
            String preName = cleanName(pre);
            if (preName != null) {
                m.name = preName;
                int pnl = pre.indexOf('\n');
                if (pnl >= 0) {
                    String rest = pre.substring(pnl + 1).trim();
                    int pnl2 = rest.indexOf('\n');
                    if (pnl2 >= 0) rest = rest.substring(0, pnl2).trim();
                    if (rest.length() > 0 && rest.length() < 200) m.address = rest;
                }
            }
            if (!m.hasPoint() && m.shortUrl == null) {
                // no link coordinates: maybe coordinates were written in the text around it
                double[] p = coordsInText(text.replace(uri, " "));
                if (p != null) setPoint(m, p[0], p[1]);
            }
            return m;
        }
        double[] p = coordsWhole(text);
        if (p == null) p = coordsInText(text);
        if (p != null) setPoint(m, p[0], p[1]);
        return m;
    }

    private static final Pattern JSON_LL_RE = Pattern.compile("\"latitude\"\\s*:\\s*" + D + "\\s*,\\s*\"longitude\"\\s*:\\s*" + D);
    private static final Pattern META_LAT_RE = Pattern.compile("place:location:latitude[\"']\\s+content=[\"']" + D + "[\"']");
    private static final Pattern META_LON_RE = Pattern.compile("place:location:longitude[\"']\\s+content=[\"']" + D + "[\"']");

    /**
     * Coordinates in an ordinary Google Maps page. Only data that names the PLACE is trusted (place:location meta tags).
     * The viewport centre (@lat,lon, APP_INITIALIZATION_STATE, ll=) is NOT used: for links without coordinates Google
     * centres it on the viewer's own area, which put the pin next to the user instead of at the shared place.
     */
    static MapLink scanBody(String body) {
        MapLink m = new MapLink();
        if (body == null) return m;
        body = unescape(body);
        Matcher ml = META_LAT_RE.matcher(body);
        Matcher mo = META_LON_RE.matcher(body);
        if (ml.find() && mo.find()) setPoint(m, num(ml.group(1)), num(mo.group(1)));
        return m;
    }

    /** Link-preview page (what chat apps show): its static map is centred on the shared place itself. */
    static MapLink scanPreview(String body) {
        MapLink m = scanBody(body);
        if (m.hasPoint() || body == null) return m;
        body = unescape(body);
        Matcher c = CENTER_RE.matcher(body);
        if (c.find() && setPoint(m, num(c.group(1)), num(c.group(2)))) return m;
        Matcher j = JSON_LL_RE.matcher(body);
        if (j.find()) setPoint(m, num(j.group(1)), num(j.group(2)));
        return m;
    }

    private static final Pattern UNI_RE = Pattern.compile("\\\\u([0-9a-fA-F]{4})");

    /** Undoes the escaping Google uses inside page scripts: \\u003d, \\u0026, \\/ and &amp; */
    static String unescape(String s) {
        if (s.indexOf('\\') >= 0) {
            Matcher m = UNI_RE.matcher(s);
            StringBuffer sb = new StringBuffer();
            while (m.find()) m.appendReplacement(sb, Matcher.quoteReplacement(String.valueOf((char) Integer.parseInt(m.group(1), 16))));
            m.appendTail(sb);
            s = sb.toString().replace("\\/", "/");
        }
        if (s.indexOf("&amp;") >= 0) s = s.replace("&amp;", "&");
        return s;
    }

    // ------------------------------------------------------------------------------------------ internals

    private static void fromUri(MapLink m, String u) {
        String lower = u.toLowerCase(Locale.US);

        // Google's cookie-consent wrapper: the real link is in ?continue=
        if (lower.contains("consent.google.") || lower.contains("consent.youtube.")) {
            String cont = param(u, "continue");
            if (cont != null && cont.length() > 0) {
                fromUri(m, cont);
                return;
            }
        }
        if (lower.startsWith("geo:")) {
            fromGeo(m, u);
            return;
        }
        if (lower.startsWith("google.navigation:")) {
            String q = param("x://x?" + u.substring(u.indexOf(':') + 1), "q");
            fromQueryValue(m, q);
            return;
        }

        String host = host(lower);
        String path = path(u);
        // short links must be opened to find out where they point
        if (host.equals("maps.app.goo.gl") || host.equals("g.co")
                || (host.equals("goo.gl") && path.toLowerCase(Locale.US).startsWith("/maps"))) {
            m.shortUrl = u;
            return;
        }

        String dec = safeDecode(u);

        // 1) the pin itself: !3dLAT!4dLON (last one = destination in /dir/ links)
        double[] pin = lastMatch(DATA_RE, u);
        if (pin == null && !dec.equals(u)) pin = lastMatch(DATA_RE, dec);
        if (pin != null && setPoint(m, pin[0], pin[1])) {
            nameFromPath(m, path);
            return;
        }

        // 2) explicit parameters (Google, WhatsApp, Waze, OSM ...)
        String[] keys = {"q", "query", "ll", "daddr", "destination", "center", "viewpoint", "sll"};
        String textCandidate = null;
        for (String k : keys) {
            String v = param(u, k);
            if (v == null || v.length() == 0) continue;
            double[] p = coordsWhole(v.replaceAll("^loc:", ""));
            if (p == null) {
                Matcher lab = GEO_Q_LABEL_RE.matcher(v);
                if (lab.matches()) {
                    p = coordsWhole(lab.group(1).trim());
                    if (p != null && m.name == null && lab.group(2).trim().length() > 0) m.name = lab.group(2).trim();
                }
            }
            if (p != null && setPoint(m, p[0], p[1])) {
                nameFromPath(m, path);
                return;
            }
            if (textCandidate == null && (k.equals("q") || k.equals("query") || k.equals("daddr") || k.equals("destination"))
                    && !v.startsWith("place_id:")) {
                textCandidate = v;
            }
        }
        String mlat = param(u, "mlat"), mlon = param(u, "mlon");
        if (mlat != null && mlon != null) {
            try {
                if (setPoint(m, Double.parseDouble(mlat), Double.parseDouble(mlon))) return;
            } catch (NumberFormatException ignored) {
            }
        }

        // 3) coordinates written as a path segment: /maps/search/30.04,31.23 , /maps/dir/A/30.04,31.23/ , /maps/place/30.04,31.23
        String[] segs = path.split("/");
        for (int i = segs.length - 1; i >= 0; i--) {
            String s = safeDecode(segs[i]).trim();
            if (s.length() == 0 || s.startsWith("@")) continue;
            double[] p = coordsWhole(s);
            if (p != null && s.indexOf('.') >= 0 && setPoint(m, p[0], p[1])) return;
        }

        // 4) @lat,lon - the map viewport centre, which for a /place/ link is the place
        Matcher a = AT_RE.matcher(dec);
        if (a.find() && setPoint(m, num(a.group(1)), num(a.group(2)))) {
            nameFromPath(m, path);
            return;
        }
        // 5) OpenStreetMap #map=zoom/lat/lon
        Matcher o = OSM_RE.matcher(dec);
        if (o.find() && setPoint(m, num(o.group(1)), num(o.group(2)))) return;

        // 6) nothing numeric: keep a name to search for
        nameFromPath(m, path);
        if (textCandidate != null) m.query = textCandidate.trim();
        else if (m.name != null) m.query = m.name;
    }

    private static void fromGeo(MapLink m, String u) {
        String body = u.substring(4);
        String head = body, qs = "";
        int qi = body.indexOf('?');
        if (qi >= 0) {
            head = body.substring(0, qi);
            qs = body.substring(qi + 1);
        }
        int semi = head.indexOf(';'); // geo:lat,lon;u=20
        if (semi >= 0) head = head.substring(0, semi);
        double[] hp = coordsWhole(head);
        boolean zero = hp != null && hp[0] == 0 && hp[1] == 0;
        String q = param("x://x?" + qs, "q");
        if (q != null && q.length() > 0) {
            Matcher lab = GEO_Q_LABEL_RE.matcher(q);
            String core = q, label = null;
            if (lab.matches()) {
                core = lab.group(1).trim();
                label = lab.group(2).trim();
            }
            double[] qp = coordsWhole(core);
            if (qp != null && setPoint(m, qp[0], qp[1])) {
                if (label != null && label.length() > 0) m.name = label;
                return;
            }
            if (hp != null && !zero && setPoint(m, hp[0], hp[1])) {
                m.name = label != null && label.length() > 0 ? label : core;
                return;
            }
            m.query = core;
            m.name = core;
            return;
        }
        if (hp != null && !zero) setPoint(m, hp[0], hp[1]);
    }

    /** value of ?q= in google.navigation: links (coordinates or a place name). */
    private static void fromQueryValue(MapLink m, String q) {
        if (q == null || q.length() == 0) return;
        double[] p = coordsWhole(q);
        if (p != null) setPoint(m, p[0], p[1]);
        else {
            m.query = q.trim();
            m.name = q.trim();
        }
    }

    private static void nameFromPath(MapLink m, String path) {
        if (m.name != null) return;
        String[] segs = path.split("/");
        for (int i = 0; i < segs.length - 1; i++) {
            if (segs[i].equals("place") || segs[i].equals("search")) {
                String n = safeDecode(segs[i + 1]).trim();
                if (n.length() > 0 && !n.startsWith("@") && coordsWhole(n) == null) {
                    m.name = n;
                    return;
                }
            }
        }
    }

    // ------------------------------------------------------------------------------------------ coordinate helpers

    private static boolean setPoint(MapLink m, double la, double lo) {
        if (la < -90 || la > 90 || lo < -180 || lo > 180) return false;
        if (la == 0 && lo == 0) return false;
        m.lat = la;
        m.lon = lo;
        return true;
    }

    /** The whole string is one coordinate pair: "30.04, 31.23" or degrees-minutes-seconds. */
    private static double[] coordsWhole(String s) {
        if (s == null) return null;
        s = s.trim();
        Matcher m = PAIR_RE.matcher(s);
        if (m.matches()) {
            double la = num(m.group(1)), lo = num(m.group(2));
            if (Math.abs(la) <= 90 && Math.abs(lo) <= 180) return new double[]{la, lo};
        }
        Matcher d = DMS_RE.matcher(s);
        if (d.matches()) return dms(d);
        return null;
    }

    /** A coordinate pair somewhere inside free text (needs at least 3 decimals so it isn't confused with other numbers). */
    private static double[] coordsInText(String s) {
        Matcher d = DMS_RE.matcher(s);
        if (d.find()) {
            double[] p = dms(d);
            if (p != null) return p;
        }
        Matcher m = PAIR_IN_TEXT_RE.matcher(s);
        while (m.find()) {
            double la = num(m.group(1)), lo = num(m.group(2));
            if (Math.abs(la) <= 90 && Math.abs(lo) <= 180) return new double[]{la, lo};
        }
        return null;
    }

    private static double[] dms(Matcher d) {
        double la = num(d.group(1)) + num(d.group(2)) / 60.0 + num(d.group(3)) / 3600.0;
        double lo = num(d.group(5)) + num(d.group(6)) / 60.0 + num(d.group(7)) / 3600.0;
        if (d.group(4).equalsIgnoreCase("S")) la = -la;
        if (d.group(8).equalsIgnoreCase("W")) lo = -lo;
        if (Math.abs(la) > 90 || Math.abs(lo) > 180) return null;
        return new double[]{la, lo};
    }

    private static double[] lastMatch(Pattern p, String s) {
        Matcher m = p.matcher(s);
        double[] r = null;
        while (m.find()) r = new double[]{num(m.group(1)), num(m.group(2))};
        return r;
    }

    private static double num(String s) {
        try {
            return Double.parseDouble(s);
        } catch (NumberFormatException e) {
            return Double.NaN;
        }
    }

    // ------------------------------------------------------------------------------------------ string helpers

    /** Arabic-Indic digits and Arabic comma / decimal mark -> ASCII, so text typed on an Arabic keyboard works. */
    static String normalize(String s) {
        StringBuilder sb = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= '\u0660' && c <= '\u0669') sb.append((char) ('0' + (c - '\u0660')));
            else if (c >= '\u06F0' && c <= '\u06F9') sb.append((char) ('0' + (c - '\u06F0')));
            else if (c == '\u066B') sb.append('.');
            else if (c == '\u060C' || c == '\u066C') sb.append(',');
            else sb.append(c);
        }
        return sb.toString();
    }

    private static String stripTail(String u) {
        while (u.length() > 0 && ".,;:!?)]}>'\"".indexOf(u.charAt(u.length() - 1)) >= 0) {
            // keep a closing ")" that belongs to geo:...(Label)
            if (u.charAt(u.length() - 1) == ')' && u.indexOf('(') >= 0) break;
            u = u.substring(0, u.length() - 1);
        }
        return u;
    }

    private static String cleanName(String pre) {
        if (pre == null) return null;
        String first = pre.trim();
        int nl = first.indexOf('\n');
        // only the multi-line "Name\nAddress\nlink" layout is trusted; a one-line "see <link>" is just chat text
        if (nl < 0) return null;
        first = first.substring(0, nl).trim();
        if (first.length() == 0 || first.length() > 80) return null;
        if (first.endsWith(":") || first.endsWith("\uFF1A")) return null; // "Here is my location:" etc.
        return first;
    }

    private static String host(String lowerUrl) {
        int s = lowerUrl.indexOf("://");
        if (s < 0) return "";
        String rest = lowerUrl.substring(s + 3);
        int e = rest.length();
        for (int i = 0; i < rest.length(); i++) {
            char c = rest.charAt(i);
            if (c == '/' || c == '?' || c == '#' || c == ':') {
                e = i;
                break;
            }
        }
        String h = rest.substring(0, e);
        return h.startsWith("www.") ? h.substring(4) : h;
    }

    private static String path(String u) {
        int s = u.indexOf("://");
        String rest = s >= 0 ? u.substring(s + 3) : u;
        int slash = rest.indexOf('/');
        if (slash < 0) return "";
        String p = rest.substring(slash);
        int cut = p.length();
        int q = p.indexOf('?'), h = p.indexOf('#');
        if (q >= 0) cut = Math.min(cut, q);
        if (h >= 0) cut = Math.min(cut, h);
        return p.substring(0, cut);
    }

    /** Value of a query-string parameter (also looks inside the #fragment, where Waze / OSM sometimes put it). */
    static String param(String url, String key) {
        int h = url.indexOf('#');
        String frag = h >= 0 ? url.substring(h + 1) : "";
        String noFrag = h >= 0 ? url.substring(0, h) : url;
        int q = noFrag.indexOf('?');
        String v = q >= 0 ? findParam(noFrag.substring(q + 1), key) : null;
        if (v == null && frag.length() > 0) v = findParam(frag, key);
        return v;
    }

    private static String findParam(String qs, String key) {
        for (String part : qs.split("&")) {
            int eq = part.indexOf('=');
            if (eq <= 0) continue;
            if (part.substring(0, eq).equals(key)) return safeDecode(part.substring(eq + 1));
        }
        return null;
    }

    private static String safeDecode(String s) {
        try {
            return URLDecoder.decode(s, "UTF-8");
        } catch (Exception e) {
            return s;
        }
    }
}
