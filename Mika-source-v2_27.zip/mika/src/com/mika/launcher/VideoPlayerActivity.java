package com.mika.launcher;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import java.util.ArrayList;
import java.util.List;

/** Full-screen video player with resume, skip +/-10s and next/previous. */
public class VideoPlayerActivity extends Activity {

    static List<Track> items = new ArrayList<Track>();
    static int startIndex = 0;

    private VideoView vv;
    private LinearLayout topBar, bottomBar;
    private SeekBar seek;
    private TextView tvTitle, tvTime;
    private View btnPlay;
    private final Handler h = new Handler();
    private int index = 0;
    private boolean seeking = false;
    private boolean controls = true;
    private long lastTouch = 0;
    private int ticks = 0;
    private AudioManager am;
    private List<Track> list = new ArrayList<Track>();

    private int dp(int v) {
        return Ui.dp(this, v);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.cutout(this);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        Intent in = getIntent();
        if (Intent.ACTION_VIEW.equals(in.getAction()) && in.getData() != null) {
            list.add(Track.fromUri(this, in.getData()));
            index = 0;
        } else {
            list.addAll(items);
            index = Math.max(0, Math.min(startIndex, list.size() - 1));
        }
        if (list.isEmpty()) {
            finish();
            return;
        }
        PlayerService.pauseIfPlaying();
        build();
        play(index);
    }

    private void build() {
        Pal pal = Pal.of(this);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        vv = new VideoView(this);
        root.addView(vv, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
        root.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                showControls(!controls);
            }
        });
        vv.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                showControls(!controls);
            }
        });

        topBar = new LinearLayout(this);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setBackgroundColor(0x99000000);
        topBar.setPadding(dp(12), dp(10), dp(12), dp(10));
        View back = Ui.iconButton(this, Icons.BACK, 44, 22, 0x33FFFFFF, Color.WHITE);
        back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        });
        topBar.addView(back);
        tvTitle = Ui.text(this, "", 17, Color.WHITE);
        tvTitle.setSingleLine(true);
        tvTitle.setEllipsize(TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0, -2, 1f);
        tl.leftMargin = dp(12);
        topBar.addView(tvTitle, tl);
        root.addView(topBar, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));

        bottomBar = new LinearLayout(this);
        bottomBar.setOrientation(LinearLayout.VERTICAL);
        bottomBar.setBackgroundColor(0x99000000);
        bottomBar.setPadding(dp(14), dp(8), dp(14), dp(12));
        LinearLayout sRow = new LinearLayout(this);
        sRow.setGravity(Gravity.CENTER_VERTICAL);
        tvTime = Ui.text(this, "0:00 / 0:00", 13, Color.WHITE);
        seek = new SeekBar(this);
        seek.setProgressTintList(ColorStateList.valueOf(pal.accent));
        seek.setThumbTintList(ColorStateList.valueOf(pal.accent));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean user) {
                if (user) tvTime.setText(Track.fmt(p) + " / " + Track.fmt(vv.getDuration()));
            }

            public void onStartTrackingTouch(SeekBar s) {
                seeking = true;
            }

            public void onStopTrackingTouch(SeekBar s) {
                seeking = false;
                vv.seekTo(s.getProgress());
            }
        });
        sRow.addView(seek, new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout.LayoutParams ttl = new LinearLayout.LayoutParams(-2, -2);
        ttl.leftMargin = dp(10);
        sRow.addView(tvTime, ttl);
        bottomBar.addView(sRow, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout ctrl = new LinearLayout(this);
        ctrl.setGravity(Gravity.CENTER);
        ctrl.addView(vbtn(Icons.PREV, new View.OnClickListener() {
            public void onClick(View v) {
                if (index > 0) play(index - 1);
            }
        }));
        ctrl.addView(vbtn(Icons.REPLAY10, new View.OnClickListener() {
            public void onClick(View v) {
                vv.seekTo(Math.max(0, vv.getCurrentPosition() - 10000));
            }
        }));
        btnPlay = Ui.iconButton(this, Icons.PAUSE, 66, 34, pal.accent, Color.WHITE);
        btnPlay.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (vv.isPlaying()) vv.pause();
                else vv.start();
                updatePlayBtn();
            }
        });
        LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(-2, -2);
        pl.leftMargin = dp(8);
        pl.rightMargin = dp(8);
        ctrl.addView(btnPlay, pl);
        ctrl.addView(vbtn(Icons.FORWARD10, new View.OnClickListener() {
            public void onClick(View v) {
                vv.seekTo(Math.min(vv.getDuration(), vv.getCurrentPosition() + 10000));
            }
        }));
        ctrl.addView(vbtn(Icons.NEXT, new View.OnClickListener() {
            public void onClick(View v) {
                if (index + 1 < list.size()) play(index + 1);
            }
        }));
        bottomBar.addView(ctrl, new LinearLayout.LayoutParams(-2, -2));
        ((LinearLayout.LayoutParams) ctrl.getLayoutParams()).gravity = Gravity.CENTER_HORIZONTAL;
        root.addView(bottomBar, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));
        setContentView(root);
        hideBars();
    }

    private View vbtn(int icon, View.OnClickListener l) {
        View t = Ui.iconButton(this, icon, 48, 24, 0x33FFFFFF, Color.WHITE);
        t.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.leftMargin = dp(6);
        lp.rightMargin = dp(6);
        t.setLayoutParams(lp);
        return t;
    }

    @SuppressWarnings("deprecation")
    private void play(int i) {
        saveProgress();
        index = i;
        final Track t = list.get(i);
        tvTitle.setText(t.title);
        am.requestAudioFocus(null, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
        vv.setVideoURI(t.uri);
        vv.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            public void onPrepared(MediaPlayer mp) {
                int dur = vv.getDuration();
                seek.setMax(Math.max(1, dur));
                int saved = Prefs.counts(VideoPlayerActivity.this).getInt("vpos_" + t.id, 0);
                if (saved > 5000 && saved < dur - 5000) vv.seekTo(saved);
                vv.start();
                updatePlayBtn();
            }
        });
        vv.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            public void onCompletion(MediaPlayer mp) {
                Prefs.counts(VideoPlayerActivity.this).edit().remove("vpos_" + t.id).apply();
                if (index + 1 < list.size()) play(index + 1);
                else {
                    Ui.setIcon(btnPlay, Icons.PLAY, Color.WHITE);
                    showControls(true);
                }
            }
        });
        vv.setOnErrorListener(new MediaPlayer.OnErrorListener() {
            public boolean onError(MediaPlayer mp, int what, int extra) {
                Toast.makeText(VideoPlayerActivity.this, "Can't play this video", Toast.LENGTH_SHORT).show();
                finish();
                return true;
            }
        });
        showControls(true);
    }

    private void saveProgress() {
        if (vv == null || index >= list.size()) return;
        try {
            int pos = vv.getCurrentPosition();
            if (pos > 0) Prefs.counts(this).edit().putInt("vpos_" + list.get(index).id, pos).apply();
        } catch (Exception ignored) {
        }
    }

    private void updatePlayBtn() {
        Ui.setIcon(btnPlay, vv.isPlaying() ? Icons.PAUSE : Icons.PLAY, Color.WHITE);
    }

    private void showControls(boolean show) {
        controls = show;
        topBar.setVisibility(show ? View.VISIBLE : View.GONE);
        bottomBar.setVisibility(show ? View.VISIBLE : View.GONE);
        lastTouch = System.currentTimeMillis();
        if (!show) hideBars();
    }

    private void hideBars() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    private final Runnable ticker = new Runnable() {
        public void run() {
            try {
                if (!seeking && vv.getDuration() > 0) {
                    seek.setProgress(vv.getCurrentPosition());
                    tvTime.setText(Track.fmt(vv.getCurrentPosition()) + " / " + Track.fmt(vv.getDuration()));
                }
                updatePlayBtn();
                if (controls && vv.isPlaying() && System.currentTimeMillis() - lastTouch > 3500) showControls(false);
                if (++ticks % 10 == 0) saveProgress();
            } catch (Exception ignored) {
            }
            h.postDelayed(this, 500);
        }
    };

    @Override
    protected void onResume() {
        super.onResume();
        h.post(ticker);
    }

    @Override
    protected void onPause() {
        super.onPause();
        saveProgress();
        h.removeCallbacks(ticker);
        if (vv != null) vv.pause();
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onDestroy() {
        super.onDestroy();
        try {
            am.abandonAudioFocus(null);
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (f && !controls) hideBars();
    }
}
