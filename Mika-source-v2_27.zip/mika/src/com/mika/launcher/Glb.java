package com.mika.launcher;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import org.json.JSONArray;
import org.json.JSONObject;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.List;

/**
 * Minimal binary-glTF (.glb) reader for the car model: positions + vertex colours, no textures.
 * Output is flat-shaded, un-indexed triangles (pos3, normal3, colour3 + emissive flag), split into
 * a body group and four wheel groups (so the wheels can spin). Model space: X forward, Y left, Z up.
 */
final class Glb {
    static final int STRIDE = 10;

    static final class Group {
        float[] v = new float[0];
        int count;            // number of vertices
        float px, py, pz;     // pivot (wheel centre)
    }

    Group body = new Group();
    Group[] wheels = new Group[4];
    float wheelRadius = 0.35f;
    /** Lit lamps in model space: {x, y, z, type} with type 1 = head lamp, 2 = tail lamp, 3 = amber corner lamp. */
    float[][] lamps = new float[0][];
    float minX, maxX, minY, maxY, minZ, maxZ;

    private static final class Mesh {
        String name;
        float[] pos, col;
        int[] idx;
        float[] triEmis; // optional per-triangle emissive flag (atlas models)
    }

    /** Crease angle (as a cosine) for smoothing the car normals while parsing; below -1 = flat shading. */
    private static float creaseCos = -2f;

    static Glb parse(byte[] data) throws Exception {
        return parse(data, false);
    }

    /** smooth = true: curved panels and tyres get smooth normals (faces up to ~38 degrees apart blend, sharper edges stay sharp). */
    static Glb parse(byte[] data, boolean smooth) throws Exception {
        creaseCos = smooth ? 0.78f : -2f;
        try {
            return parseInner(data);
        } finally {
            creaseCos = -2f;
        }
    }

    private static Glb parseInner(byte[] data) throws Exception {
        ByteBuffer bb = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN);
        if (bb.getInt(0) != 0x46546C67) throw new Exception("not a glb");
        int off = 12;
        JSONObject json = null;
        int binOff = -1;
        while (off + 8 <= data.length) {
            int len = bb.getInt(off);
            int type = bb.getInt(off + 4);
            if (type == 0x4E4F534A) json = new JSONObject(new String(data, off + 8, len, "UTF-8"));
            else if (type == 0x004E4942 && binOff < 0) binOff = off + 8;
            off += 8 + ((len + 3) & ~3);
        }
        if (json == null || binOff < 0) throw new Exception("bad glb");

        JSONArray accessors = json.getJSONArray("accessors");
        JSONArray views = json.getJSONArray("bufferViews");
        JSONArray nodes = json.getJSONArray("nodes");
        JSONArray meshes = json.getJSONArray("meshes");

        if (isAtlasModel(json, nodes, meshes)) return parseAtlas(bb, binOff, json, accessors, views, nodes, meshes);

        List<Mesh> list = new ArrayList<Mesh>();
        for (int i = 0; i < nodes.length(); i++) {
            JSONObject n = nodes.getJSONObject(i);
            if (!n.has("mesh")) continue;
            JSONObject m = meshes.getJSONObject(n.getInt("mesh"));
            JSONObject prim = m.getJSONArray("primitives").getJSONObject(0);
            if (prim.optInt("mode", 4) != 4) continue;
            JSONObject at = prim.getJSONObject("attributes");
            Mesh me = new Mesh();
            me.name = n.optString("name", "");
            me.pos = readFloats(bb, binOff, accessors, views, at.getInt("POSITION"), 3);
            me.col = at.has("COLOR_0") ? readFloats(bb, binOff, accessors, views, at.getInt("COLOR_0"), 4) : null;
            me.idx = prim.has("indices") ? readIndices(bb, binOff, accessors, views, prim.getInt("indices")) : null;
            list.add(me);
        }

        Glb g = new Glb();
        g.minX = g.minY = g.minZ = 1e9f;
        g.maxX = g.maxY = g.maxZ = -1e9f;
        List<float[]> bodyParts = new ArrayList<float[]>();
        List<List<float[]>> wheelParts = new ArrayList<List<float[]>>();
        float[][] wb = new float[4][]; // bbox of the largest mesh of each wheel (the tyre)
        for (int i = 0; i < 4; i++) wheelParts.add(new ArrayList<float[]>());

        for (Mesh me : list) {
            float[] bb6 = bbox(me.pos);
            String low = me.name.toLowerCase();
            boolean wheel = low.startsWith("part") || low.startsWith("wheel");
            float emis = low.contains("headlamp") ? 1f : (low.contains("tail lamp") || low.contains("rear light")) ? 2f : 0f;
            float[] tri = triangles(me, emis);
            if (!wheel) {
                bodyParts.add(tri);
                g.minX = Math.min(g.minX, bb6[0]);
                g.minY = Math.min(g.minY, bb6[1]);
                g.minZ = Math.min(g.minZ, bb6[2]);
                g.maxX = Math.max(g.maxX, bb6[3]);
                g.maxY = Math.max(g.maxY, bb6[4]);
                g.maxZ = Math.max(g.maxZ, bb6[5]);
            } else {
                float cx = (bb6[0] + bb6[3]) / 2, cy = (bb6[1] + bb6[4]) / 2;
                int w = (cx > 0 ? 2 : 0) + (cy > 0 ? 1 : 0);
                wheelParts.get(w).add(tri);
                float size = bb6[3] - bb6[0];
                if (wb[w] == null || size > wb[w][3] - wb[w][0]) wb[w] = bb6;
            }
        }
        g.body = pack(bodyParts);
        for (int w = 0; w < 4; w++) {
            g.wheels[w] = pack(wheelParts.get(w));
            if (wb[w] != null) {
                g.wheels[w].px = (wb[w][0] + wb[w][3]) / 2;
                g.wheels[w].py = (wb[w][1] + wb[w][4]) / 2;
                g.wheels[w].pz = (wb[w][2] + wb[w][5]) / 2;
                g.wheelRadius = (wb[w][3] - wb[w][0]) / 2;
                g.minZ = Math.min(g.minZ, wb[w][2]);
            }
        }
        g.lamps = findLamps(g.body);
        return g;
    }


    // =================================================================== atlas models (single mesh + colour-strip texture)
    /** One mesh, Y-up, a base-colour texture and no separate wheel nodes (e.g. the "Hyper GT" low-poly car). */
    private static boolean isAtlasModel(JSONObject json, JSONArray nodes, JSONArray meshes) throws Exception {
        if (!json.has("images") || json.getJSONArray("images").length() == 0) return false;
        int withMesh = 0;
        for (int i = 0; i < nodes.length(); i++) {
            JSONObject n = nodes.getJSONObject(i);
            if (!n.has("mesh")) continue;
            withMesh++;
            String low = n.optString("name", "").toLowerCase();
            if (low.startsWith("part") || low.startsWith("wheel")) return false;
            JSONObject at = meshes.getJSONObject(n.getInt("mesh")).getJSONArray("primitives").getJSONObject(0).getJSONObject("attributes");
            if (!at.has("TEXCOORD_0")) return false;
        }
        return withMesh == 1;
    }

    // Wheel layout of that model, in its own glTF space (Y up, front = +Z): centres (z, y), tyre radius.
    // Measured from the tyre / rim meshes: rear (z, y) and front (z, y) wheel centres, tyre radius (rear tyres are bigger).
    private static final float[][] ATLAS_WHEELS = {{-1.3130f, 0.2270f}, {1.3700f, 0.1930f}};
    private static final float[] ATLAS_WHEEL_R = {0.43f, 0.40f}; // search radius around each centre (tyre + a little)
    private static final float ATLAS_TYRE_R = 0.392f;           // mean tyre radius, sets the spin rate

    private static int find(int[] p, int x) {
        while (p[x] != x) {
            p[x] = p[p[x]];
            x = p[x];
        }
        return x;
    }

    private static Glb parseAtlas(ByteBuffer bb, int binOff, JSONObject json, JSONArray accessors, JSONArray views,
                                  JSONArray nodes, JSONArray meshes) throws Exception {
        JSONObject node = null;
        for (int i = 0; i < nodes.length(); i++) if (nodes.getJSONObject(i).has("mesh")) node = nodes.getJSONObject(i);
        JSONObject prim = meshes.getJSONObject(node.getInt("mesh")).getJSONArray("primitives").getJSONObject(0);
        JSONObject at = prim.getJSONObject("attributes");
        float[] pos = readFloats(bb, binOff, accessors, views, at.getInt("POSITION"), 3);
        float[] uv = readFloats(bb, binOff, accessors, views, at.getInt("TEXCOORD_0"), 2);
        int[] idx = readIndices(bb, binOff, accessors, views, prim.getInt("indices"));
        int nv = pos.length / 3;

        // ---- the colour atlas -> one colour per vertex (the renderer has no textures)
        JSONObject iv = json.getJSONArray("images").getJSONObject(0);
        JSONObject bv = views.getJSONObject(iv.getInt("bufferView"));
        int io = binOff + bv.optInt("byteOffset", 0);
        byte[] png = new byte[bv.getInt("byteLength")];
        for (int i = 0; i < png.length; i++) png[i] = bb.get(io + i);
        Bitmap bmp = BitmapFactory.decodeByteArray(png, 0, png.length);
        if (bmp == null) throw new Exception("bad texture");
        int tw = bmp.getWidth(), th = bmp.getHeight();
        int[] px = new int[tw * th];
        bmp.getPixels(px, 0, tw, 0, 0, tw, th);
        bmp.recycle();

        float[] col = new float[nv * 4];
        int[] strip = new int[nv];
        for (int i = 0; i < nv; i++) {
            float u = uv[i * 2], v = uv[i * 2 + 1];
            float fx = Math.max(0, Math.min(tw - 1, u * tw - 0.5f)), fy = Math.max(0, Math.min(th - 1, v * th - 0.5f));
            int x0 = (int) fx, y0 = (int) fy, x1 = Math.min(tw - 1, x0 + 1), y1 = Math.min(th - 1, y0 + 1);
            float ax = fx - x0, ay = fy - y0;
            for (int k = 0; k < 3; k++) {
                int sh = 16 - 8 * k;
                float c00 = (px[y0 * tw + x0] >> sh) & 0xFF, c10 = (px[y0 * tw + x1] >> sh) & 0xFF;
                float c01 = (px[y1 * tw + x0] >> sh) & 0xFF, c11 = (px[y1 * tw + x1] >> sh) & 0xFF;
                col[i * 4 + k] = ((c00 * (1 - ax) + c10 * ax) * (1 - ay) + (c01 * (1 - ax) + c11 * ax) * ay) / 255f;
            }
            col[i * 4 + 3] = 1f;
            strip[i] = (int) (Math.min(0.9999f, Math.max(0f, u)) * 14f) + (v > 0.5f ? 14 : 0); // atlas = 2 rows x 14 strips
        }
        // glass strip: deepen the cyan so it reads as tinted glass
        for (int i = 0; i < nv; i++) {
            if (strip[i] == 25) {
                col[i * 4] *= 0.42f;
                col[i * 4 + 1] *= 0.5f;
                col[i * 4 + 2] *= 0.62f;
            }
        }

        // ---- glTF (X right, Y up, Z front)  ->  model space (X forward, Y left, Z up), grounded and centred
        float[] mp = new float[pos.length];
        float minX = 1e9f, maxX = -1e9f, minZ = 1e9f;
        for (int i = 0; i < nv; i++) {
            mp[i * 3] = pos[i * 3 + 2];
            mp[i * 3 + 1] = pos[i * 3];
            mp[i * 3 + 2] = pos[i * 3 + 1];
            minX = Math.min(minX, mp[i * 3]);
            maxX = Math.max(maxX, mp[i * 3]);
            minZ = Math.min(minZ, mp[i * 3 + 2]);
        }
        float shX = -(minX + maxX) / 2f, shZ = 0.035f - minZ;
        for (int i = 0; i < nv; i++) {
            mp[i * 3] += shX;
            mp[i * 3 + 2] += shZ;
        }

        // ---- split triangles: 4 wheels (tyre + rim, so they can spin), the rest is the body
        int nt = idx.length / 3;
        int[] owner = new int[nt]; // -1 body, else wheel index 0..3
        int[] cnt = new int[5];
        float[][] wsum = new float[4][3];
        for (int t = 0; t < nt; t++) {
            owner[t] = -1;
            for (int wi = 0; wi < ATLAS_WHEELS.length && owner[t] < 0; wi++) {
                float zc = ATLAS_WHEELS[wi][0], yc = ATLAS_WHEELS[wi][1];
                boolean in = true;
                float minAx = 1e9f, sx = 0f;
                for (int k = 0; k < 3; k++) {
                    int vi = idx[t * 3 + k];
                    float gx = pos[vi * 3], gy = pos[vi * 3 + 1], gz = pos[vi * 3 + 2];
                    if (Math.hypot(gy - yc, gz - zc) > ATLAS_WHEEL_R[wi]) in = false;
                    minAx = Math.min(minAx, Math.abs(gx));
                    sx += gx / 3f;
                }
                if (in && minAx > 0.55f) {
                    int w = (zc > 0 ? 2 : 0) + (sx > 0 ? 1 : 0);
                    owner[t] = w;
                }
            }
        }

        // Body panels that merely overlap the wheel circle (fender paint, side markers) must not spin with the wheel:
        // split the wheel candidates into connected pieces; a piece that has body paint / marker-lamp colours goes back to the body.
        {
            java.util.HashMap<Long, Integer> kid = new java.util.HashMap<Long, Integer>();
            int[] vk = new int[nv];
            java.util.Arrays.fill(vk, -1);
            int[] par = new int[nt * 3 + 3];
            int np = 0;
            for (int t = 0; t < nt; t++) {
                if (owner[t] < 0) continue;
                for (int k = 0; k < 3; k++) {
                    int vi = idx[t * 3 + k];
                    if (vk[vi] >= 0) continue;
                    long key = ((long) (Math.round(pos[vi * 3] * 500f) & 0x1FFFFF) << 42)
                            | ((long) (Math.round(pos[vi * 3 + 1] * 500f) & 0x1FFFFF) << 21)
                            | (long) (Math.round(pos[vi * 3 + 2] * 500f) & 0x1FFFFF);
                    Integer id = kid.get(key);
                    if (id == null) {
                        id = Integer.valueOf(np);
                        par[np] = np;
                        np++;
                        kid.put(key, id);
                    }
                    vk[vi] = id.intValue();
                }
            }
            for (int t = 0; t < nt; t++) {
                if (owner[t] < 0) continue;
                int ra = find(par, vk[idx[t * 3]]);
                for (int k = 1; k < 3; k++) {
                    int rb = find(par, vk[idx[t * 3 + k]]);
                    if (rb != ra) par[rb] = ra;
                }
            }
            boolean[] bad = new boolean[np + 1];
            for (int t = 0; t < nt; t++) {
                if (owner[t] < 0) continue;
                int s = strip[idx[t * 3]];
                if (s == 4 || s == 26) bad[find(par, vk[idx[t * 3]])] = true;
            }
            // a real wheel piece (tyre, rim, hub cap) is centred on the axle: off-centre pieces are arch liners / trim
            float[] y0 = new float[np + 1], y1 = new float[np + 1], z0 = new float[np + 1], z1 = new float[np + 1];
            int[] cw = new int[np + 1];
            java.util.Arrays.fill(y0, 1e9f);
            java.util.Arrays.fill(z0, 1e9f);
            java.util.Arrays.fill(y1, -1e9f);
            java.util.Arrays.fill(z1, -1e9f);
            java.util.Arrays.fill(cw, -1);
            for (int t = 0; t < nt; t++) {
                if (owner[t] < 0) continue;
                int r = find(par, vk[idx[t * 3]]);
                cw[r] = owner[t];
                for (int k = 0; k < 3; k++) {
                    int vi = idx[t * 3 + k];
                    y0[r] = Math.min(y0[r], pos[vi * 3 + 1]);
                    y1[r] = Math.max(y1[r], pos[vi * 3 + 1]);
                    z0[r] = Math.min(z0[r], pos[vi * 3 + 2]);
                    z1[r] = Math.max(z1[r], pos[vi * 3 + 2]);
                }
            }
            for (int r = 0; r < np; r++) {
                if (cw[r] < 0) continue;
                float zc = ATLAS_WHEELS[cw[r] >= 2 ? 1 : 0][0], yc = ATLAS_WHEELS[cw[r] >= 2 ? 1 : 0][1];
                if (Math.hypot((y0[r] + y1[r]) / 2f - yc, (z0[r] + z1[r]) / 2f - zc) > 0.06) bad[r] = true;
            }
            for (int t = 0; t < nt; t++) {
                if (owner[t] >= 0 && bad[find(par, vk[idx[t * 3]])]) owner[t] = -1;
            }
        }
        for (int t = 0; t < nt; t++) cnt[owner[t] + 1]++;

        Glb g = new Glb();
        g.minX = minX + shX;
        g.maxX = maxX + shX;
        float[] lim = {1e9f, -1e9f, 1e9f, -1e9f};
        for (int i = 0; i < nv; i++) {
            lim[0] = Math.min(lim[0], mp[i * 3 + 1]);
            lim[1] = Math.max(lim[1], mp[i * 3 + 1]);
            lim[2] = Math.min(lim[2], mp[i * 3 + 2]);
            lim[3] = Math.max(lim[3], mp[i * 3 + 2]);
        }
        g.minY = lim[0];
        g.maxY = lim[1];
        g.minZ = lim[2];
        g.maxZ = lim[3];

        for (int w = -1; w < 4; w++) {
            Mesh me = new Mesh();
            me.pos = mp;
            me.col = col;
            int[] ids = new int[cnt[w + 1] * 3];
            float[] em = new float[cnt[w + 1]];
            int o = 0, e = 0;
            float sy = 0f;
            int sn = 0;
            for (int t = 0; t < nt; t++) {
                if (owner[t] != w) continue;
                float cz = 0f, cx = 0f;
                for (int k = 0; k < 3; k++) {
                    int vi = idx[t * 3 + k];
                    ids[o++] = vi;
                    cx += pos[vi * 3 + 2] / 3f; // glTF z = forward
                    cz += pos[vi * 3 + 1] / 3f;
                    if (w >= 0) {
                        sy += mp[vi * 3 + 1];
                        sn++;
                    }
                }
                // emissive: tail lamps (red-orange strip, rear), head lamps (white / peach strips at the nose)
                int s0 = strip[idx[t * 3]];
                float f = 0f;
                if (s0 == 4) f = -1f; // body paint: recoloured at draw time (car page colour swatches)
                else if (s0 == 27 || (s0 == 26 && cx < -2.0f)) f = 2f;
                else if ((s0 == 26 || s0 == 12) && cx > 1.5f) {
                    f = 1f;
                    int c0 = idx[t * 3];
                    // orange corner / indicator lens: it is not a head-lamp bulb, so it keeps its own warm amber light (flag 3)
                    if (col[c0 * 4] > 0.85f && col[c0 * 4 + 2] < 0.5f) f = 3f;
                }
                em[e++] = f;
            }
            me.idx = ids;
            me.triEmis = em;
            float[] tri = triangles(me, 0f);
            if (w < 0) {
                g.body = pack(java.util.Collections.singletonList(tri));
            } else {
                g.wheels[w] = pack(java.util.Collections.singletonList(tri));
                float zc = ATLAS_WHEELS[w >= 2 ? 1 : 0][0], yc = ATLAS_WHEELS[w >= 2 ? 1 : 0][1];
                g.wheels[w].px = zc + shX;
                g.wheels[w].py = sn > 0 ? sy / sn : 0f;
                g.wheels[w].pz = yc + shZ;
            }
        }
        g.wheelRadius = ATLAS_TYRE_R;
        g.lamps = findLamps(g.body);
        return g;
    }

    /** Cluster the emissive vertices into individual lamps: per type and side, split along the width into two. */
    private static float[][] findLamps(Group body) {
        List<float[]> out = new ArrayList<float[]>();
        for (int type = 1; type <= 3; type++) {
            for (int side = -1; side <= 1; side += 2) {
                double sx = 0, sy = 0, sz = 0;
                int n = 0;
                for (int i = 0; i < body.v.length; i += STRIDE) {
                    if ((int) body.v[i + 9] != type || body.v[i + 1] * side <= 0f) continue;
                    sx += body.v[i];
                    sy += body.v[i + 1];
                    sz += body.v[i + 2];
                    n++;
                }
                if (n == 0) continue;
                float my = (float) (sy / n);
                for (int half = 0; half < (type == 3 ? 1 : 2); half++) {
                    double hx = 0, hy = 0, hz = 0;
                    int hn = 0;
                    for (int i = 0; i < body.v.length; i += STRIDE) {
                        if ((int) body.v[i + 9] != type || body.v[i + 1] * side <= 0f) continue;
                        if (type != 3 && (body.v[i + 1] < my) != (half == 0)) continue;
                        hx += body.v[i];
                        hy += body.v[i + 1];
                        hz += body.v[i + 2];
                        hn++;
                    }
                    if (hn > 0) out.add(new float[]{(float) (hx / hn), (float) (hy / hn), (float) (hz / hn), type});
                }
            }
        }
        return out.toArray(new float[0][]);
    }

    private static Group pack(List<float[]> parts) {
        int n = 0;
        for (float[] p : parts) n += p.length;
        Group gr = new Group();
        gr.v = new float[n];
        int o = 0;
        for (float[] p : parts) {
            System.arraycopy(p, 0, gr.v, o, p.length);
            o += p.length;
        }
        gr.count = n / STRIDE;
        return gr;
    }

    private static float[] bbox(float[] p) {
        float[] b = {1e9f, 1e9f, 1e9f, -1e9f, -1e9f, -1e9f};
        for (int i = 0; i < p.length; i += 3) {
            for (int k = 0; k < 3; k++) {
                b[k] = Math.min(b[k], p[i + k]);
                b[k + 3] = Math.max(b[k + 3], p[i + k]);
            }
        }
        return b;
    }

    private static float[] triangles(Mesh m, float emis) {
        int nIdx = m.idx != null ? m.idx.length : m.pos.length / 3;
        int tris = nIdx / 3;
        float[] out = new float[tris * 3 * STRIDE];
        int o = 0;
        for (int t = 0; t < tris; t++) {
            int[] id = new int[3];
            for (int k = 0; k < 3; k++) id[k] = m.idx != null ? m.idx[t * 3 + k] : t * 3 + k;
            float ax = m.pos[id[0] * 3], ay = m.pos[id[0] * 3 + 1], az = m.pos[id[0] * 3 + 2];
            float bx = m.pos[id[1] * 3], by = m.pos[id[1] * 3 + 1], bz = m.pos[id[1] * 3 + 2];
            float cx = m.pos[id[2] * 3], cy = m.pos[id[2] * 3 + 1], cz = m.pos[id[2] * 3 + 2];
            float ux = bx - ax, uy = by - ay, uz = bz - az, vx = cx - ax, vy = cy - ay, vz = cz - az;
            float nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
            float l = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
            if (l < 1e-9f) continue;
            nx /= l;
            ny /= l;
            nz /= l;
            for (int k = 0; k < 3; k++) {
                int vi = id[k];
                out[o++] = m.pos[vi * 3];
                out[o++] = m.pos[vi * 3 + 1];
                out[o++] = m.pos[vi * 3 + 2];
                out[o++] = nx;
                out[o++] = ny;
                out[o++] = nz;
                if (m.col != null) {
                    out[o++] = m.col[vi * 4];
                    out[o++] = m.col[vi * 4 + 1];
                    out[o++] = m.col[vi * 4 + 2];
                } else {
                    out[o++] = 0.7f;
                    out[o++] = 0.7f;
                    out[o++] = 0.7f;
                }
                out[o++] = m.triEmis != null ? m.triEmis[t] : emis;
            }
        }
        float[] res = out;
        if (o != out.length) {
            res = new float[o];
            System.arraycopy(out, 0, res, 0, o);
        }
        if (creaseCos > -1.5f) MeshSmooth.smooth(res, res.length, STRIDE, 3, creaseCos);
        return res;
    }

    // ------------------------------------------------------------- accessors
    private static float[] readFloats(ByteBuffer bb, int binOff, JSONArray acc, JSONArray views, int ai, int want) throws Exception {
        JSONObject a = acc.getJSONObject(ai);
        JSONObject v = views.getJSONObject(a.getInt("bufferView"));
        String ty = a.getString("type");
        int comps = ty.equals("VEC4") ? 4 : ty.equals("VEC3") ? 3 : ty.equals("VEC2") ? 2 : 1;
        int ct = a.getInt("componentType");
        int count = a.getInt("count");
        int csize = (ct == 5126 || ct == 5125) ? 4 : (ct == 5123 || ct == 5122) ? 2 : 1;
        int stride = v.optInt("byteStride", comps * csize);
        int base = binOff + v.optInt("byteOffset", 0) + a.optInt("byteOffset", 0);
        boolean norm = a.optBoolean("normalized", false);
        float[] out = new float[count * want];
        for (int i = 0; i < count; i++) {
            for (int k = 0; k < want; k++) {
                float val;
                if (k >= comps) {
                    val = 1f;
                } else {
                    int p = base + i * stride + k * csize;
                    if (ct == 5126) val = bb.getFloat(p);
                    else if (ct == 5121) {
                        int x = bb.get(p) & 0xFF;
                        val = norm ? x / 255f : x;
                    } else if (ct == 5123) {
                        int x = bb.getShort(p) & 0xFFFF;
                        val = norm ? x / 65535f : x;
                    } else throw new Exception("unsupported component type " + ct);
                }
                out[i * want + k] = val;
            }
        }
        return out;
    }

    private static int[] readIndices(ByteBuffer bb, int binOff, JSONArray acc, JSONArray views, int ai) throws Exception {
        JSONObject a = acc.getJSONObject(ai);
        JSONObject v = views.getJSONObject(a.getInt("bufferView"));
        int ct = a.getInt("componentType");
        int count = a.getInt("count");
        int base = binOff + v.optInt("byteOffset", 0) + a.optInt("byteOffset", 0);
        int[] out = new int[count];
        for (int i = 0; i < count; i++) {
            if (ct == 5125) out[i] = bb.getInt(base + i * 4);
            else if (ct == 5123) out[i] = bb.getShort(base + i * 2) & 0xFFFF;
            else out[i] = bb.get(base + i) & 0xFF;
        }
        return out;
    }
}
