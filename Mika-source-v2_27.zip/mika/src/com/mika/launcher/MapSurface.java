package com.mika.launcher;

import android.location.Location;

import java.util.List;

/**
 * Common API of the two map engines: {@link VectorMapView} (MapLibre GL in a WebView, Mapbox-style vector map)
 * and {@link MapView} (classic OpenStreetMap raster tiles, used as a fallback). Zoom values use the raster scale
 * (z15 = street level) for both engines.
 */
interface MapSurface {
    void setListener(MapView.Listener l);

    void setInteractive(boolean b);

    void setNight(boolean b);

    void setAccent(int c);

    void setMe(Location l);

    void setPin(double lat, double lon);

    void clearPin();

    boolean hasPin();

    void setSaved(List<double[]> s);

    void setCenter(double lat, double lon);

    void setZoom(float z);

    float getZoom();

    void zoomBy(float dz);

    double centerLat();

    double centerLon();

    /** Smooth camera move to a place. */
    void flyTo(double lat, double lon, float zoom);

    // ---- vector-only extras (no-ops on the raster engine)
    boolean isVector();

    /** Keeps the camera on the car; rotates the map with the heading when heading-up is on. */
    void followTo(double lat, double lon, float bearing, boolean moving);

    void setTilt(boolean on);

    boolean isTilted();

    void setHeadingUp(boolean on);

    void resetNorth();

    void setSatellite(boolean on);

    boolean isSatellite();

    // ---- route line (lat, lon pairs)
    void setRoute(List<double[]> latLon);

    void clearRoute();

    void fitRoute();
}
