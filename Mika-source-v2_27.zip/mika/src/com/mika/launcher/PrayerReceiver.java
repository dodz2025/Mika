package com.mika.launcher;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;

/** Prayer alarms: shows the reminder / prayer notification (or plays the chosen adhan file) and sets the next alarm. */
public class PrayerReceiver extends BroadcastReceiver {
    private static final String CH_NOW = "mika_prayer", CH_SOON = "mika_prayer_soft";

    @Override
    public void onReceive(Context c, Intent i) {
        String a = i == null ? null : i.getAction();
        if (PrayerTimes.ACTION_ALARM.equals(a)) {
            int idx = i.getIntExtra("idx", -1), kind = i.getIntExtra("kind", 1);
            long at = i.getLongExtra("at", 0);
            // an alarm that fires much later than planned (phone was off / dozing for a long time) is not worth announcing
            if (idx >= 0 && Math.abs(System.currentTimeMillis() - at) < 10 * 60000L && Prefs.i(c, "prayerAlert", 1) != 0) fire(c, idx, kind, at);
        }
        PrayerTimes.schedule(c); // alarm, boot, time zone / clock change, app update: always plan the next one
    }

    static void fire(Context c, int idx, int kind, long at) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        boolean ar = Prefs.i(c, "prayerLang", 0) == 0;
        String name = PrayerTimes.name(c, idx), time = PrayerTimes.fmtTime(c, at);
        String title, text;
        if (kind == 0) {
            long mins = Prefs.i(c, "prayerBefore", 10);
            title = ar ? name + " \u0628\u0639\u062F " + mins + " \u062F\u0642\u064A\u0642\u0629" : name + " in " + mins + " min";
            text = time;
        } else {
            title = ar ? "\u062D\u0627\u0646 \u0645\u0648\u0639\u062F \u0635\u0644\u0627\u0629 " + name : "It's time for " + name;
            text = time;
        }
        boolean adhan = kind == 1 && Prefs.i(c, "prayerAlert", 1) == 2 && Prefs.s(c, "adhanUri", "").length() > 0;
        boolean playing = false;
        if (adhan) {
            try {
                Intent s = new Intent(c, AdhanService.class).putExtra("title", title).putExtra("text", text);
                if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(s);
                else c.startService(s);
                playing = true;
            } catch (Exception e) {
                playing = false; // background start refused: fall back to the notification sound below
            }
        }
        if (playing) return;
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel nowCh = new NotificationChannel(CH_NOW, "Prayer time", NotificationManager.IMPORTANCE_HIGH);
            NotificationChannel soonCh = new NotificationChannel(CH_SOON, "Prayer reminder", NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(nowCh);
            nm.createNotificationChannel(soonCh);
            b = new Notification.Builder(c, kind == 1 ? CH_NOW : CH_SOON);
        } else {
            b = new Notification.Builder(c);
        }
        PendingIntent open = PendingIntent.getActivity(c, 0, new Intent(c, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(title).setContentText(text)
                .setContentIntent(open).setAutoCancel(true).setShowWhen(true);
        if (kind == 1 && Build.VERSION.SDK_INT < 26) b.setDefaults(Notification.DEFAULT_ALL);
        nm.notify(7100 + idx, b.build());
    }
}
