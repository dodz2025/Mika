package com.mika.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Browse songs, albums, artists, videos and photos stored on the device. */
public class LibraryActivity extends Activity {

    private static final int REQ_PERM = 31;
    private static final String[] TABS = {"Songs", "Albums", "Artists", "Videos", "Photos"};

    private Pal pal;
    private boolean landscape;
    private List<Track> songs = new ArrayList<Track>();
    private List<Track> videos = new ArrayList<Track>();
    private List<Track> photos = new ArrayList<Track>();
    private boolean loaded = false;
    private int tab = 0;
    private String drillTitle = null;
    private List<Track> drillTracks = null;
    private String query = "";

    private ListView list;
    private GridView grid;
    private TextView empty, tvTabTitle;
    private EditText search;
    private final List<TextView> tabViews = new ArrayList<TextView>();
    private LinearLayout mini;
    private ImageView miniArt;
    private TextView miniTitle, miniSub;
    private View miniPlay;
    private RowAdapter rowAdapter;
    private PhotoAdapter photoAdapter;

    /** One row in the list. */
    static class Row {
        String title, sub, key;
        Thumbs.Loader loader;
        Runnable click, longClick;
    }

    private int dp(int v) {
        return Ui.dp(this, v);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) Ui.immersive(this);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.immersive(this);
        build();
        if (MediaScanner.hasPermission(this)) load();
        if (Build.VERSION.SDK_INT >= 23) {
            List<String> need = new ArrayList<String>();
            for (String perm : MediaScanner.permissions()) {
                if (checkSelfPermission(perm) != android.content.pm.PackageManager.PERMISSION_GRANTED) need.add(perm);
            }
            if (Build.VERSION.SDK_INT >= 33
                    && checkSelfPermission("android.permission.POST_NOTIFICATIONS")
                    != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                need.add("android.permission.POST_NOTIFICATIONS");
            }
            if (!need.isEmpty()) requestPermissions(need.toArray(new String[0]), REQ_PERM);
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] p, int[] r) {
        super.onRequestPermissionsResult(code, p, r);
        if (MediaScanner.hasPermission(this) && !loaded) load();
        else refresh();
    }

    @Override
    protected void onResume() {
        super.onResume();
        PlayerService.LISTENERS.add(miniRefresh);
        miniRefresh.run();
    }

    @Override
    protected void onPause() {
        super.onPause();
        PlayerService.LISTENERS.remove(miniRefresh);
    }

    @Override
    public void onBackPressed() {
        if (drillTracks != null) {
            drillTracks = null;
            drillTitle = null;
            refresh();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public void onConfigurationChanged(android.content.res.Configuration c) {
        super.onConfigurationChanged(c);
        build();
        refresh();
    }

    private void load() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                final List<Track> a = MediaScanner.audio(LibraryActivity.this);
                final List<Track> v = MediaScanner.videos(LibraryActivity.this);
                final List<Track> p = MediaScanner.images(LibraryActivity.this);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        songs = a;
                        videos = v;
                        photos = p;
                        loaded = true;
                        refresh();
                    }
                });
            }
        }).start();
    }

    // ------------------------------------------------------------------ UI
    private void build() {
        pal = Pal.of(this);
        landscape = getResources().getDisplayMetrics().widthPixels > getResources().getDisplayMetrics().heightPixels;
        tabViews.clear();
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{pal.bgTop, pal.bgBottom}));
        root.setPadding(dp(14), dp(10), dp(14), dp(10));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        View back = Ui.iconButton(this, Icons.BACK, 44, 22, pal.card, pal.text);
        back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                onBackPressed();
            }
        });
        top.addView(back);
        tvTabTitle = Ui.text(this, "Media", 20, pal.text);
        tvTabTitle.setTypeface(Typeface.DEFAULT_BOLD);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(-2, -2);
        tl.leftMargin = dp(12);
        top.addView(tvTabTitle, tl);
        search = new EditText(this);
        search.setHint("Search");
        search.setSingleLine(true);
        search.setTextColor(pal.text);
        search.setHintTextColor(pal.sub);
        search.setTextSize(16);
        search.setBackground(Ui.pill(this, pal.card, 18));
        search.setPadding(dp(16), dp(8), dp(16), dp(8));
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            public void onTextChanged(CharSequence s, int a, int b, int c) {
            }

            public void afterTextChanged(Editable e) {
                query = e.toString().trim().toLowerCase(Locale.getDefault());
                refresh();
            }
        });
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(0, -2, 1f);
        sl.leftMargin = dp(12);
        top.addView(search, sl);
        TextView now = Ui.button(this, "Now playing", 14, pal.accent, 0xFFFFFFFF);
        now.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(LibraryActivity.this, PlayerActivity.class));
            }
        });
        LinearLayout.LayoutParams nl = new LinearLayout.LayoutParams(-2, -2);
        nl.leftMargin = dp(10);
        top.addView(now, nl);
        root.addView(top, new LinearLayout.LayoutParams(-1, -2));

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout tabs = new LinearLayout(this);
        for (int i = 0; i < TABS.length; i++) {
            final int idx = i;
            TextView t = Ui.button(this, TABS[i], 15, pal.card, pal.text);
            t.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    tab = idx;
                    drillTracks = null;
                    drillTitle = null;
                    refresh();
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.rightMargin = dp(8);
            tabs.addView(t, lp);
            tabViews.add(t);
        }
        hs.addView(tabs);
        LinearLayout.LayoutParams hl = new LinearLayout.LayoutParams(-1, -2);
        hl.topMargin = dp(10);
        hl.bottomMargin = dp(8);
        root.addView(hs, hl);

        FrameLayout_ content = new FrameLayout_(this);
        list = new ListView(this);
        list.setDivider(null);
        list.setSelector(new android.graphics.drawable.ColorDrawable(0));
        rowAdapter = new RowAdapter();
        list.setAdapter(rowAdapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> p, View v, int pos, long id) {
                Row r = rowAdapter.rows.get(pos);
                if (r.click != null) r.click.run();
            }
        });
        list.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            public boolean onItemLongClick(AdapterView<?> p, View v, int pos, long id) {
                Row r = rowAdapter.rows.get(pos);
                if (r.longClick != null) {
                    r.longClick.run();
                    return true;
                }
                return false;
            }
        });
        content.addView(list, new android.widget.FrameLayout.LayoutParams(-1, -1));

        grid = new GridView(this);
        grid.setNumColumns(landscape ? 6 : 3);
        grid.setHorizontalSpacing(dp(4));
        grid.setVerticalSpacing(dp(4));
        grid.setSelector(new android.graphics.drawable.ColorDrawable(0));
        photoAdapter = new PhotoAdapter();
        grid.setAdapter(photoAdapter);
        grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> p, View v, int pos, long id) {
                PhotoViewerActivity.items = new ArrayList<Track>(photoAdapter.items);
                PhotoViewerActivity.startIndex = pos;
                startActivity(new Intent(LibraryActivity.this, PhotoViewerActivity.class));
            }
        });
        content.addView(grid, new android.widget.FrameLayout.LayoutParams(-1, -1));

        empty = Ui.text(this, "", 16, pal.sub);
        empty.setGravity(Gravity.CENTER);
        empty.setPadding(dp(30), dp(30), dp(30), dp(30));
        content.addView(empty, new android.widget.FrameLayout.LayoutParams(-1, -1));
        root.addView(content, new LinearLayout.LayoutParams(-1, 0, 1f));

        // mini player
        mini = new LinearLayout(this);
        mini.setGravity(Gravity.CENTER_VERTICAL);
        mini.setBackground(Ui.pill(this, pal.card, 22));
        mini.setPadding(dp(10), dp(8), dp(10), dp(8));
        miniArt = new ImageView(this);
        miniArt.setScaleType(ImageView.ScaleType.CENTER_CROP);
        mini.addView(miniArt, new LinearLayout.LayoutParams(dp(44), dp(44)));
        LinearLayout txt = new LinearLayout(this);
        txt.setOrientation(LinearLayout.VERTICAL);
        miniTitle = Ui.text(this, "", 15, pal.text);
        miniTitle.setSingleLine(true);
        miniTitle.setEllipsize(TextUtils.TruncateAt.END);
        miniSub = Ui.text(this, "", 12, pal.sub);
        miniSub.setSingleLine(true);
        txt.addView(miniTitle);
        txt.addView(miniSub);
        LinearLayout.LayoutParams txl = new LinearLayout.LayoutParams(0, -2, 1f);
        txl.leftMargin = dp(10);
        mini.addView(txt, txl);
        View prev = Ui.iconButton(this, Icons.PREV, 44, 22, 0, pal.text);
        prev.setBackground(null);
        prev.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                PlayerService.send(LibraryActivity.this, PlayerService.ACTION_PREV);
            }
        });
        miniPlay = Ui.iconButton(this, Icons.PLAY, 46, 24, pal.accent, 0xFFFFFFFF);
        miniPlay.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                PlayerService.send(LibraryActivity.this, PlayerService.ACTION_TOGGLE);
            }
        });
        View next = Ui.iconButton(this, Icons.NEXT, 44, 22, 0, pal.text);
        next.setBackground(null);
        next.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                PlayerService.send(LibraryActivity.this, PlayerService.ACTION_NEXT);
            }
        });
        mini.addView(prev);
        mini.addView(miniPlay);
        mini.addView(next);
        mini.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(LibraryActivity.this, PlayerActivity.class));
            }
        });
        mini.setVisibility(View.GONE);
        LinearLayout.LayoutParams ml = new LinearLayout.LayoutParams(-1, -2);
        ml.topMargin = dp(8);
        root.addView(mini, ml);
        setContentView(root);
    }

    /** Tiny alias so the file reads clearly; just a FrameLayout. */
    static class FrameLayout_ extends android.widget.FrameLayout {
        FrameLayout_(android.content.Context c) {
            super(c);
        }
    }

    private final Runnable miniRefresh = new Runnable() {
        @Override
        public void run() {
            if (mini == null) return;
            Track t = PlayerService.current();
            if (t == null) {
                mini.setVisibility(View.GONE);
                return;
            }
            mini.setVisibility(View.VISIBLE);
            miniTitle.setText(t.title);
            miniSub.setText(t.artist);
            Bitmap a = PlayerService.art();
            if (a != null) miniArt.setImageBitmap(a);
            else miniArt.setImageDrawable(null);
            Ui.setIcon(miniPlay, PlayerService.isPlaying() ? Icons.PAUSE : Icons.PLAY, 0xFFFFFFFF);
        }
    };

    // ------------------------------------------------------------- content
    private void refresh() {
        if (list == null) return;
        for (int i = 0; i < tabViews.size(); i++) {
            TextView t = tabViews.get(i);
            boolean on = i == tab;
            t.setBackground(Ui.pill(this, on ? pal.accent : pal.card, 18));
            t.setTextColor(on ? 0xFFFFFFFF : pal.text);
        }
        tvTabTitle.setText(drillTitle != null ? drillTitle : "Media");
        boolean photosTab = tab == 4 && drillTracks == null;
        list.setVisibility(photosTab ? View.GONE : View.VISIBLE);
        grid.setVisibility(photosTab ? View.VISIBLE : View.GONE);

        if (!MediaScanner.hasPermission(this)) {
            showEmpty("Allow access to your media to browse it.\n\nTap here to open permission settings.");
            empty.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()));
                    startActivity(i);
                }
            });
            return;
        }
        empty.setOnClickListener(null);
        if (!loaded) {
            showEmpty("Loading your media\u2026");
            return;
        }

        List<Row> rows = new ArrayList<Row>();
        if (photosTab) {
            List<Track> f = new ArrayList<Track>();
            for (Track t : photos) if (query.length() == 0 || t.title.toLowerCase(Locale.getDefault()).contains(query)) f.add(t);
            photoAdapter.items = f;
            photoAdapter.notifyDataSetChanged();
            if (f.isEmpty()) showEmpty("No photos found."); else empty.setVisibility(View.GONE);
            return;
        }
        if (drillTracks != null) {
            rows = songRows(filter(drillTracks));
        } else if (tab == 0) {
            rows = songRows(filter(songs));
        } else if (tab == 1) {
            rows = albumRows();
        } else if (tab == 2) {
            rows = artistRows();
        } else {
            rows = videoRows();
        }
        rowAdapter.rows = rows;
        rowAdapter.notifyDataSetChanged();
        if (rows.isEmpty()) showEmpty(tab == 3 ? "No videos found." : "Nothing here yet.");
        else empty.setVisibility(View.GONE);
    }

    private void showEmpty(String s) {
        empty.setText(s);
        empty.setVisibility(View.VISIBLE);
        if (rowAdapter != null) {
            rowAdapter.rows = new ArrayList<Row>();
            rowAdapter.notifyDataSetChanged();
        }
    }

    private List<Track> filter(List<Track> src) {
        if (query.length() == 0) return src;
        List<Track> out = new ArrayList<Track>();
        for (Track t : src) {
            if (t.title.toLowerCase(Locale.getDefault()).contains(query)
                    || t.artist.toLowerCase(Locale.getDefault()).contains(query)
                    || t.album.toLowerCase(Locale.getDefault()).contains(query)) out.add(t);
        }
        return out;
    }

    private List<Row> songRows(final List<Track> src) {
        List<Row> rows = new ArrayList<Row>();
        final List<Track> queue = new ArrayList<Track>(src);
        for (int i = 0; i < queue.size(); i++) {
            final int idx = i;
            final Track t = queue.get(i);
            Row r = new Row();
            r.title = t.title;
            r.sub = t.artist + "  \u00B7  " + Track.fmt(t.duration);
            r.key = "alb" + t.albumId + "_" + (t.albumId == 0 ? t.id : 0);
            r.loader = new Thumbs.Loader() {
                public Bitmap load() {
                    return Thumbs.audioArt(LibraryActivity.this, t, 120);
                }
            };
            r.click = new Runnable() {
                public void run() {
                    PlayerService.play(LibraryActivity.this, queue, idx);
                    startActivity(new Intent(LibraryActivity.this, PlayerActivity.class));
                }
            };
            r.longClick = new Runnable() {
                public void run() {
                    songMenu(t);
                }
            };
            rows.add(r);
        }
        return rows;
    }

    private void songMenu(final Track t) {
        new AlertDialog.Builder(this).setTitle(t.title)
                .setItems(new String[]{"Play next", "Add to queue"}, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int which) {
                        PlayerService.enqueue(LibraryActivity.this, t, which == 0);
                        Toast.makeText(LibraryActivity.this, which == 0 ? "Playing next" : "Added to queue",
                                Toast.LENGTH_SHORT).show();
                    }
                }).show();
    }

    private List<Row> albumRows() {
        Map<String, List<Track>> groups = new LinkedHashMap<String, List<Track>>();
        for (Track t : filter(songs)) {
            String k = t.album + "\u0000" + t.albumId;
            List<Track> l = groups.get(k);
            if (l == null) {
                l = new ArrayList<Track>();
                groups.put(k, l);
            }
            l.add(t);
        }
        List<Row> rows = new ArrayList<Row>();
        for (Map.Entry<String, List<Track>> e : groups.entrySet()) {
            final List<Track> tracks = e.getValue();
            final Track first = tracks.get(0);
            Row r = new Row();
            r.title = first.album;
            r.sub = first.artist + "  \u00B7  " + tracks.size() + (tracks.size() == 1 ? " song" : " songs");
            r.key = "alb" + first.albumId + "_" + (first.albumId == 0 ? first.id : 0);
            r.loader = new Thumbs.Loader() {
                public Bitmap load() {
                    return Thumbs.audioArt(LibraryActivity.this, first, 120);
                }
            };
            final String title = first.album;
            r.click = new Runnable() {
                public void run() {
                    drillTracks = tracks;
                    drillTitle = title;
                    refresh();
                }
            };
            rows.add(r);
        }
        sortRows(rows);
        return rows;
    }

    private List<Row> artistRows() {
        Map<String, List<Track>> groups = new LinkedHashMap<String, List<Track>>();
        for (Track t : filter(songs)) {
            List<Track> l = groups.get(t.artist);
            if (l == null) {
                l = new ArrayList<Track>();
                groups.put(t.artist, l);
            }
            l.add(t);
        }
        List<Row> rows = new ArrayList<Row>();
        for (Map.Entry<String, List<Track>> e : groups.entrySet()) {
            final List<Track> tracks = e.getValue();
            final Track first = tracks.get(0);
            Row r = new Row();
            r.title = e.getKey();
            r.sub = tracks.size() + (tracks.size() == 1 ? " song" : " songs");
            r.key = "alb" + first.albumId + "_" + (first.albumId == 0 ? first.id : 0);
            r.loader = new Thumbs.Loader() {
                public Bitmap load() {
                    return Thumbs.audioArt(LibraryActivity.this, first, 120);
                }
            };
            final String title = e.getKey();
            r.click = new Runnable() {
                public void run() {
                    drillTracks = tracks;
                    drillTitle = title;
                    refresh();
                }
            };
            rows.add(r);
        }
        sortRows(rows);
        return rows;
    }

    private void sortRows(List<Row> rows) {
        Collections.sort(rows, new Comparator<Row>() {
            public int compare(Row a, Row b) {
                return a.title.compareToIgnoreCase(b.title);
            }
        });
    }

    private List<Row> videoRows() {
        List<Row> rows = new ArrayList<Row>();
        final List<Track> all = new ArrayList<Track>();
        for (Track t : videos) if (query.length() == 0 || t.title.toLowerCase(Locale.getDefault()).contains(query)) all.add(t);
        for (int i = 0; i < all.size(); i++) {
            final int idx = i;
            final Track t = all.get(i);
            Row r = new Row();
            r.title = t.title;
            r.sub = Track.fmt(t.duration);
            r.key = "vid" + t.id;
            r.loader = new Thumbs.Loader() {
                public Bitmap load() {
                    return Thumbs.videoFrame(LibraryActivity.this, t.uri, 160);
                }
            };
            r.click = new Runnable() {
                public void run() {
                    VideoPlayerActivity.items = all;
                    VideoPlayerActivity.startIndex = idx;
                    startActivity(new Intent(LibraryActivity.this, VideoPlayerActivity.class));
                }
            };
            rows.add(r);
        }
        return rows;
    }

    // ------------------------------------------------------------ adapters
    private class RowAdapter extends BaseAdapter {
        List<Row> rows = new ArrayList<Row>();

        public int getCount() {
            return rows.size();
        }

        public Object getItem(int i) {
            return rows.get(i);
        }

        public long getItemId(int i) {
            return i;
        }

        public View getView(int pos, View convert, ViewGroup parent) {
            LinearLayout cell;
            ImageView art;
            TextView t1, t2;
            if (convert == null) {
                cell = new LinearLayout(LibraryActivity.this);
                cell.setGravity(Gravity.CENTER_VERTICAL);
                cell.setPadding(dp(8), dp(7), dp(8), dp(7));
                art = new ImageView(LibraryActivity.this);
                art.setScaleType(ImageView.ScaleType.CENTER_CROP);
                art.setBackground(Ui.pill(LibraryActivity.this, pal.card, 10));
                cell.addView(art, new LinearLayout.LayoutParams(dp(52), dp(52)));
                LinearLayout col = new LinearLayout(LibraryActivity.this);
                col.setOrientation(LinearLayout.VERTICAL);
                t1 = Ui.text(LibraryActivity.this, "", 16, pal.text);
                t1.setSingleLine(true);
                t1.setEllipsize(TextUtils.TruncateAt.END);
                t2 = Ui.text(LibraryActivity.this, "", 13, pal.sub);
                t2.setSingleLine(true);
                t2.setEllipsize(TextUtils.TruncateAt.END);
                col.addView(t1);
                col.addView(t2);
                LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(0, -2, 1f);
                cl.leftMargin = dp(12);
                cell.addView(col, cl);
                cell.setTag(new Object[]{art, t1, t2});
            } else {
                cell = (LinearLayout) convert;
            }
            Object[] v = (Object[]) cell.getTag();
            art = (ImageView) v[0];
            t1 = (TextView) v[1];
            t2 = (TextView) v[2];
            Row r = rows.get(pos);
            t1.setText(r.title);
            t2.setText(r.sub);
            if (r.loader != null) Thumbs.load(art, r.key, r.loader);
            return cell;
        }
    }

    private class PhotoAdapter extends BaseAdapter {
        List<Track> items = new ArrayList<Track>();

        public int getCount() {
            return items.size();
        }

        public Object getItem(int i) {
            return items.get(i);
        }

        public long getItemId(int i) {
            return i;
        }

        public View getView(int pos, View convert, ViewGroup parent) {
            ImageView iv;
            int cols = landscape ? 6 : 3;
            int size = (getResources().getDisplayMetrics().widthPixels - dp(28) - dp(4) * (cols - 1)) / cols;
            if (convert == null) {
                iv = new ImageView(LibraryActivity.this);
                iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
                iv.setBackgroundColor(pal.card);
                iv.setLayoutParams(new AbsListViewLP(size, size));
            } else {
                iv = (ImageView) convert;
            }
            final Track t = items.get(pos);
            Thumbs.load(iv, "img" + t.id, new Thumbs.Loader() {
                public Bitmap load() {
                    return Thumbs.decodeUri(LibraryActivity.this, t.uri, 256);
                }
            });
            return iv;
        }
    }

    private static class AbsListViewLP extends android.widget.AbsListView.LayoutParams {
        AbsListViewLP(int w, int h) {
            super(w, h);
        }
    }
}
