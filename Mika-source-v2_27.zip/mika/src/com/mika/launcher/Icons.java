package com.mika.launcher;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.widget.ImageView;

/**
 * Modern rounded vector icons (soft corners, round caps/joins, 24x24 design grid).
 * Drawn with Canvas: no bitmap assets, scale to any size and are tint-able.
 */
final class Icons {
    static final int PLAY = 0, PAUSE = 1, PREV = 2, NEXT = 3, GEAR = 4, MAP = 5, PHONE = 6, WIFI = 7,
            BT = 8, MUTE = 9, VOLUME = 10, SEARCH = 11, HOME = 12, NAV = 13, APPS = 14, MUSIC = 15,
            CLOSE = 16, BOLT = 17, BATTERY = 18, MIC = 19, PLUS = 20, MINUS = 21, TARGET = 22, WORK = 23,
            LAYOUT = 24, VOL_UP = 25, VOL_DOWN = 26, CAR = 27, BACK = 28, SHUFFLE = 29, REPEAT = 30,
            REPEAT_ONE = 31, REPLAY10 = 32, FORWARD10 = 33, STAR = 34, COMPASS = 35, LAYERS = 36,
            SLIDESHOW = 37, SLEEP = 38;

    private Icons() {
    }

    static Drawable get(int type, int color) {
        return new Glyph(type, color);
    }

    static ImageView view(Context c, int type, int sizeDp, int color) {
        ImageView iv = new ImageView(c);
        iv.setImageDrawable(new Glyph(type, color));
        int px = Ui.dp(c, sizeDp);
        iv.setLayoutParams(new android.widget.LinearLayout.LayoutParams(px, px));
        return iv;
    }

    static void set(ImageView iv, int type, int color) {
        iv.setImageDrawable(new Glyph(type, color));
    }

    private static final class Glyph extends Drawable {
        private final int type;
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);

        Glyph(int type, int color) {
            this.type = type;
            fill.setStyle(Paint.Style.FILL);
            fill.setColor(color);
            line.setStyle(Paint.Style.STROKE);
            line.setColor(color);
            line.setStrokeCap(Paint.Cap.ROUND);
            line.setStrokeJoin(Paint.Join.ROUND);
            txt.setStyle(Paint.Style.FILL);
            txt.setColor(color);
            txt.setTextAlign(Paint.Align.CENTER);
            txt.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        }

        /** Filled shape with softly rounded corners (fill + round-join stroke of the same colour). */
        private void soft(Canvas cv, Path p, float w) {
            cv.drawPath(p, fill);
            line.setStrokeWidth(w);
            cv.drawPath(p, line);
        }

        private void speaker(Canvas cv) {
            Path p = new Path();
            p.moveTo(4.6f, 9.6f);
            p.lineTo(8f, 9.6f);
            p.lineTo(12.2f, 5.9f);
            p.lineTo(12.2f, 18.1f);
            p.lineTo(8f, 14.4f);
            p.lineTo(4.6f, 14.4f);
            p.close();
            soft(cv, p, 1.8f);
        }

        private void arrowHead(Canvas cv, float x, float y, float dx, float dy) {
            // dx,dy = direction the arrow points (unit); draws a small round chevron at (x,y)
            Path p = new Path();
            float nx = -dy, ny = dx;
            p.moveTo(x - dx * 2.6f + nx * 2.6f, y - dy * 2.6f + ny * 2.6f);
            p.lineTo(x, y);
            p.lineTo(x - dx * 2.6f - nx * 2.6f, y - dy * 2.6f - ny * 2.6f);
            cv.drawPath(p, line);
        }

        @Override
        public void draw(Canvas cv) {
            RectF b = new RectF(getBounds());
            float s = Math.min(b.width(), b.height());
            float u = s / 24f; // design grid 24x24
            cv.save();
            cv.translate(b.left + (b.width() - s) / 2f, b.top + (b.height() - s) / 2f);
            cv.scale(u, u);
            line.setStrokeWidth(2.1f);
            line.setStyle(Paint.Style.STROKE);
            Path p = new Path();
            switch (type) {
                case PLAY:
                    p.moveTo(8.2f, 5.6f);
                    p.lineTo(18.6f, 12f);
                    p.lineTo(8.2f, 18.4f);
                    p.close();
                    soft(cv, p, 2.8f);
                    break;
                case PAUSE:
                    cv.drawRoundRect(new RectF(5.8f, 4.6f, 10.2f, 19.4f), 2.2f, 2.2f, fill);
                    cv.drawRoundRect(new RectF(13.8f, 4.6f, 18.2f, 19.4f), 2.2f, 2.2f, fill);
                    break;
                case PREV:
                    cv.drawRoundRect(new RectF(5.2f, 5.6f, 7.8f, 18.4f), 1.3f, 1.3f, fill);
                    p.moveTo(18.2f, 6.4f);
                    p.lineTo(10.2f, 12f);
                    p.lineTo(18.2f, 17.6f);
                    p.close();
                    soft(cv, p, 2.4f);
                    break;
                case NEXT:
                    cv.drawRoundRect(new RectF(16.2f, 5.6f, 18.8f, 18.4f), 1.3f, 1.3f, fill);
                    p.moveTo(5.8f, 6.4f);
                    p.lineTo(13.8f, 12f);
                    p.lineTo(5.8f, 17.6f);
                    p.close();
                    soft(cv, p, 2.4f);
                    break;
                case GEAR: {
                    int teeth = 8;
                    float ro = 9.4f, ri = 7.1f;
                    for (int i = 0; i < teeth; i++) {
                        double a0 = Math.PI * 2 / teeth * i;
                        double w = Math.PI * 2 / teeth;
                        double[] ang = {a0 - w * 0.16, a0 + w * 0.16, a0 + w * 0.34, a0 + w * 0.66};
                        float[] rad = {ro, ro, ri, ri};
                        for (int k = 0; k < 4; k++) {
                            float x = 12 + (float) Math.cos(ang[k]) * rad[k];
                            float y = 12 + (float) Math.sin(ang[k]) * rad[k];
                            if (i == 0 && k == 0) p.moveTo(x, y);
                            else p.lineTo(x, y);
                        }
                    }
                    p.close();
                    p.setFillType(Path.FillType.EVEN_ODD);
                    p.addCircle(12, 12, 3.1f, Path.Direction.CW);
                    cv.drawPath(p, fill);
                    line.setStrokeWidth(1.5f);
                    cv.drawPath(p, line);
                    break;
                }
                case MAP:
                    p.setFillType(Path.FillType.EVEN_ODD);
                    p.moveTo(12, 21.5f);
                    p.cubicTo(6.4f, 15.4f, 5, 12.6f, 5, 9.6f);
                    p.cubicTo(5, 5.8f, 8, 2.8f, 12, 2.8f);
                    p.cubicTo(16, 2.8f, 19, 5.8f, 19, 9.6f);
                    p.cubicTo(19, 12.6f, 17.6f, 15.4f, 12, 21.5f);
                    p.close();
                    p.addCircle(12, 9.6f, 2.9f, Path.Direction.CW);
                    cv.drawPath(p, fill);
                    break;
                case PHONE:
                    p.moveTo(6.8f, 3.8f);
                    p.lineTo(9.3f, 3.8f);
                    p.lineTo(10.5f, 7.6f);
                    p.lineTo(8.8f, 9.2f);
                    p.cubicTo(9.9f, 11.6f, 12.4f, 14.1f, 14.8f, 15.2f);
                    p.lineTo(16.4f, 13.5f);
                    p.lineTo(20.2f, 14.7f);
                    p.lineTo(20.2f, 17.2f);
                    p.cubicTo(20.2f, 18.9f, 19f, 20.2f, 17.3f, 20.2f);
                    p.cubicTo(10.3f, 19.8f, 4.2f, 13.7f, 3.8f, 6.7f);
                    p.cubicTo(3.8f, 5f, 5.1f, 3.8f, 6.8f, 3.8f);
                    p.close();
                    soft(cv, p, 1.6f);
                    break;
                case WIFI:
                    line.setStrokeWidth(2.2f);
                    cv.drawArc(new RectF(2.6f, 3f, 21.4f, 21.8f), 228, 84, false, line);
                    cv.drawArc(new RectF(6f, 6.6f, 18f, 18.6f), 226, 88, false, line);
                    cv.drawCircle(12, 16.2f, 1.7f, fill);
                    break;
                case BT:
                    line.setStrokeWidth(2f);
                    p.moveTo(6.5f, 7.5f);
                    p.lineTo(17f, 16.5f);
                    p.lineTo(12, 21);
                    p.lineTo(12, 3);
                    p.lineTo(17, 7.5f);
                    p.lineTo(6.5f, 16.5f);
                    cv.drawPath(p, line);
                    break;
                case MUTE:
                    speaker(cv);
                    line.setStrokeWidth(2.1f);
                    cv.drawLine(16, 9.6f, 21, 14.4f, line);
                    cv.drawLine(21, 9.6f, 16, 14.4f, line);
                    break;
                case VOLUME:
                case VOL_UP:
                    speaker(cv);
                    line.setStrokeWidth(2f);
                    cv.drawArc(new RectF(7.4f, 8f, 17.4f, 16f), -48, 96, false, line);
                    cv.drawArc(new RectF(5.2f, 4.4f, 21.2f, 19.6f), -48, 96, false, line);
                    break;
                case VOL_DOWN:
                    speaker(cv);
                    line.setStrokeWidth(2f);
                    cv.drawArc(new RectF(7.4f, 8f, 17.4f, 16f), -48, 96, false, line);
                    break;
                case SEARCH:
                    line.setStrokeWidth(2.3f);
                    cv.drawCircle(10.6f, 10.6f, 6.1f, line);
                    cv.drawLine(15.2f, 15.2f, 20f, 20f, line);
                    break;
                case HOME:
                    line.setStrokeWidth(2.1f);
                    p.moveTo(4.5f, 10.8f);
                    p.lineTo(12, 4f);
                    p.lineTo(19.5f, 10.8f);
                    p.lineTo(19.5f, 17.6f);
                    p.quadTo(19.5f, 20, 17.1f, 20);
                    p.lineTo(6.9f, 20);
                    p.quadTo(4.5f, 20, 4.5f, 17.6f);
                    p.close();
                    cv.drawPath(p, line);
                    cv.drawRoundRect(new RectF(10, 13.6f, 14, 20f), 1.2f, 1.2f, fill);
                    break;
                case NAV:
                    p.moveTo(12, 3.6f);
                    p.lineTo(19.2f, 19.4f);
                    p.lineTo(12, 15.8f);
                    p.lineTo(4.8f, 19.4f);
                    p.close();
                    soft(cv, p, 2f);
                    break;
                case APPS:
                    cv.drawRoundRect(new RectF(4.2f, 4.2f, 10.8f, 10.8f), 2.2f, 2.2f, fill);
                    cv.drawRoundRect(new RectF(13.2f, 4.2f, 19.8f, 10.8f), 2.2f, 2.2f, fill);
                    cv.drawRoundRect(new RectF(4.2f, 13.2f, 10.8f, 19.8f), 2.2f, 2.2f, fill);
                    cv.drawRoundRect(new RectF(13.2f, 13.2f, 19.8f, 19.8f), 2.2f, 2.2f, fill);
                    break;
                case MUSIC:
                    line.setStrokeWidth(2.2f);
                    cv.drawLine(15.6f, 17f, 15.6f, 4.8f, line);
                    p.moveTo(15.6f, 4.8f);
                    p.cubicTo(16.4f, 8.2f, 19.6f, 8.2f, 19.6f, 11.4f);
                    cv.drawPath(p, line);
                    cv.drawCircle(11.8f, 17.4f, 3.6f, fill);
                    break;
                case LAYOUT:
                    line.setStrokeWidth(2f);
                    cv.drawRoundRect(new RectF(3.8f, 3.8f, 20.2f, 20.2f), 4f, 4f, line);
                    cv.drawLine(10.6f, 3.8f, 10.6f, 20.2f, line);
                    cv.drawLine(10.6f, 12f, 20.2f, 12f, line);
                    break;
                case CLOSE:
                    line.setStrokeWidth(2.4f);
                    cv.drawLine(6.2f, 6.2f, 17.8f, 17.8f, line);
                    cv.drawLine(17.8f, 6.2f, 6.2f, 17.8f, line);
                    break;
                case BOLT:
                    p.moveTo(13.4f, 2.8f);
                    p.lineTo(5.8f, 13.4f);
                    p.lineTo(11f, 13.4f);
                    p.lineTo(10.2f, 21.2f);
                    p.lineTo(18.2f, 10.2f);
                    p.lineTo(13f, 10.2f);
                    p.close();
                    soft(cv, p, 1.6f);
                    break;
                case BATTERY:
                    line.setStrokeWidth(2f);
                    cv.drawRoundRect(new RectF(3, 7, 19, 17), 3f, 3f, line);
                    cv.drawRoundRect(new RectF(20.2f, 10.2f, 22, 13.8f), 0.9f, 0.9f, fill);
                    cv.drawRoundRect(new RectF(5.4f, 9.4f, 14, 14.6f), 1.4f, 1.4f, fill);
                    break;
                case MIC:
                    cv.drawRoundRect(new RectF(8.8f, 2.8f, 15.2f, 14.2f), 3.2f, 3.2f, fill);
                    line.setStrokeWidth(2f);
                    cv.drawArc(new RectF(5.6f, 7.4f, 18.4f, 19.4f), 0, 180, false, line);
                    cv.drawLine(12, 19.4f, 12, 22, line);
                    break;
                case PLUS:
                    line.setStrokeWidth(2.5f);
                    cv.drawLine(12, 5.4f, 12, 18.6f, line);
                    cv.drawLine(5.4f, 12, 18.6f, 12, line);
                    break;
                case MINUS:
                    line.setStrokeWidth(2.5f);
                    cv.drawLine(5.4f, 12, 18.6f, 12, line);
                    break;
                case TARGET:
                    line.setStrokeWidth(2f);
                    cv.drawCircle(12, 12, 6.8f, line);
                    cv.drawCircle(12, 12, 2.4f, fill);
                    cv.drawLine(12, 2.4f, 12, 5, line);
                    cv.drawLine(12, 19, 12, 21.6f, line);
                    cv.drawLine(2.4f, 12, 5, 12, line);
                    cv.drawLine(19, 12, 21.6f, 12, line);
                    break;
                case WORK:
                    line.setStrokeWidth(2f);
                    cv.drawRoundRect(new RectF(3.6f, 7.8f, 20.4f, 20f), 3.4f, 3.4f, line);
                    p.moveTo(8.6f, 7.8f);
                    p.lineTo(8.6f, 6.4f);
                    p.quadTo(8.6f, 4.2f, 10.8f, 4.2f);
                    p.lineTo(13.2f, 4.2f);
                    p.quadTo(15.4f, 4.2f, 15.4f, 6.4f);
                    p.lineTo(15.4f, 7.8f);
                    cv.drawPath(p, line);
                    cv.drawLine(3.8f, 13.2f, 20.2f, 13.2f, line);
                    break;
                case CAR:
                    p.moveTo(3.2f, 16.4f);
                    p.lineTo(3.2f, 12.6f);
                    p.quadTo(3.2f, 11.2f, 4.6f, 10.9f);
                    p.lineTo(7.2f, 10.3f);
                    p.lineTo(9.4f, 6.9f);
                    p.quadTo(9.9f, 6.1f, 10.9f, 6.1f);
                    p.lineTo(14.2f, 6.1f);
                    p.quadTo(15.2f, 6.1f, 15.9f, 6.8f);
                    p.lineTo(18.4f, 10.4f);
                    p.quadTo(20.8f, 10.8f, 20.8f, 12.9f);
                    p.lineTo(20.8f, 16.4f);
                    p.lineTo(19.8f, 16.4f);
                    p.arcTo(new RectF(13.4f, 13.2f, 19.8f, 19.6f), 0, -180);
                    p.lineTo(10.6f, 16.4f);
                    p.arcTo(new RectF(4.2f, 13.2f, 10.6f, 19.6f), 0, -180);
                    p.close();
                    soft(cv, p, 1.6f);
                    cv.drawCircle(7.4f, 16.4f, 2.1f, fill);
                    cv.drawCircle(16.6f, 16.4f, 2.1f, fill);
                    break;
                case BACK:
                    line.setStrokeWidth(2.4f);
                    cv.drawLine(19, 12, 5.6f, 12, line);
                    p.moveTo(11.4f, 6f);
                    p.lineTo(5.4f, 12f);
                    p.lineTo(11.4f, 18f);
                    cv.drawPath(p, line);
                    break;
                case SHUFFLE:
                    line.setStrokeWidth(2.1f);
                    p.moveTo(3.8f, 7f);
                    p.lineTo(7.4f, 7f);
                    p.cubicTo(13f, 7f, 10.6f, 17f, 16.4f, 17f);
                    p.lineTo(19.6f, 17f);
                    cv.drawPath(p, line);
                    arrowHead(cv, 20.2f, 17f, 1, 0);
                    Path q = new Path();
                    q.moveTo(3.8f, 17f);
                    q.lineTo(7.4f, 17f);
                    q.cubicTo(10f, 17f, 10.4f, 14.6f, 11.4f, 12.8f);
                    cv.drawPath(q, line);
                    Path r = new Path();
                    r.moveTo(13.4f, 9.4f);
                    r.cubicTo(14.2f, 8f, 15f, 7f, 16.4f, 7f);
                    r.lineTo(19.6f, 7f);
                    cv.drawPath(r, line);
                    arrowHead(cv, 20.2f, 7f, 1, 0);
                    break;
                case REPEAT:
                case REPEAT_ONE:
                    line.setStrokeWidth(2.1f);
                    p.moveTo(4, 11f);
                    p.lineTo(4, 10f);
                    p.quadTo(4, 6f, 8, 6f);
                    p.lineTo(19f, 6f);
                    cv.drawPath(p, line);
                    arrowHead(cv, 20f, 6f, 1, 0);
                    Path p2 = new Path();
                    p2.moveTo(20, 13f);
                    p2.lineTo(20, 14f);
                    p2.quadTo(20, 18f, 16, 18f);
                    p2.lineTo(5f, 18f);
                    cv.drawPath(p2, line);
                    arrowHead(cv, 4f, 18f, -1, 0);
                    if (type == REPEAT_ONE) {
                        txt.setTextSize(8.6f);
                        cv.drawText("1", 12, 14.9f, txt);
                    }
                    break;
                case REPLAY10:
                case FORWARD10: {
                    boolean fw = type == FORWARD10;
                    line.setStrokeWidth(2f);
                    RectF oval = new RectF(4f, 5f, 20f, 21f);
                    if (fw) {
                        cv.drawArc(oval, -60, 290, false, line);
                        arrowHead(cv, 15.7f, 4.2f, 1, 0.1f);
                    } else {
                        cv.drawArc(oval, -230, 290, false, line);
                        arrowHead(cv, 8.3f, 4.2f, -1, 0.1f);
                    }
                    txt.setTextSize(7f);
                    cv.drawText("10", 12, 15.2f, txt);
                    break;
                }
                case STAR: {
                    for (int i = 0; i < 10; i++) {
                        double a = -Math.PI / 2 + Math.PI / 5 * i;
                        float rr = (i % 2 == 0) ? 9.2f : 4.2f;
                        float x = 12 + (float) Math.cos(a) * rr, y = 12.6f + (float) Math.sin(a) * rr;
                        if (i == 0) p.moveTo(x, y);
                        else p.lineTo(x, y);
                    }
                    p.close();
                    soft(cv, p, 1.6f);
                    break;
                }
                case COMPASS:
                    line.setStrokeWidth(2f);
                    cv.drawCircle(12, 12, 9, line);
                    p.moveTo(15.8f, 8.2f);
                    p.lineTo(13.6f, 13.6f);
                    p.lineTo(8.2f, 15.8f);
                    p.lineTo(10.4f, 10.4f);
                    p.close();
                    soft(cv, p, 1.2f);
                    break;
                case LAYERS:
                    line.setStrokeWidth(2f);
                    p.moveTo(12, 3.6f);
                    p.lineTo(20.6f, 8.6f);
                    p.lineTo(12, 13.6f);
                    p.lineTo(3.4f, 8.6f);
                    p.close();
                    cv.drawPath(p, line);
                    Path l2 = new Path();
                    l2.moveTo(3.6f, 12.6f);
                    l2.lineTo(12, 17.4f);
                    l2.lineTo(20.4f, 12.6f);
                    cv.drawPath(l2, line);
                    Path l3 = new Path();
                    l3.moveTo(3.6f, 16.2f);
                    l3.lineTo(12, 21f);
                    l3.lineTo(20.4f, 16.2f);
                    cv.drawPath(l3, line);
                    break;
                case SLIDESHOW:
                    line.setStrokeWidth(2f);
                    cv.drawRoundRect(new RectF(3.6f, 5f, 20.4f, 19f), 3.6f, 3.6f, line);
                    p.moveTo(10.2f, 9.2f);
                    p.lineTo(15.2f, 12f);
                    p.lineTo(10.2f, 14.8f);
                    p.close();
                    soft(cv, p, 1.4f);
                    break;
                case SLEEP:
                    p.moveTo(19.6f, 14.6f);
                    p.cubicTo(18.4f, 15f, 17.2f, 15.2f, 16f, 15.2f);
                    p.cubicTo(11.9f, 15.2f, 8.6f, 11.9f, 8.6f, 7.8f);
                    p.cubicTo(8.6f, 6.6f, 8.8f, 5.4f, 9.4f, 4.2f);
                    p.cubicTo(5.8f, 5.2f, 3.4f, 8.5f, 3.4f, 12.4f);
                    p.cubicTo(3.4f, 17.2f, 7.2f, 21f, 12f, 21f);
                    p.cubicTo(15.4f, 21f, 18.5f, 18.4f, 19.6f, 14.6f);
                    p.close();
                    soft(cv, p, 1.4f);
                    break;
                default:
                    break;
            }
            cv.restore();
        }

        @Override
        public void setAlpha(int a) {
            fill.setAlpha(a);
            line.setAlpha(a);
            txt.setAlpha(a);
        }

        @Override
        public void setColorFilter(ColorFilter f) {
            fill.setColorFilter(f);
            line.setColorFilter(f);
            txt.setColorFilter(f);
        }

        @Override
        public int getOpacity() {
            return PixelFormat.TRANSLUCENT;
        }
    }
}
