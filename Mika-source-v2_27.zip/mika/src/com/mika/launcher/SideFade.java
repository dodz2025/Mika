package com.mika.launcher;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;

/**
 * Wraps a page and fades its left and right edges smoothly to black (= transparent on an AMOLED screen).
 * Same setting as the car page: Settings > Day & night > "Car page side fade (AMOLED)" (carFade: 0 off, 1 soft, 2 wide).
 * The fade views never take touches, so everything underneath still works.
 */
final class SideFade extends FrameLayout {
    private final View left, right;

    SideFade(Context c, View child) {
        super(c);
        addView(child, new FrameLayout.LayoutParams(-1, -1));
        left = new View(c);
        right = new View(c);
        addView(left, new FrameLayout.LayoutParams(0, -1, Gravity.LEFT));
        addView(right, new FrameLayout.LayoutParams(0, -1, Gravity.RIGHT));
        apply();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        apply();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) apply();
    }

    /** Width in pixels of the faded strip on each side (0 when the fade is off). */
    static int widthPx(Context c) {
        int mode = Prefs.i(c, "carFade", 1);
        float frac = mode == 1 ? 0.14f : mode == 2 ? 0.24f : 0f;
        return Math.round(c.getResources().getDisplayMetrics().widthPixels * frac);
    }

    private void apply() {
        int mode = Prefs.i(getContext(), "carFade", 1);
        float frac = mode == 1 ? 0.14f : mode == 2 ? 0.24f : 0f;
        int w = getWidth() > 0 ? getWidth() : getResources().getDisplayMetrics().widthPixels;
        int fw = Math.round(w * frac);
        int n = 16;
        int[] cols = new int[n];
        for (int i = 0; i < n; i++) {
            float t = i / (float) (n - 1);
            float sm = t * t * (3f - 2f * t);
            cols[i] = ((int) (255f * (1f - sm)) << 24);
        }
        left.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, cols));
        right.setBackground(new GradientDrawable(GradientDrawable.Orientation.RIGHT_LEFT, cols));
        for (View v : new View[]{left, right}) {
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) v.getLayoutParams();
            if (lp.width != fw) {
                lp.width = fw;
                v.setLayoutParams(lp);
            }
            v.setVisibility(fw > 0 ? View.VISIBLE : View.GONE);
        }
    }
}
