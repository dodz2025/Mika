package com.mika.launcher;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Smooths the normals of an un-indexed triangle list: every vertex takes the area-weighted average of the
 * faces that meet at the same position and bend away from its own face by less than the crease angle.
 * Hard edges (panel gaps, window frames, bumper lips) stay sharp, curved panels and tyres turn smooth.
 * Pure Java, no Android classes, so it can be unit-tested on a desktop JVM.
 */
final class MeshSmooth {
    private MeshSmooth() {
    }

    /**
     * @param v        vertex floats, three vertices per triangle, `stride` floats per vertex
     * @param len      number of valid floats in v
     * @param stride   floats per vertex (position at 0..2)
     * @param nrm      offset of the normal (3 floats) inside a vertex; it holds the flat face normal on entry
     * @param creaseCos cosine of the largest angle between two faces that is still smoothed over
     */
    static void smooth(float[] v, int len, int stride, int nrm, float creaseCos) {
        int nv = len / stride;
        nv -= nv % 3;
        if (nv < 3) return;
        int nt = nv / 3;
        float[] fn = new float[nt * 3];   // flat face normals (unit)
        float[] fa = new float[nt];       // face areas
        for (int t = 0; t < nt; t++) {
            int a = t * 3 * stride, b = a + stride, c = b + stride;
            float ux = v[b] - v[a], uy = v[b + 1] - v[a + 1], uz = v[b + 2] - v[a + 2];
            float wx = v[c] - v[a], wy = v[c + 1] - v[a + 1], wz = v[c + 2] - v[a + 2];
            float nx = uy * wz - uz * wy, ny = uz * wx - ux * wz, nz = ux * wy - uy * wx;
            float l = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
            fa[t] = l * 0.5f;
            // use the normal that is already stored (it may be flipped outwards by the loader), not the winding
            float sx = v[a + nrm], sy = v[a + nrm + 1], sz = v[a + nrm + 2];
            float sl = (float) Math.sqrt(sx * sx + sy * sy + sz * sz);
            if (sl < 1e-6f) {
                if (l < 1e-12f) {
                    sx = 0f; sy = 1f; sz = 0f;
                } else {
                    sx = nx / l; sy = ny / l; sz = nz / l;
                }
            } else {
                sx /= sl; sy /= sl; sz /= sl;
            }
            fn[t * 3] = sx;
            fn[t * 3 + 1] = sy;
            fn[t * 3 + 2] = sz;
        }
        // group the triangle corners by exact position (21 bits per axis at 1 mm: no hash collisions)
        HashMap<Long, List<Integer>> groups = new HashMap<Long, List<Integer>>(nv * 2);
        long[] keyOf = new long[nv];
        for (int i = 0; i < nv; i++) {
            int o = i * stride;
            long qx = Math.round(v[o] * 1000.0) + (1L << 20);
            long qy = Math.round(v[o + 1] * 1000.0) + (1L << 20);
            long qz = Math.round(v[o + 2] * 1000.0) + (1L << 20);
            long key = ((qx & 0x1FFFFFL) << 42) | ((qy & 0x1FFFFFL) << 21) | (qz & 0x1FFFFFL);
            keyOf[i] = key;
            List<Integer> g = groups.get(key);
            if (g == null) {
                g = new ArrayList<Integer>(6);
                groups.put(key, g);
            }
            g.add(i);
        }
        float[] out = new float[nv * 3];
        for (int i = 0; i < nv; i++) {
            int t = i / 3;
            float bx = fn[t * 3], by = fn[t * 3 + 1], bz = fn[t * 3 + 2];
            float sx = 0f, sy = 0f, sz = 0f;
            List<Integer> g = groups.get(keyOf[i]);
            for (int k = 0; k < g.size(); k++) {
                int tj = g.get(k) / 3;
                float dx = fn[tj * 3], dy = fn[tj * 3 + 1], dz = fn[tj * 3 + 2];
                if (bx * dx + by * dy + bz * dz < creaseCos) continue;
                float w = fa[tj] + 1e-9f;
                sx += dx * w; sy += dy * w; sz += dz * w;
            }
            float l = (float) Math.sqrt(sx * sx + sy * sy + sz * sz);
            if (l < 1e-9f) {
                sx = bx; sy = by; sz = bz;
            } else {
                sx /= l; sy /= l; sz /= l;
            }
            out[i * 3] = sx;
            out[i * 3 + 1] = sy;
            out[i * 3 + 2] = sz;
        }
        for (int i = 0; i < nv; i++) {
            int o = i * stride + nrm;
            v[o] = out[i * 3];
            v[o + 1] = out[i * 3 + 1];
            v[o + 2] = out[i * 3 + 2];
        }
    }
}
