package com.mika.launcher;

import android.content.Context;

import java.util.Calendar;

/**
 * Day / night schedule set by the user (Settings > Day & night).
 * Day starts at "skyDayMin" and night starts at "skyNightMin" (minutes since midnight). The sky eases between
 * the two over about 40 minutes (dawn / dusk) instead of switching instantly.
 */
final class SkyClock {
    static final int DEF_DAY_MIN = 6 * 60;
    static final int DEF_NIGHT_MIN = 18 * 60;
    /** Half-width of the dawn / dusk transition, in minutes. */
    private static final float RAMP = 20f;

    private SkyClock() {
    }

    static int dayStart(Context c) {
        return Prefs.i(c, "skyDayMin", DEF_DAY_MIN);
    }

    static int nightStart(Context c) {
        return Prefs.i(c, "skyNightMin", DEF_NIGHT_MIN);
    }

    /** 0 = automatic (follow the schedule), 1 = always day, 2 = always night. */
    static int mode(Context c) {
        return Prefs.i(c, "skyMode", 0);
    }

    static float nowMinutes() {
        Calendar k = Calendar.getInstance();
        return k.get(Calendar.HOUR_OF_DAY) * 60f + k.get(Calendar.MINUTE) + k.get(Calendar.SECOND) / 60f;
    }

    /** True when the schedule (ignoring the "always day / night" override) says it is night. Used by the auto theme. */
    static boolean scheduleNight(Context c) {
        return schedule(c, nowMinutes()) < 0.5f;
    }

    /** Target daylight for the 3D sky: 0 = full night, 1 = full day, in between = dawn / dusk. */
    static float daylight(Context c) {
        int m = mode(c);
        if (m == 1) return 1f;
        if (m == 2) return 0f;
        return schedule(c, nowMinutes());
    }

    private static float clamp01(float v) {
        return v < 0f ? 0f : (v > 1f ? 1f : v);
    }

    private static float schedule(Context c, float now) {
        float ds = dayStart(c), ns = nightStart(c);
        float len = ((ns - ds) % 1440f + 1440f) % 1440f; // length of the day, minutes
        if (len == 0f) return 1f;
        float f = ((now - ds) % 1440f + 1440f) % 1440f; // minutes since day start
        float rise = clamp01((f + RAMP) / (2f * RAMP));
        float fall = clamp01((len + RAMP - f) / (2f * RAMP));
        float riseNext = clamp01((f - 1440f + RAMP) / (2f * RAMP));
        float v = Math.max(Math.min(rise, fall), riseNext);
        return v * v * (3f - 2f * v);
    }

    /** "6:00 AM" or "06:00" depending on the 24-hour setting. */
    static String fmt(Context c, int minutes) {
        int h = (minutes / 60) % 24, m = minutes % 60;
        if (Prefs.b(c, "h24", true)) return String.format("%02d:%02d", h, m);
        int h12 = h % 12 == 0 ? 12 : h % 12;
        return String.format("%d:%02d %s", h12, m, h < 12 ? "AM" : "PM");
    }

    /** Label for the quick day / night switch on the Car page. */
    static String label(Context c) {
        int m = mode(c);
        if (m == 1) return "Day";
        if (m == 2) return "Night";
        return "Auto \u00B7 " + (daylight(c) >= 0.5f ? "Day" : "Night");
    }
}
